/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss(jesse.kriss@us.ibm.com), CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util;

import com.ibm.sdl.data.api.ITreeData;

public class TreeTraverser {
	
	public interface IRecursionDelegator {
		public void perform(ITreeData tree, Object node, Object param);
	}
	
	public static void dfsTraverse(ITreeData tree, IRecursionDelegator delegator, Object param) {
		dfs(tree, tree.getTreeRoot(), delegator, param);
	}
	
	private static void dfs(ITreeData tree, Object parent, IRecursionDelegator delegator, Object param) {
		
		delegator.perform(tree, parent, param);
		int cnt = tree.getChildCount(parent);
		Object child = null;
		for(int i = 0; i < cnt; ++i) {
			child = tree.getChild(parent, i);
			dfs(tree, child, delegator, param);
		}
	}
	
	public static void bfsTraverse(ITreeData tree, IRecursionDelegator delegator, Object param) {
		if(null == delegator) {
			return;
		}
		
		delegator.perform(tree, tree.getTreeRoot(), param);
		
		bfs(tree, tree.getTreeRoot(), delegator, param);
	}
	
	private static void bfs(ITreeData tree, Object parent, IRecursionDelegator delegator, Object param) {
		
		int cnt = tree.getChildCount(parent);
		Object child = null;
		for(int i = 0; i < cnt; ++i) {
			child = tree.getChild(parent, i);
			delegator.perform(tree, child, param);
		}
		
		for(int i = 0; i < cnt; ++i) {
			child = tree.getChild(parent, i);
			bfs(tree, child, delegator, param);
		}
	}
}
