/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.prop;

/**
 * 
 * @author CaoNan
 *
 */
public interface ITooltip {
 
	public static String PROP_TOOLTIP = "#PROP_TOOLTIP#";
	 
	public abstract String getTooltip();
	public abstract void setTooltip(String tip);
}
 
