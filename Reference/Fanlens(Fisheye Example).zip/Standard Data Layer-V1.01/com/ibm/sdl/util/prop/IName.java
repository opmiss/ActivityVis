/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.prop;

/**
 * 
 * @author CaoNan
 *
 */
public interface IName {
 
	public String PROP_NAME = "#PROP_NAME#";
	 
	public abstract String getName();
	public abstract void setName(String name);
}
 
