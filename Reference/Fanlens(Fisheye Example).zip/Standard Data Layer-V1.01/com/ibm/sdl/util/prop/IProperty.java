/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.prop;

import java.io.Serializable;

/**
 * 
 * @author CaoNan
 *
 */
public interface IProperty extends Serializable {	
	public void addProperty(Object key, Object value);
	public void setProperty(Object key, Object value);
	public Object getProperty(Object key);
	public Object removeProperty(Object key);
	public Object[] getKeyCollection();
	public Object[] getValueCollection();
	
	public void addPropertyListener(IPropertyListener prop);
	public void removePropertyListener(IPropertyListener prop);
	public IPropertyListener[] removeAllListeners();
	public IPropertyListener[] getPropertyListeners();
	public void clear();
}
