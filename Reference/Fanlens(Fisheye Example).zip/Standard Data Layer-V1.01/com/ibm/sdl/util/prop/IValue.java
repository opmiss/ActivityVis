/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.prop;

public interface IValue {

	public static final String PROP_WEIGHT = "#PROP_VALUE#";
	
	public Object getValue();
	
	public void setValue(Object value);
	
}
