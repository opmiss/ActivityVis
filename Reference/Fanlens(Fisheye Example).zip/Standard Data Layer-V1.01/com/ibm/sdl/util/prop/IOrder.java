package com.ibm.sdl.util.prop;

public interface IOrder {

	public static String PROP_ORDER = "order";
	
	public int getOrder();
	
	public void setOrder(int order);
	
}
