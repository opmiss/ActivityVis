/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.prop;

/**
 * 
 * @author CaoNan
 *
 */
public interface IWeight {
 
	public static final double DEFAULT_WIEGHT = 0.0001;
	public static final String PROP_WEIGHT = "#PROP_WEIGHT#";
	 
	public abstract double getWeight();
	public abstract void setWeight(double weight);
}
 
