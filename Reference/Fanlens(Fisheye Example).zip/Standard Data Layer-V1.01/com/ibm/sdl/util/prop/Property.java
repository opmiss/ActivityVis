/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.prop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Property implements IProperty {

	private static final long serialVersionUID = 6751110231518204968L;
	
	protected Map m_prop = new HashMap();
	
	protected List m_listeners = null;
	
	public Property() {
		m_listeners = new ArrayList(0);
	}
	
	public void addProperty(Object key, Object value) {
		if(null == m_prop.get(key)) {
			m_prop.put(key, value);
			firePropertyAdded(key, this);
		} else {
			setProperty(key, value);
		}
	}
	
	public void setProperty(Object key, Object value) {
		if(m_prop.containsKey(key)) {
			Object v = m_prop.get(key);
			if(null != v && !v.equals(value)) {
				m_prop.put(key, value);
				firePropertyChanged(key, this);
			}
		}
	}

	public Object getProperty(Object key) {
		return m_prop.get(key);
	}

	public Object[] getKeyCollection() {
		return m_prop.keySet().toArray();
	}

	public Object[] getValueCollection() {
		return m_prop.values().toArray();
	}
	
	public Object removeProperty(Object key) {
		Object value = m_prop.remove(key);
		firePropertyRemoved(key, value);
		return value;
	}

	public void addPropertyListener(IPropertyListener listener) {
		m_listeners.add(listener);
	}

	public void removePropertyListener(IPropertyListener listener) {
		m_listeners.remove(listener);
	}
	
	public IPropertyListener[] removeAllListeners() {
		IPropertyListener[] listeners = getPropertyListeners();
		m_listeners.clear();
		return listeners;
	}

	public IPropertyListener[] getPropertyListeners() {
		return (IPropertyListener[])m_listeners.toArray(new IPropertyListener[]{});
	}
	
	public void clear() {
		m_prop.clear();
		firePropertyCleared();
	}
	
	public void firePropertyChanged(Object key, IProperty prop) {
		int size = m_listeners.size();
		IPropertyListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IPropertyListener)m_listeners.get(i);
			l.propertyChanged(key, prop);
		}
	}
	
	public void firePropertyAdded(Object key, IProperty prop) {
		int size = m_listeners.size();
		IPropertyListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IPropertyListener)m_listeners.get(i);
			l.propertyAdded(key, prop);
		}
	}
	
	public void firePropertyRemoved(Object key, Object value) {
		int size = m_listeners.size();
		IPropertyListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IPropertyListener)m_listeners.get(i);
			l.propertyRemoved(key, value);
		}
	}
	
	public void firePropertyCleared() {
		int size = m_listeners.size();
		IPropertyListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IPropertyListener)m_listeners.get(i);
			l.propertyCleared();
		}
	}
}
