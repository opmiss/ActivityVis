/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss(jesse.kriss@us.ibm.com), CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util;

import java.util.Date;

public interface IPropExtractor {

	public String getName(Object data);
	
	public String getID(Object data);
	
	public String getTooltip(Object data);
	
	public double getWeight(Object data);
	
	public void setWeight(Object data, double weight);
	
	public String getType(Object data);
	
	public Object getProperty(Object key, Object data);
	
	public void setProperty(Object data, Object key, Object value);
	
	public void removeProperty(Object data, Object key);
	
	public Object[] getValueCollection(Object data);
	
	public Object[] getKeyCollection(Object data);
	
	public void clear(Object data);
	
	public double getDouble(Object key, Object data);
	
	public float getFloat(Object key, Object data);
	
	public String getString(Object key, Object data);
	
	public long getLong(Object key, Object data);
	
	public int getInteger(Object key, Object data);
	
	public Date getDate(Object key, Object data);
}
