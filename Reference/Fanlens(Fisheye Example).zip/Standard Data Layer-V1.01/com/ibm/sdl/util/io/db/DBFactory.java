/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Liulijie, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;

import com.ibm.sdl.util.PropOperator;

/**
 * @author lijie liu
 *
 */
public class DBFactory {
	
	private static final String blankAccess = "data/blankDB/blank.mdb";
	
	public static Access createAccess(String dbfile) throws IOException {
		if(dbfile.equals(blankAccess))
			throw new IOException("Can not load the orignal BLANK DB!");
		copyAccess(blankAccess, dbfile);
		
		return new Access(dbfile);
	}
	public static Access loadAccess(String dbfile) {
		return new Access(dbfile);
	}
	
	public static MySQL createMySQL(String ip, int port, String dbName, String username, String password) {
		return new MySQL(ip, port, dbName, username, password);
	}
	
	private static void copyAccess(String fromFile, String toFile) throws IOException {
        int  bytesum  =  0;  
        int  byteread  =  0;  
        File oldfile = new File(fromFile);
        File newfile = new File(toFile);
        if(newfile.exists()) 
     	   newfile.delete();
        
        if  (oldfile.exists())  {
            InputStream  inStream  =  new  FileInputStream(fromFile);
            FileOutputStream  fs  =  new  FileOutputStream(toFile);  
            byte[]  buffer  =  new  byte[1444];  
            while  (  (byteread  =  inStream.read(buffer))  !=  -1)  {  
                bytesum  +=  byteread; 
                fs.write(buffer,  0,  byteread);  
            }  
            inStream.close();
            fs.close();
        }  
    }  
	
	public static String format(String parameter) {
		return parameter.replace("#", "___").replaceAll(" ___", " [___").replaceAll("___ ", "___] ");
	}
	
	public static String unformat(String parameter) {
		return parameter.replace("___", "#");
	}
	
	public static void setParameter(String[] m_columns, Class[] m_schemas, PreparedStatement pstmt, Object row) throws SQLException {
		int length = m_schemas.length;

		for(int j = 0; j < length; j++) {
			String colname = m_columns[j];
			Object data = null;
			
			if(m_schemas[j] == boolean.class) {
				data = PropOperator.getInstance().getProperty(colname, row);
				if(null != data)
					pstmt.setBoolean(j+1, Boolean.valueOf((String)data));
				else
					pstmt.setBoolean(j+1, false);
			} else if(m_schemas[j] == Date.class) {
				Date date = (Date)PropOperator.getInstance().getProperty(colname, row);
				if(date != null) {
					java.sql.Date sqlDate = null;
					sqlDate.parse(date.toLocaleString());
					pstmt.setDate(j+1, sqlDate);
				}else{
					pstmt.setDate(j+1, null);
				}
			} else if(m_schemas[j] == double.class) {
				data = PropOperator.getInstance().getDouble(colname, row);
				if(null != data)
					pstmt.setDouble(j+1, (Double)data);
				else
					pstmt.setDouble(j+1, Double.NaN);
			} else if(m_schemas[j] == int.class) {
				data = PropOperator.getInstance().getInteger(colname, row);
				if(null != data)
					pstmt.setDouble(j+1, (Integer)data);
				else
					pstmt.setDouble(j+1, -1);
			} else if(m_schemas[j] == long.class) {
				data = PropOperator.getInstance().getLong(colname, row);
				if(null != data)
					pstmt.setLong(j+1, (Long)data);
				else
					pstmt.setLong(j+1, -1);
			} else if(m_schemas[j] == String.class) {
				data = PropOperator.getInstance().getString(colname, row);
				if(null != data)
					pstmt.setString(j+1, (String)data);
				else
					pstmt.setString(j+1, null);
			} else  {
				data = PropOperator.getInstance().getString(colname, row);
				if(null != data)
					pstmt.setString(j+1, (String)data);
				else
					pstmt.setString(j+1, null);
			}
		}
	}
	
}
