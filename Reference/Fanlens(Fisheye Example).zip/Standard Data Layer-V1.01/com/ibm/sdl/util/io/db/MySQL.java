/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Liulijie, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
/**
 * @author lijie liu
 *
 */
public class MySQL implements IDatabase{
	
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;

	private Connection conn = null;
	
	protected MySQL(String ip, int port, String dbName, String username, String password){
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://"+ ip +":"+ port +"/" + dbName, username, password);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public ResultSet getResultSet() {
		return rs;
	}
	public void prepareStatement(String sql) throws SQLException {
		this.clear();
		pstmt = conn.prepareStatement(sql);
	}
	
	public void setInt(int parameterIndex, int x) throws SQLException {
		pstmt.setInt(parameterIndex, x);
	}
	
	public int getInt(String columnName) throws SQLException {
		return rs.getInt(columnName);
	}
	
	public void setBoolean(int parameterIndex, boolean x) throws SQLException {
		if(x == false) {
			pstmt.setString(parameterIndex, "false");			
		}else if(x == true) {
			pstmt.setString(parameterIndex, "true");			
		}else {
			pstmt.setString(parameterIndex, "");
		}
	}
	
	public boolean getBoolean(String columnName) throws SQLException {
		return rs.getBoolean(columnName);
	}

	public void setTime(int parameterIndex, Calendar x) throws SQLException {
		if(null==x) {
			pstmt.setString(parameterIndex, "");
		}else {
			pstmt.setString(parameterIndex, x.getTime().toString());			
		}
	}
	
	public void setString(int parameterIndex, Object x) throws SQLException {
		if(null==x) {
			x = "";
		}
		pstmt.setString(parameterIndex, x.toString());
	}
	public String getString(String columnName) throws SQLException {
		return rs.getString(columnName);
	}
	
	public void executeUpdate() throws SQLException {
		pstmt.executeUpdate();
	}
	public void clear(){
	try{
		if(null!=pstmt){
			pstmt.close();
			pstmt=null;
		}
		if(null!=rs){
			rs.close();
			rs=null;
		}
	}catch(Exception e){
	}
}
	public void setAutoCommit(boolean flag) throws SQLException{
		conn.setAutoCommit(flag);
	}
	public void truncate() throws SQLException{
		Statement pstmt = conn.createStatement();
		pstmt.executeUpdate("truncate tbl_edge_activity;");
		pstmt.executeUpdate("truncate tbl_edge_orgnization;");
		pstmt.executeUpdate("truncate tbl_node_activity;");
		pstmt.executeUpdate("truncate tbl_node_orgnization;");
		pstmt.executeUpdate("truncate tbl_user;");
	}
	public void commit() throws SQLException {
		conn.commit();
	}
	public void close(){
		try{
			if(null!=conn){
				conn.close();
				conn=null;
			}
		}catch(Exception e){
		}
	}
	public void executeQuery() throws SQLException {
		rs = pstmt.executeQuery();
	}

	public Calendar getTime(String columnName) throws SQLException {
		return null;
	}

	public Statement createStatement() throws SQLException {
		return null;
	}

	public Statement createStatement(int arg0, int arg1) throws SQLException {
		return null;
	}

	public Connection getConnection() {
		return null;
	}

	public float getFloat(String columnName) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setFloat(int parameterIndex, float x) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public double getDouble(String columnName) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public long getLong(String columnName) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setDouble(int parameterIndex, double x) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void setLong(int parameterIndex, long x) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void execute(String sql) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void createTable(String tableName, String[] columnNames, Class[] schemas) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public Date getDate(String columnName) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	public void setDate(int parameterIndex, Date x) throws SQLException {
		// TODO Auto-generated method stub
		
	}

	public void dropTable(String tableName) throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
