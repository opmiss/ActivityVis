package com.ibm.sdl.util.io;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface IDatabaseManager {

	public void connect(String conn);
	
	public void prepareStatement(String sql) throws SQLException;

	public void setParameter(int pidx, String param) throws SQLException;

	public ResultSet getResultSet();

	public void clear();

	public void setAutoCommit(boolean flag) throws SQLException;

	public void commit() throws SQLException;

	public void close();
	
	public void executeUpdate() throws SQLException;

	public void executeQuery() throws SQLException;
	
	public Connection getConnection();
	
}
