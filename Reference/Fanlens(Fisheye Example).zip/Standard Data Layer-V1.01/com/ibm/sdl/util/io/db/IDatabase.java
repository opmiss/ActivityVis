/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Liulijie, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io.db;

import java.sql.Connection;
import java.sql.SQLException;
/**
 * @author lijie liu
 *
 */
public interface IDatabase {
	
	public abstract void createTable(String tableName, String[] columnNames, Class[] schemas) throws SQLException;

	public abstract void dropTable(String tableName) throws SQLException;
	
	public abstract Connection getConnection();
}
