/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.InputStream;

import com.ibm.sdl.util.filter.IItemFilter;

/**
 * 
 * @author CaoNan
 *
 */
public interface IDataReader 
{
	public boolean read(InputStream instream);
	public Object getData();
	public Object getFilteredData(IItemFilter filter);
	public void setNodeType(Class type);
	public void setEdgeType(Class type);
}
