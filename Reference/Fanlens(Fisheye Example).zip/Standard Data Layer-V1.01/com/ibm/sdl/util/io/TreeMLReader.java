/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.filter.IItemFilter;

public class TreeMLReader extends DefaultHandler implements IDataReader {

	private static final String TREE = "tree";

	private static final String BRANCH = "branch";

	private static final String LEAF = "leaf";

	private static final String ATTR = "attribute";

	private static final String NAME = "name";

	private static final String VALUE = "value";

	private static final String TYPE = "type";

	private static final String DECLS = "declarations";

	private static final String DECL = "attributeDecl";

	private static final String INT = "Int";

	private static final String INTEGER = "Integer";

	private static final String LONG = "Long";

	private static final String FLOAT = "Float";

	private static final String REAL = "Real";

	private static final String STRING = "String";

	private static final String DATE = "Date";

	private static final String CATEGORY = "Category";

	// prefuse-specific allowed types
	public static final String BOOLEAN = "Boolean";

	public static final String DOUBLE = "Double";

	private EntityTree m_tree = null;

	private Object m_activeNode = null;

	private Class m_nodetype = null;

	private Class m_edgetype = null;
	
	public TreeMLReader(Class nodetype, Class edgetype) {
		m_nodetype = nodetype;
		m_edgetype = edgetype;
	}

	public boolean read(InputStream inxml) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(false);
			SAXParser parser;
			parser = factory.newSAXParser();
			parser.parse(new InputSource(inxml), this);
			return true;
		} catch (MalformedURLException me) {
			return false;
		} catch (IOException ie) {
			ie.printStackTrace();
			return false;
		} catch (SAXException se) {
			se.printStackTrace();
			return false;
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
			return false;
		}
	}

	public Object getData() {
		return m_tree;
	}

	public Object getFilteredData(IItemFilter filter) {
		return m_tree.getNodes(filter, null);
	}

	public void setNodeType(Class type) {
		m_nodetype = type;
	}

	public void setEdgeType(Class type) {
		m_edgetype = type;
	}

	public void startDocument() {
		m_tree = new EntityTree();
		m_tree.setEdgeType(m_edgetype);
	}

	public void endElement(String namespaceURI, String localName, String qName) {
		if (qName.equals(BRANCH) || qName.equals(LEAF)) {
			m_activeNode = m_tree.getParent(m_activeNode);
		}
	}

	public void startElement(String namespaceURI, String localName,
			String qName, Attributes atts) {
		if (qName.equals(DECL)) {
//			if (!m_inSchema) {
//				throw new RuntimeException("All declarations must be done "
//						+ "before nodes begin");
//			}
//			String name = atts.getValue(NAME);
//			String type = atts.getValue(TYPE);
		} else if (qName.equals(BRANCH) || qName.equals(LEAF)) {
			try {
				// parse a node element
				Object n;
				if (m_activeNode == null) {
					n = m_nodetype.newInstance();
					m_tree.setTreeRoot(n);
				} else {
					n = m_nodetype.newInstance();
					m_tree.addChild(m_activeNode, n);
				}
				m_activeNode = n;
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		} else if (qName.equals(ATTR)) {
			// parse an attribute
			parseAttribute(atts);
		}
	}

	protected void parseAttribute(Attributes atts) {
		String alName, name = null, value = null;
		for (int i = 0; i < atts.getLength(); i++) {
			alName = atts.getQName(i);
			if (alName.equals(NAME)) {
				name = atts.getValue(i);
			} else if (alName.equals(VALUE)) {
				value = atts.getValue(i);
			}
		}
		if (name == null || value == null) {
			System.err.println("Attribute under-specified");
			return;
		}
		PropOperator.getInstance().setProperty(m_activeNode, name, value);
	}
}
