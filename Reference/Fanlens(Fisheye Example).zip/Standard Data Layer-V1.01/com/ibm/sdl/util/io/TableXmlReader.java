/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.table.impl.EntityTable;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.filter.IItemFilter;

public class TableXmlReader extends DefaultHandler implements IDataReader {

	private StringBuffer buffer = null;
	private EntityTable m_table = null;
	
	private Class[] schemes = null;
	private String[] names = null;
	
	private boolean bTable = false;
	private boolean bScheme = false;
	private boolean bColumn = false;
	private boolean bRow = false;
	
	private String rowName = null;
	private Object currentRow = null;
	private String column = "";
	Class scheme = null;
	
	protected Class rowType = null;
	
	public TableXmlReader(Class rowType) {
		super();
		buffer = new StringBuffer();
		m_table = new EntityTable();
		m_table.clearAll();
		this.rowType = rowType; 
	}

	public boolean read(InputStream inxml) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(false);
			SAXParser parser;
			parser = factory.newSAXParser();
			parser.parse(new InputSource(inxml), this);
			return true;
		} catch (MalformedURLException me) {
			return false;
		} catch (IOException ie) {
			return false;
		} catch (SAXException se) {
			se.printStackTrace();
			return false;
		} catch (ParserConfigurationException pe) {
			return false;
		}
	}

	public Object getData() {
		
		if(null == schemes || null == names) {
			return null;
		}
		
		return m_table;
	}

	public Object getFilteredData(IItemFilter filter) {
		return null;
	}

	public void setNodeType(Class type) {
		rowType = type;
	}

	public void setEdgeType(Class type) {
		// do nothing
	}

	int cursor = 0;
	public void startElement(String namespaceURI, String localName,
			String qName, Attributes attrs) throws SAXException {
		try {
			if ("table".equalsIgnoreCase(qName)) {
				bTable = true;
			} else if ("scheme".equalsIgnoreCase(qName)) {
				if (bTable) {
					bScheme = true;
					int cnt = Integer.parseInt(attrs.getValue("count"));
					schemes = new Class[cnt];
					names = new String[cnt];
				} else {
					throw new SAXException("Invalidate XML file");
				}
			} else if ("row".equalsIgnoreCase(qName)) {
				if (bTable) {
					bRow = true;
					currentRow = rowType.newInstance();
					rowName = attrs.getValue("name");
				} else {
					throw new SAXException("Invalidate XML file");
				}
			} else if ("column".equalsIgnoreCase(qName)) {
				if (bScheme) {
					bColumn = true;
					names[cursor] = attrs.getValue("name");
					String type = attrs.getValue("type");
					if("boolean".equalsIgnoreCase(type)) {
						schemes[cursor] = boolean.class;
					} else if("date".equalsIgnoreCase(type)) {
						schemes[cursor] = Date.class;
					} else if("double".equalsIgnoreCase(type)) {
						schemes[cursor] = double.class;
					} else if("integer".equalsIgnoreCase(type)) {
						schemes[cursor] = int.class;
					} else if("long".equalsIgnoreCase(type)) {
						schemes[cursor] = long.class;
					} else if("string".equalsIgnoreCase(type)) {
						schemes[cursor] = String.class;
					} else if("object".equalsIgnoreCase(type)) {
						schemes[cursor] = Object.class;
					}
					cursor ++;
				} else if(bRow) {
					bColumn = true;
					int sn = Integer.parseInt(attrs.getValue("sn"));
					column = names[sn];
					scheme = schemes[sn];
				} else {
					throw new SAXException("Invalidate XML file");
				}
			} else {
				throw new SAXException("Invalidate XML file");
			}
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		}
	}

	public void characters(char[] ch, int start, int length) {
		if (bRow && bColumn) {
			buffer.append(ch, start, length);
		}
	}
	
	public void endElement(String uri, String localName, String qName) {
		if ("table".equalsIgnoreCase(qName)) {
			bTable = false;
		} else if ("scheme".equalsIgnoreCase(qName)) {
			try {
				bScheme = false;
				m_table.setSchemes(schemes);
				m_table.setColumnNames(names);
			} catch (InvalidateDataException ie) {
				ie.printStackTrace();
			}
		} else if ("row".equalsIgnoreCase(qName)) {
			try {
				bRow = false;
				m_table.addRow(rowName, currentRow);
				currentRow = null;
			} catch (InvalidateTypeException e) {
				e.printStackTrace();
			}
		} else if ("column".equalsIgnoreCase(qName)) {
			if(bRow) {
				
				String value = buffer.toString();
				
				if(boolean.class.equals(scheme)) {
					PropOperator.getInstance().setProperty(currentRow, column, 
//							new Boolean(Boolean.parseBoolean(value)));
							Boolean.valueOf(value));
				} else if (double.class.equals(scheme)) {
					PropOperator.getInstance().setProperty(currentRow, column, 
							new Double(Double.parseDouble(value)));
				} else if (int.class.equals(scheme)) {
					PropOperator.getInstance().setProperty(currentRow, column, 
							new Integer(Integer.parseInt(value)));
				} else if (long.class.equals(scheme)) {
					PropOperator.getInstance().setProperty(currentRow, column, 
							new Long(Long.parseLong(value)));
				} else if (String.class.equals(scheme)) {
					PropOperator.getInstance().setProperty(currentRow, column, value);
				} else {
					PropOperator.getInstance().setProperty(currentRow, column, value);
				}
				
				buffer.delete(0, buffer.length());
			}
			bColumn = false;
		}
	}
}
