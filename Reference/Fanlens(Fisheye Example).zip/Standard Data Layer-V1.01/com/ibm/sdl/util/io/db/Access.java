/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Liu lijie, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io.db;

/**
 * @author lijie liu
 *
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Access implements IDatabase{
	
	private Connection conn = null;
	
	protected Access(String dbfile){
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			conn = DriverManager.getConnection("jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=" + dbfile);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Connection getConnection() {
		return conn;
	}
	
	public void createTable(String tableName, String[] columnNames, Class[] schemas) throws SQLException {
		if(conn == null)
			return;
		
		StringBuffer sql = new StringBuffer("create  table  " + tableName + " (" );
		
		for (int i = 0; i < columnNames.length; i++) {
			sql.append(columnNames[i] + " ");
			
			if(schemas[i].equals(String.class)){
				sql.append("VARCHAR");
			}else if(schemas[i].equals(Integer.class)){
				sql.append("INTEGER");				
			}else if(schemas[i].equals(Double.class)){
				sql.append("DOUBLE");				
			}else if(schemas[i].equals(Boolean.class)){
				sql.append("BIT");
			}else if(schemas[i].equals(Long.class)){
				sql.append("INTEGER");
			}else if(schemas[i].equals(Float.class)){
				sql.append("FLOAT");
			}else {
				sql.append("VARCHAR");
			}
			
			if(i == columnNames.length - 1) 
				sql.append(")");
			else
				sql.append(", ");
		}
		
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(DBFactory.format(sql.toString()));
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
	}

	public void dropTable(String tableName) throws SQLException {
		if(conn == null)
			return;
		
		try {
			Statement stmt = conn.createStatement();
			stmt.execute(DBFactory.format("DROP TABLE " + tableName));
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
	}

}
