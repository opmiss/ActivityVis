/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.IProperty;
import com.ibm.sdl.util.prop.Identifiable;


/**
 * The default tree structure resource loader, load tree 
 * from a xml document
 * 
 * @author CaoNan
 */
public class EntityTreeXmlReader extends DefaultHandler implements IDataReader
{
	protected boolean bTreemapData = false;
	protected boolean bItem = false;
	protected boolean bProperty = false;
	protected boolean bElement = false;
	protected String key = "";
	protected String type = "";
	
	protected IProperty current = null;
	protected EntityTree m_tree = null;
	
	protected Map pcollection = null;
	protected Class nodeType = null;
	protected StringBuffer buffer = new StringBuffer();
	
	protected Map m_pool = null;
	
	public EntityTreeXmlReader(Class nodeType, Class edgeType) {
		super();
		m_tree = new EntityTree();
		m_pool = new TreeMap();
		this.nodeType = nodeType;
		m_tree.setEdgeType(edgeType);
	}
	
	public Map getDataPool() {
		return m_pool;
	}
	
	public void setNodeType(Class dataType) {
		this.nodeType = dataType;
	}
	
	public void setEdgeType(Class type) {
		if(null != m_tree) {
			m_tree.setEdgeType(type);
		}
	}
		
	public boolean read(InputStream inxml) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
	        factory.setValidating(false);
	        factory.setNamespaceAware(false);
	        SAXParser parser;
			parser = factory.newSAXParser();
			parser.parse(new InputSource(inxml), this);
			return true;
		} catch (MalformedURLException me) {
			return false;
		} catch (IOException ie) {
			return false;
		} catch (SAXException se) {
			se.printStackTrace();
			return false;
		} catch (ParserConfigurationException pe) {
			return false;
		}
	}
	
	public Object getData() {
		if(m_tree.isEmpty()) {
			createTree(null);
		}
		return m_tree;
	}
	
	/**
	 * Implements the IResourceLoader.getFilteredResource() method
	 */
	public Object getFilteredData(IItemFilter filter) {
		m_tree.clear();
		createTree(filter);
		return m_tree;
	}
	
	public void startElement(String namespaceURI, String localName, 
			String qName, Attributes attrs) throws SAXException
	{
		try {
			if("PeonyTreeData".equalsIgnoreCase(qName)) {
				this.bTreemapData = true;
			} else if("item".equalsIgnoreCase(qName)) {
				if(bTreemapData) {
					this.bItem = true;
					current = (IProperty)nodeType.newInstance();
					current.addProperty(Identifiable.PROP_ID, attrs.getValue("", "id"));
//					try {
						current.addProperty(IName.PROP_NAME, attrs.getValue("", "name"));
//					} catch (UnsupportedEncodingException e) {
//						e.printStackTrace();
//					}
					current.addProperty(EntityTree.PROP_PARENT_URL, attrs.getValue("", "parent"));
				} else {
					throw new SAXException("Invalidate XML file");
				}
			} else if("property".equalsIgnoreCase(qName)) {
				if(bItem){
					this.bProperty = true;
					key = attrs.getValue("", "keyword");
					type = attrs.getValue("", "type");
					if("array".equalsIgnoreCase(type)) {
						pcollection = new HashMap();
						current.addProperty(key, pcollection);
					}
					if(0 != buffer.length()) {
						buffer.delete(0, buffer.length());
					}
				} else {
					throw new SAXException("Invalidate XML file");
				}
			} else if("element".equalsIgnoreCase(qName)) {
				if(bProperty) {
					bElement = true;
					key = attrs.getValue("", "keyword");
				} else {
					throw new SAXException("Invalidate XML file");
				}
			} else {
				throw new SAXException("Invalidate XML file");
			}
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		}
	}
	
	public void endElement(String uri, String localName, String qName)
	{
		if("TreemapData".equalsIgnoreCase(qName)){
			this.bTreemapData = false;
		} else if("item".equalsIgnoreCase(qName)){
			this.bItem = false;
			this.m_pool.put(current.getProperty(Identifiable.PROP_ID), current);
		} else if("property".equalsIgnoreCase(qName)){
			this.bProperty = false;
			current.addProperty(key, buffer.toString());
		} else if("element".equalsIgnoreCase(qName)) {
			this.bElement = false;
			pcollection.put(key, buffer.toString());
		}
	}
	
	public void characters(char[] ch, int start, int length)
	{
		if(bProperty && !("array".equalsIgnoreCase(type))) {
			buffer.append(ch, start, length);
		} else if(bElement) {
			buffer.append(ch, start, length);
		}
	}
	
	/**
	 * Create tree structure from the node pool
	 * 
	 * @param filter resource filter to select nodes
	 * @return
	 */
	protected void createTree(IItemFilter filter) {
		
		Object node = null;
		
		Iterator it = m_pool.values().iterator();
		while(it.hasNext()) {
			node = it.next();
			if(null != filter && !filter.accept(node)) {
				continue;
			}
			createBranch((IProperty)node);			
		}
		m_tree.refresh();
	}
	
	private void createBranch(IProperty node) {
		
		String url = (String)node.getProperty(EntityTree.PROP_PARENT_URL);
		Object parent = null;
		
		if("".equals(url)) {
//			System.out.println("root = " + node);
			this.m_tree.setTreeRoot(node);
		} else {
			parent = m_pool.get(url);
//			System.out.println("parent = " + parent + ", node = " + node);
			if(parent == null) {
				System.out.println("No parent : node = " + node.getProperty(Identifiable.PROP_ID));
				return;
			}
			if(!m_tree.containsChild(parent, node)) {
				m_tree.addChild(parent, node);
				createBranch((IProperty)parent);
			}
		}
	}
}
