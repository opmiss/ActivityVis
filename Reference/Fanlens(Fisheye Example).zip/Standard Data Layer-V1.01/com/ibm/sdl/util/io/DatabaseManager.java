/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseManager implements IDatabaseManager {
	
	private PreparedStatement pstmt = null;

	private ResultSet m_result = null;

	private Connection m_conn = null;

	private static DatabaseManager m_manager = null;

	private DatabaseManager() {
	}

	public static DatabaseManager getInstance() {
		if (null == m_manager) {
			m_manager = new DatabaseManager();
		}
		return m_manager;
	}
	
	public void connect(String conn) {
		try {
			if(m_conn != null) {
				m_conn.close();
				m_conn = null;
			}
			try {
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			// "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=ddd.mdb"
			m_conn = DriverManager.getConnection(conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void prepareStatement(String sql) throws SQLException {
		this.clear();
		pstmt = m_conn.prepareStatement(sql);
	}

	public void setParameter(int pidx, String param) throws SQLException {
		if (null == param) {
			param = "";
		}
		pstmt.setString(pidx, param);
	}

	public ResultSet getResultSet() {
		return m_result;
	}

	public void executeUpdate() throws SQLException {
		pstmt.executeUpdate();
	}

	public void clear() {
		try {
			if (null != pstmt) {
				pstmt.close();
				pstmt = null;
			}
			if (null != m_result) {
				m_result.close();
				m_result = null;
			}
		} catch (Exception e) {
		}
	}

	public void setAutoCommit(boolean flag) throws SQLException {
		m_conn.setAutoCommit(flag);
	}

	public void commit() throws SQLException {
		m_conn.commit();
	}

	public void close() {
		try {
			if (null != m_conn) {
				m_conn.close();
				m_conn = null;
			}
		} catch (Exception e) {
		}
	}

	public void executeQuery() throws SQLException {
		m_result = pstmt.executeQuery();
	}

	public Connection getConnection() {
		return m_conn;
	}
}
