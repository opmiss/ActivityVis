/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IProperty;
import com.ibm.sdl.util.prop.Identifiable;

public class TMLReader extends DefaultHandler implements IDataReader {
	
	public static String NODE = "node";

	public static String EDGE = "edge";

	public static String DATA = "data";

	private boolean isNode = false;
	private boolean isEdge = false;
	private boolean isData = false;
//	private boolean isName = false;
//	private boolean bGetNodeName = false;
	
	private String m_key = "";

	private EntityTree m_tree;

	protected Class data_type = null;

	private IProperty currNode = null;
	
	private IEdge currEdge = null;

	private String id = null;

	private HashMap nodeMap = null;
	
	private Object root = null;
	
	public TMLReader(Class nodeType, Class edgeType) {
		super();
		m_tree = new EntityTree();
		m_tree.setEdgeType(edgeType);
		nodeMap = new HashMap();
		data_type = nodeType;
	}

	
	public void clear(){
		m_tree.clear();
		nodeMap.clear();
		currNode = null;
		currEdge = null;
		id = null;
	}

	public Object getData() {
		if(null == m_tree.getTreeRoot()) {
			m_tree.setTreeRoot(root);
			m_tree.refresh();
		}
		return m_tree;
	}

	public void setNodeType(Class dataType) {
		data_type = dataType;
	}
	
	public void setEdgeType(Class type) {
		if(null != m_tree) {
			m_tree.setEdgeType(type);
		}
	}
	
	public Object getFilteredData(IItemFilter filter) {
		return null;
	}
	
	public boolean read(InputStream inxml) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
	        factory.setValidating(false);
	        factory.setNamespaceAware(false);
	        SAXParser parser;
			parser = factory.newSAXParser();
			parser.parse(new InputSource(inxml), this);
			return true;
		} catch (MalformedURLException me) {
			return false;
		} catch (IOException ie) {
			ie.printStackTrace();
			return false;
		} catch (SAXException se) {
			se.printStackTrace();
			return false;
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
			return false;
		}
	}

	StringBuffer m_buffer = new StringBuffer();
	
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		try {
			if (qName.equals(NODE)) {
				isNode = true;
				id = attributes.getValue("id");
				currNode = getNode(id);
				if(null == root) {
					root = currNode;
				}
				m_tree.addNode(currNode);
			} else if (qName.equals(DATA)) {
				isData = true;
				m_key = attributes.getValue("key");
			} else if (qName.equals(EDGE)) {
				isEdge = true;
				String id1 = attributes.getValue("source");
				String id2 = attributes.getValue("target");
				IProperty node1 = getNode(id1);
				IProperty node2 = getNode(id2);
				
//				System.out.println("create edge : source id = " + id1 + ", target id = " + id2);
				currEdge = (IEdge)m_tree.addEdge(node1, node2);
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (isData) {
			m_buffer.append(new String(ch, start, length));
		}
	}
	
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (qName.equals(NODE)) {
			isNode = false;
			currNode = null;
		} else if(qName.equals(DATA)) {
			isData = false;
			
			if(isNode) {
				currNode.addProperty(m_key, m_buffer.toString());
			} else if(isEdge) {
				currEdge.addProperty(m_key, m_buffer.toString());
			}
			m_buffer.delete(0, m_buffer.length());
			m_key = "";
		} else if(qName.equals(EDGE)) {
			isEdge = false;
			currEdge = null;
		}
	}
	
	protected IProperty getNode(String id) throws InstantiationException, IllegalAccessException {
		IProperty node = (IProperty)nodeMap.get(id);
		if(null == node) {
			node = (IProperty)data_type.newInstance();
			node.addProperty(Identifiable.PROP_ID, id);
			nodeMap.put(id, node);
		}
		return node;
	}

}
