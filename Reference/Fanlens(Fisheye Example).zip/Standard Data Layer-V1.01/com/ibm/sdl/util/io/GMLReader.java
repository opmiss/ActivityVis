/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.HashMap;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IProperty;
import com.ibm.sdl.util.prop.Identifiable;

public class GMLReader extends DefaultHandler implements IDataReader {

	public static String NODE = "node";

	public static String EDGE = "edge";

	public static String DATA = "data";

	private boolean isNode = false;
	private boolean isEdge = false;
	private boolean isData = false;
	
	private StringBuffer m_buff = null;
	
//	private boolean isName = false;
//	private boolean bGetNodeName = false;
	
	private String m_key = "";

	private EntityGraph m_graph;

	protected Class data_type = null;

	private IProperty currNode = null;
	
	private IEdge currEdge = null;

	private String id = null;

	private HashMap nodeMap = null;

	public GMLReader(Class nodeType, Class edgeType){
		super();
		m_graph = new EntityGraph();
		nodeMap = new HashMap();
		m_buff = new StringBuffer();
		data_type = nodeType;
		m_graph.setEdgeType(edgeType);
	}
	
	public void clear(){
		m_graph.clear();
		nodeMap.clear();
		currNode = null;
		currEdge = null;
		id = null;
	}

	public Object getData() {
		return m_graph;
	}

	public void setNodeType(Class dataType) {
		data_type = dataType;
	}
	
	public void setEdgeType(Class type) {
		if(null != m_graph) {
			m_graph.setEdgeType(type);
		}
	}
	
	public Object getFilteredData(IItemFilter filter) {
		return null;
	}
	
	public boolean read(InputStream inxml) {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			factory.setValidating(false);
			factory.setNamespaceAware(false);
			SAXParser parser;
			parser = factory.newSAXParser();
			parser.parse(new InputSource(inxml), this);
			return true;
		} catch (MalformedURLException me) {
			return false;
		} catch (IOException ie) {
			ie.printStackTrace();
			return false;
		} catch (SAXException se) {
			se.printStackTrace();
			return false;
		} catch (ParserConfigurationException pe) {
			pe.printStackTrace();
			return false;
		}
	}

	public void characters(char[] ch, int start, int length)
			throws SAXException {
		if (isData) {
			m_buff.append(new String(ch, start, length));			
		}
	}

	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		if (qName.equals(NODE)) {
			isNode = false;
			nodeMap.put(id, currNode);
			m_graph.addNode(currNode);
			currNode = null;
		} else if(qName.equals(DATA)) {
			if(isNode) {
				if(0 < m_buff.length()) {
					currNode.addProperty(m_key, m_buff.toString());
					m_buff.delete(0, m_buff.length());
				} else {
					currNode.addProperty(m_key, "");
				}
			} else if(isEdge){
				if(0 < m_buff.length()) {
					currEdge.addProperty(m_key, m_buff.toString());
					m_buff.delete(0, m_buff.length());
				} else {
					currEdge.addProperty(m_key, "");
				}
			}
			isData = false;
			m_key = "";
		} else if(qName.equals(EDGE)) {
			isEdge = false;
			currEdge = null;
		}
	}

	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		try {
			if (qName.equals(NODE)) {
				isNode = true;
				currNode = (IProperty) data_type.newInstance();
				id = attributes.getValue("id");
				currNode.addProperty(Identifiable.PROP_ID, id);
			} else if (qName.equals(DATA)) {
				isData = true;
				m_key = attributes.getValue("key");
			} else if (qName.equals(EDGE)) {
				isEdge = true;
				String id1 = attributes.getValue("source");
				String id2 = attributes.getValue("target");
				IProperty node1 = (IProperty) nodeMap.get(id1);
				IProperty node2 = (IProperty) nodeMap.get(id2);
				currEdge = (IEdge)m_graph.addEdge(node1, node2);
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}
}
