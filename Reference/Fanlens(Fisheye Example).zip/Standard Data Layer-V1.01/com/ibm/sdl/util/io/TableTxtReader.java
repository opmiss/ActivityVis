/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.ITableData;
import com.ibm.sdl.data.table.impl.EntityTable;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IProperty;

public class TableTxtReader implements IDataReader {

	private ITableData m_table = null;
	private Class m_type = null;
	private Class[] m_scheme = null;
	
	public TableTxtReader(Class dataType) {
		m_type = dataType;
	}
	
	public TableTxtReader(Class[] scheme, Class dataType) {
		m_scheme = scheme;
		m_type = dataType;
	}
	
	public void setScheme(Class[] scheme) {
		m_scheme = scheme;
	}
	
	public boolean read(InputStream instream) {
		
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(instream));
			String line = null;
	
			line = reader.readLine();
			String[] header = line.split("\t");
	
			if(m_scheme == null) {
				m_scheme = new Class[header.length];
				for(int i = 0; i < header.length; ++i) {
					m_scheme[i] = String.class;
				}
			} else {
				if(m_scheme.length != header.length) {
					return false;
				}
			}
			
			m_table = new EntityTable(header, m_scheme);			
			
			IProperty row = null;
			while (null != (line = reader.readLine())) {
				String[] data = line.split("\t");
				row = (IProperty) m_type.newInstance();
				for(int i=0; i<data.length; i++){	
					row.addProperty(header[i], data[i]);
				}	
				((EntityTable)m_table).addRow(row);	
			}
			reader.close();
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} catch (InstantiationException e) {
			e.printStackTrace();
			return false;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			return false;
		} catch (InvalidateDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
			return false;
		}
	}

	public Object getData() {
		return m_table;
	}

	public Object getFilteredData(IItemFilter filter) {
		try {
			int size = m_table.getRowCount();
			
			String[] header = m_table.getColumnNames();
			
			if(m_scheme == null) {
				m_scheme = new Class[header.length];
				for(int i = 0; i < header.length; ++i) {
					m_scheme[i] = String.class;
				}
			} else {
				if(m_scheme.length != header.length) {
					return null;
				}
			}
			
			EntityTable t;
			
			t = new EntityTable(header, m_scheme);
			
			for(int i = 0; i < size; i++) {
				Object row = m_table.getRow(i);
				if(filter.accept(row)) {
					t.addRow(row);
				}
			}
			return m_table;
		} catch (InvalidateDataException e) {
			e.printStackTrace();
			return null;
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
			return null;
		}
	}

	public void reset() {
		this.m_scheme = null;
		this.m_table = null;
	}
	
	public void setNodeType(Class dataType) {
		m_type = dataType;
	}
	
	public void setEdgeType(Class type) {
	}
}
