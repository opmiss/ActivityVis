/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;
import java.util.StringTokenizer;

import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.Identifiable;

/**
 * 
 * @author Xijun Ma, Weijia Cai, Nan Cao
 *
 */

public class EntityTreeTextReader implements IDataReader {

	public static final String ID = Identifiable.PROP_ID;
	public static final String LEVEL = "level";
	public static final String NAME = IName.PROP_NAME;
	public static final String EMAIL = "email";
	public static final String TELEPHONE = "telephone";
	public static final String JOB_RESPONSIBIBLE = "job responsible";
	public static final String UID = "uid";
	
	private EntityTree m_tree = null;
	
	private Class node_type = null;
	
	private String cur_line;

	private int cur_level;

	private Object cur_parent;

	private Object pre_node;
	
	public EntityTreeTextReader(Class nodeType, Class edgeType){
		super();
		m_tree = new EntityTree();
		m_tree.setEdgeType(edgeType);
		node_type = nodeType;
	}
	
	public void setNodeType(Class dataType) {
		node_type = dataType;
	}
	
	public void setEdgeType(Class type) {
		if(null != m_tree) {
			m_tree.setEdgeType(type);
		}
	}
	
	public boolean read(InputStream instream) {
		try {
			InputStreamReader reader = new InputStreamReader(instream);
			read(reader);
			reader.close();
			
			m_tree.refresh();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public boolean read(Reader reader){
		try{
			BufferedReader br = new BufferedReader(reader);
			Stack stack = new Stack();

			// read data file
			// root
			cur_line = br.readLine();
			if (cur_line == null)
				return false;
			
//			count = 0;
			Object node = parseNode(cur_line);
			m_tree.setTreeRoot(node);
			
			cur_level = Integer.parseInt((String)PropOperator.getInstance().getProperty(EntityTreeTextReader.LEVEL, node));
			cur_parent = node;

			pre_node = node;
			
			cur_line = br.readLine();
			
			while (cur_line != null) {
				// parse a node
				try{
					node = parseNode(cur_line);
					
					int node_level = Integer.parseInt((String)PropOperator.getInstance().getProperty(EntityTreeTextReader.LEVEL, node));
	
					if (node_level > cur_level) {
						stack.push(cur_parent);
						cur_parent = pre_node;
					} else if (node_level < cur_level) {
						cur_parent = stack.pop();
						int cur_parent_level = Integer.parseInt((String)PropOperator.getInstance().getProperty(EntityTreeTextReader.LEVEL, cur_parent));
						while (node_level != (cur_parent_level + 1)) {
							cur_parent = stack.pop();
							cur_parent_level = Integer.parseInt((String)PropOperator.getInstance().getProperty(EntityTreeTextReader.LEVEL, cur_parent));
						}
					} else {
						
					}
					
					m_tree.addNode(node);
					m_tree.addEdge(cur_parent, node);
					pre_node = node;
					
					cur_level = node_level;
				}catch(Exception e){
					e.printStackTrace();
//					System.err.println("Error: " + cur_line);
				}
				cur_line = br.readLine();
			}
			
			br.close();
			
			return true;
		} catch (NumberFormatException e) {
			e.printStackTrace();
			return false;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	public Object parseNode(String line) {
		try {
			Object node = node_type.newInstance();
			
			String seperator = "###";
			int cur_pos;
			int cur_index;
			String level, name, email, phone, jobresponsib, uid;

			PropOperator.getInstance().setProperty(node, ID, "Node: " + node.hashCode());

			cur_pos = 0;
			cur_index = line.indexOf(seperator, cur_pos);
			level = line.substring(cur_pos, cur_index);
			PropOperator.getInstance().setProperty(node, LEVEL, level);

			cur_pos = cur_index + 3;
			cur_index = line.indexOf(seperator, cur_pos);
			name = line.substring(cur_pos, cur_index);
			PropOperator.getInstance().setProperty(node, NAME, name);
			
			cur_pos = cur_index + 3;
			cur_index = line.indexOf(seperator, cur_pos);
			email = line.substring(cur_pos, cur_index);
			PropOperator.getInstance().setProperty(node, EMAIL, email);
			
			cur_pos = cur_index + 3;
			cur_index = line.indexOf(seperator, cur_pos);
			phone = line.substring(cur_pos, cur_index);
			PropOperator.getInstance().setProperty(node, TELEPHONE, phone);
			
			cur_pos = cur_index + 3;
			cur_index = line.indexOf(seperator, cur_pos);
			
			jobresponsib = line.substring(cur_pos, cur_index);
			PropOperator.getInstance().setProperty(node, JOB_RESPONSIBIBLE, jobresponsib);
			
			cur_pos = cur_index + 3;
			cur_index = line.indexOf(seperator, cur_pos);
			
			uid = line.substring(cur_pos, cur_index);
			PropOperator.getInstance().setProperty(node, UID, uid);
			
			return node;
		} catch (Exception e) {
//			System.err.println("Error in: " + line);
			e.printStackTrace();
			return null;
		}
	}

	public void clear() {
		m_tree.clear();
	}
	
	public Object getData() {
		return m_tree;
	}

	/**
	 * Cannot be used in this loader
	 */
	public Object getFilteredData(IItemFilter filter) {
		return null;
	}
	
	
	private Object readTree(int depth, IItemFilter filter, String buffer, BufferedReader reader) throws IOException {
		StringTokenizer tok = new StringTokenizer(buffer, "#");
		
		int level = Integer.parseInt(tok.nextToken());
		String name = tok.nextToken();
		
		ArrayList children = new ArrayList();
		buffer = reader.readLine();

		while (buffer != null) {
			tok = new StringTokenizer(buffer, "#");
			level = Integer.parseInt(tok.nextToken());
			
			if (level > depth) {
				if (level == depth + 1) {
					Object node = readTree(level, filter, buffer, reader);
					if(null != filter) {
						if(filter.accept(node)) {
							m_tree.addNode(node);
							children.add(node);
						}
					} else {
						m_tree.addNode(node);
						children.add(node);
					}
				} else {
					System.out.println("Error in data.");
					break;
				}
			} else {
				break;
			}
		}
		
		try {
			Object node = null;
			Iterator it = children.iterator();
			node = node_type.newInstance();
			PropOperator.getInstance().setProperty(node, IName.PROP_NAME, name);
			while(it.hasNext()) {
				m_tree.addChild(node, it.next());
			}
			return node;
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
}
