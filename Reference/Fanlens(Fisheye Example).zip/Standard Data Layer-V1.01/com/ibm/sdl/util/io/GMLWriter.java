/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.OutputStream;

import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphData;
import com.ibm.sdl.util.PropOperator;

public class GMLWriter {

	protected static final String head = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	public GMLWriter() {
	}
	
	public void write(IGraphData graph, OutputStream os) throws IOException {
		if(null == graph) {
			return;
		}
		
		StringBuffer buff = new StringBuffer();
		
		os.write(head.getBytes());
		os.write("<graph>\n".getBytes());
		os.flush();
		
		// 1. write nodes
		int ncnt = graph.getNodeCount();
		Object node = null;
		Object[] keys = null;
		String id = null;
		for(int i = 0; i < ncnt; ++i) {
			node = graph.getNode(i);
			id = PropOperator.getInstance().getID(node);
			buff.append("\t\t<node id=\"" + id + "\">\n");
			keys = PropOperator.getInstance().getKeyCollection(node);
			for(int j = 0; j < keys.length; ++j) {
				buff.append("\t\t<data key=\"" + keys[i] + ">" + 
						PropOperator.getInstance().getString((String)keys[i], node) 
						+ "</data>\n");
			}
			buff.append("\t\t</node>\n");
		}
		
		os.write(buff.toString().getBytes());
		os.flush();
		
		buff.delete(0, buff.length() - 1);
		
		// 2. write edges
		IEdge edge = null;
		Object n1 = null, n2 = null;
		String id1 = null, id2 = null;
		int ecnt = graph.getEdgeCount();
		for(int i = 0; i < ecnt; ++i) {
			edge = graph.getEdge(i);
			n1 = edge.getFirstNode();
			n2 = edge.getSecondNode();
			id1 = PropOperator.getInstance().getID(n1);
			id2 = PropOperator.getInstance().getID(n2);
			buff.append("\t<edge source=\"" + id1 + "\" target = \"" + id2 + "\"></edge>\n");
		}
		
		os.write("</graph>\n".getBytes());
		os.flush();
		os.close();		
	}
}
