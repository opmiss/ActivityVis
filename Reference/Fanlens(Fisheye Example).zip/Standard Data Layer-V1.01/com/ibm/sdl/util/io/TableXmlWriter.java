/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.util.io;

import java.io.IOException;
import java.io.OutputStream;

import com.ibm.sdl.data.api.IColumn;
import com.ibm.sdl.data.api.ITableData;
import com.ibm.sdl.data.table.column.impl.BooleanColumn;
import com.ibm.sdl.data.table.column.impl.DateColumn;
import com.ibm.sdl.data.table.column.impl.DoubleColumn;
import com.ibm.sdl.data.table.column.impl.IntColumn;
import com.ibm.sdl.data.table.column.impl.LongColumn;
import com.ibm.sdl.data.table.column.impl.ObjectColumn;
import com.ibm.sdl.data.table.column.impl.StringColumn;

public class TableXmlWriter {

	protected static final String head = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
	public TableXmlWriter() {
	}
	
	public void write(ITableData table, OutputStream os) throws IOException {
		
		if(null == table) {
			return;
		}
		
		os.write(head.getBytes());
		os.write("<table>\n".getBytes());
		os.flush();
		// 1. write the schemes
		
		IColumn[] columns = table.getColumns();
		String temp = "\t<scheme count = \"" + columns.length + "\">\n"; 
		os.write(temp.getBytes());
		for(int i = 0; i < columns.length; ++i) {
			String type = "object";
			if(columns[i] instanceof BooleanColumn) {
				type = "boolean"; 
			} else if(columns[i] instanceof DateColumn) {
				type = "date";
			} else if(columns[i] instanceof DoubleColumn) {
				type = "double";
			} else if(columns[i] instanceof IntColumn) {
				type = "integer";
			} else if(columns[i] instanceof LongColumn) {
				type = "long";
			} else if(columns[i] instanceof StringColumn) {
				type = "string";
			} else if(columns[i] instanceof ObjectColumn) {
				type = "object";
			}
			String scheme = "\t\t<column " + " sn = \"" + i + "\" name = \"" + columns[i].getName() + "\" type = \"" + type + "\"/>\n";
			os.write(scheme.getBytes());
		}
		
		os.write("\t</scheme>\n".getBytes());
		os.flush();
		
		int size = table.getRowCount();
		table.getColumns();
		StringBuffer buff = new StringBuffer();
		for(int i = 0; i < size; ++i) {
			os.write("\t<row>\n".getBytes());
			for(int j = 0; j < columns.length; ++j) {
				String value = "";
				if(columns[j] instanceof BooleanColumn) {
					value = "" + columns[j].getBoolean(i);
				} else if(columns[j] instanceof DateColumn) {
					value = "" + columns[j].getDate(i);
				} else if(columns[j] instanceof DoubleColumn) {
					value = "" + columns[j].getDouble(i);
				} else if(columns[j] instanceof IntColumn) {
					value = "" + columns[j].getInt(i);
				} else if(columns[j] instanceof LongColumn) {
					value = "" + columns[j].getLong(i);
				} else if(columns[j] instanceof StringColumn) {
					value = "" + columns[j].getString(i);
				} else if(columns[j] instanceof ObjectColumn) {
					value = "" + columns[j].getObject(i);
				}
				
				buff.append("\t\t<column sn = \"" + j + "\">\n");
				buff.append("\t\t\t<![CDATA[");
				buff.append(value);
				buff.append("]]>\n");
				buff.append("\t\t</column>\n");
				os.write(buff.toString().getBytes());
				
				buff.delete(0, buff.length());
			}
			os.write("\t</row>\n".getBytes());
			os.flush();
		}
		
		os.write("</table>\n".getBytes());
		os.flush();
		os.close();
	}
}
