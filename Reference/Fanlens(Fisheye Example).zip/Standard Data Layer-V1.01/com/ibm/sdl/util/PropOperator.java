/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss(jesse.kriss@us.ibm.com), CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util;

import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.IProperty;
import com.ibm.sdl.util.prop.ITooltip;
import com.ibm.sdl.util.prop.IType;
import com.ibm.sdl.util.prop.IWeight;
import com.ibm.sdl.util.prop.Identifiable;

public class PropOperator implements IPropExtractor {

	protected static IPropExtractor extractor = null;
	
	public PropOperator() {
	}
	
	public static IPropExtractor getInstance() {
		if(null == extractor) {
			extractor = new PropOperator();
		}
		return extractor;
	}
	
	/**
	 * Check if the class1 is the subclass of class2
	 * 
	 * @param class1
	 * @param class2
	 * @return
	 */
	public static boolean isSubClassOf(Class class1, Class class2) {
		if(class1 == null) {
			return false;
		}
		
		if(class2.equals(class1)) {
			return true;
		} else {
			return isSubClassOf(class1.getSuperclass(), class2);
		}
	}
	
	public String getID(Object data) {
		if(data instanceof Identifiable) {
			return ((Identifiable)data).getID();
		} else {
			Object id = getProperty(Identifiable.PROP_ID, data);
			if(id == null) {
				id = getProperty("id", data);
			}
			return id == null ? null : id.toString();
		}
	}
	
	public String getName(Object data) {
		if(data instanceof IName) {
			return ((IName)data).getName();
		} else {
			Object name = getProperty(IName.PROP_NAME, data);
			return name == null ? "" : (String)name;
		}
	}
	
	public String getType(Object data) {
		if(data instanceof IType) {
			return ((IType)data).getType();
		} else {
			Object type = getProperty(IType.PROP_TYPE, data);
			return type == null ? null : (String)type;
		}
	}
	
	public double getWeight(Object data) {
		double weight = 0D;
		if(data instanceof IWeight) {
			weight = ((IWeight)data).getWeight(); 
		} else {
			Object w = getProperty(IWeight.PROP_WEIGHT, data);
			if(w instanceof String) {
				weight = Double.parseDouble((String)w);
			} else if(w instanceof Number) {
				if(w instanceof Integer) {
					weight = ((Integer)w).intValue();
				} else if (w instanceof Float){
					weight = ((Float)w).floatValue();
				} else if (w instanceof Double) {
					weight = ((Double)w).doubleValue();
				} else if (w instanceof Long) {
					weight = ((Long)w).longValue();
				} else if (w instanceof Short) {
					weight = ((Short)w).shortValue();
				}
			} else {
				weight = 0D;
			}
		}
		return weight;
	}
	
	public void setWeight(Object data, double weight) {
		if(data instanceof IWeight) {
			((IWeight)data).setWeight(weight); 
		} else {
			setProperty(data, IWeight.PROP_WEIGHT, new Double(weight));
		}
	}
	
	public String getTooltip(Object data) {
		if(data instanceof ITooltip) {
			return ((ITooltip)data).getTooltip();
		} else {
			Object tip = getProperty(ITooltip.PROP_TOOLTIP, data);
			return tip == null ? null : (String)tip;
		}
	}
	
	public Object getProperty(Object key, Object data) {
		if(data instanceof IProperty) {
			return ((IProperty)data).getProperty(key);
		} else if(data instanceof Map) {
			return ((Map)data).get(key);
		} else if(data instanceof Hashtable) {
			return ((Hashtable)data).get(key);
		}
		
		return null;
	}
	
	public void setProperty(Object data, Object key, Object value) {
		if(data instanceof IProperty) {
			((IProperty)data).addProperty(key, value);
		} else if(data instanceof Map) {
			((Map)data).put(key, value);
		} else if(data instanceof Hashtable) {
			((Hashtable)data).put(key, value);
		}
	}
	
	public void removeProperty(Object data, Object key) {
		if(data instanceof IProperty) {
			((IProperty)data).removeProperty(key);
		} else if(data instanceof Map) {
			((Map)data).remove(key);
		} else if(data instanceof Hashtable) {
			((Hashtable)data).remove(key);
		}
	}
	
	public Object[] getKeyCollection(Object data) {
		
		if(data instanceof IProperty) {
			return ((IProperty)data).getKeyCollection();
		} else if(data instanceof Map) {
			return ((Map)data).keySet().toArray();
		} else if(data instanceof Hashtable) {
			return ((Hashtable)data).keySet().toArray();
		}
		
		return null;
	}
	
	public Object[] getValueCollection(Object data) {
		
		if(data instanceof IProperty) {
			return ((IProperty)data).getValueCollection();
		} else if(data instanceof Map) {
			return ((Map)data).values().toArray();
		} else if(data instanceof Hashtable) {
			return ((Hashtable)data).values().toArray();
		}
		return null;
	}
	
	public void clear(Object data) {
		if(data instanceof IProperty) {
			((IProperty)data).clear();
		} else if(data instanceof Map) {
			((Map)data).clear();
		} else if(data instanceof Hashtable) {
			((Hashtable)data).clear();
		}
	}

	public double getDouble(Object key, Object data) {
		Object value = getProperty(key, data);
		
		if(null == value) {
			return 0;
		} else if(value instanceof Number) {
			return ((Number)value).doubleValue();
		} else if(value instanceof String) {
			return Double.parseDouble((String)value);
		} else {
			return 0;
		}
	}

	public float getFloat(Object key, Object data) {
		Object value = getProperty(key, data);
		
		if(null == value) {
			return 0;
		} else if(value instanceof Number) {
			return ((Number)value).floatValue();
		} else if(value instanceof String) {
			return Float.parseFloat((String)value);
		} else {
			return 0;
		}
	}

	public String getString(Object key, Object data) {
		Object value = getProperty(key, data);
		
		if(null == value) {
			return null;
		} else if(value instanceof String) {
			return (String)value;
		} else {
			return value.toString();
		}
	}

	public long getLong(Object key, Object data) {
		Object value = getProperty(key, data);
		if(null == value) {
			return 0;
		} else if(value instanceof Number) {
			return ((Number)value).longValue();
		} else if(value instanceof String) {
			return Long.parseLong((String)value);
		} else {
			return 0;
		}
	}

	public int getInteger(Object key, Object data) {
		Object value = getProperty(key, data);
		
		if(null == value) {
			return 0;
		} else if(value instanceof Number) {
			return ((Number)value).intValue();
		} else if(value instanceof String) {
			return Integer.parseInt((String)value);
		} else {
			return 0;
		}
	}

	public Date getDate(Object key, Object data) {
		Object value = getProperty(key, data);
		
		if(null == value) {
			return null;
		} else if(value instanceof Date) {
			return (Date)value;
		} else {
			return null;
		}
	}
}
