/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss(jesse.kriss@us.ibm.com), CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.util;

public class DoubleRange {

	private double min, max;
	
	boolean empty = true;
	
	public DoubleRange() {
	}
	
	public DoubleRange(double min, double max) {
		setMin(min);
		setMax(max);
	}
	
	public void setMin(double min) {
		this.min = min;
	}
	
	public void setMax(double max) {
		this.max = max;
	}
	
	public void clear() {
		empty = true;
	}
	
	public void add(double d) {
		if (empty) {
			empty = false;
			min = d;
			max = d;
		}
		min = (d < min) ? d : min;
		max = (d > max) ? d : max;
	}
	
	public double getMin() {
		return min;
	}
	
	public double getMax() {
		return max;
	}
	
	public String toString() {
		return min + " to " + max;
	}
}
