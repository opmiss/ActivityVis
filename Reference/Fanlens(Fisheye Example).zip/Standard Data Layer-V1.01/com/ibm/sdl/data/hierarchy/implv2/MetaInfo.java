package com.ibm.sdl.data.hierarchy.implv2;


public class MetaInfo {


	public Object start = null;
	public Object end = null;
	
	public int height = 0;
	
	public int weight = 1;
	
	public boolean collapsed = false;
	public MetaInfo(MetaInfo m) {
		start = m.start;
		end = m.end;
		height = m.height;
		weight = m.weight;
		collapsed = m.collapsed;
	}
	public MetaInfo(){
		
	}
}
