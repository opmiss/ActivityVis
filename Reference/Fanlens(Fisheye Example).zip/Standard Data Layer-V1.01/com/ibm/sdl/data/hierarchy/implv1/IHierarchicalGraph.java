/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.hierarchy.implv1;

import com.ibm.sdl.data.api.IGraphDataEx;

public interface IHierarchicalGraph extends IHierarchy {

	public IGraphDataEx getSubGraph(Object parent);
	
	public IGraphDataEx getSubGraph(int height);
	
	public void clusterEdges(int height);
	
	public IGraphDataEx collapse(Object parent);
	
	public IGraphDataEx expand(Object parent);
	
}
