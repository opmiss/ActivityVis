package com.ibm.sdl.data.hierarchy.implv3;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphData;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;

public class ViewGraph extends EntityGraph implements IViewGraph {
	
	private static final long serialVersionUID = -6301133442154419166L;

	private IHierarchicalGraph hierarchy;
//	private Map collapsed = new HashMap();
	private Set collapsed = new HashSet();
	
	private String[] attrs;
	private double[] mx;
	private double[] mn;
	
	@SuppressWarnings("unchecked")
	public ViewGraph(IHierarchicalGraph hierarchy, String[] attrs, Class edgeType) {
		this.hierarchy = hierarchy;
		setNumericAttr(attrs);
		setEdgeType(edgeType);
		
		mx = new double[attrs.length];
		mn = new double[attrs.length];
		Arrays.fill(mx, Double.MIN_VALUE);
		Arrays.fill(mn, Double.MAX_VALUE);
		
		IGraphData baseGraph = ((HierarchicalGraph)hierarchy).getGraph();
		int numNodes = baseGraph.getNodeCount();
		for (int i = 0; i < numNodes; ++i) {
			Object node = baseGraph.getNode(i);
			addNode(node);
//			collapsed.put(node, false);
			for (int j = 0; j < attrs.length; ++j) {
				double val = getAttr(node, attrs[i]);
				mx[j] = Math.max(mx[j], val);
				mn[j] = Math.min(mn[j], val);
			}
		}
		int numEdges = baseGraph.getEdgeCount();
		for (int i = 0; i < numEdges; ++i) {
			IEdge edge = baseGraph.getEdge(i);
			addEdge(edge.getFirstNode(), edge.getSecondNode());
		}
	}
	
	public IViewGraph expand(Object node) {
		if (!isCollapsed(node))
			return this;
		
		setCollapsed(node, false);
		
		for (Object e : (List) m_edgesFromNode1.get(node)) 
			for (Object v : hierarchy.expandEdge((IEdge) e, node)) {
				if (contains(v))
					addNode(v);
				addEdge(v, ((IEdge) e).getSecondNode());
			}

		for (Object e : (List) m_edgesFromNode2.get(node)) 
			for (Object v : hierarchy.expandEdge((IEdge) e, node)) {
				if (!contains(v));
					addNode(v);
				addEdge(v, ((IEdge) e).getFirstNode());
			}
		
		removeNode(node); // also remove the adjacent edges
		
		int numNodes = getNodeCount();
		for (int i = 0; i < numNodes; ++i) {
			Object v = getNode(i);
			for (int j = 0; j < attrs.length; ++j) {
				double val = PropOperator.getInstance().getDouble(attrs[j], v);
				mx[j] = Math.max(mx[j], val);
				mn[j] = Math.min(mn[j], val);
			}
		}
		
		return this;
	}
	
	@SuppressWarnings("unchecked")
	public IViewGraph collapse(Object node) {
		if (isCollapsed(node))
			return this;
		
		setCollapsed(node, true);
		
		for (int j = 0; j < attrs.length; ++j) {
			double val = getAttr(node, attrs[j]);
			mx[j] = Math.max(mx[j], val);
			mn[j] = Math.min(mn[j], val);
		}
		
		Set nbrs = new HashSet();
		Object[] children = hierarchy.getSubNodes(node);
		int numNodes = getNodeCount();
		for (int i = 0; i < children.length; ++i)
			for (int j = 0; j < numNodes; ++j) {
				Object v = getNode(j);
				if (hierarchy.inducedEdge(children[i], v))
					nbrs.add(v);
			}
		for (Object v : nbrs)
			addEdge(node, v);
		return this;
	}
	
	// query
	
	private static double getAttr(Object node, String attr) {
		return PropOperator.getInstance().getDouble(attr, node);
	}
	
	@SuppressWarnings("unchecked")
	public void setCollapsed(Object node, boolean coll) {
		if (coll)
			collapsed.add(node);
		else
			collapsed.remove(node);
//		collapsed.put(node, flag);
	}
	
	public boolean isCollapsed(Object node) {
		return collapsed.contains(node);
//		return collapsed.get(node);
	}
	
	public double getMaxWeight(String attr) {
		int i = indexOf(attr);
		if (i == -1)
			throw new InvalidArgumentsException("invalid attribute");
		return mx[i];
	}

	public double getMinWeight(String attr) {
		int i = indexOf(attr);
		if (i == -1)
			throw new InvalidArgumentsException("invalid attribute");
		return mn[i];
	}
	
	private int indexOf(String attr) {
		for (int i = 0; i < attrs.length; ++i)
			if (attrs[i].equals(attr))
				return i;
		return -1;
	}

	public String[] getNumericAttr() {
		return attrs;
	}

	public void setNumericAttr(String[] attrs) {
		this.attrs = attrs;
	}

	/**
	 * clear the view
	 */
	public void reset() {
		// TODO Auto-generated method stub
		
	}

	public void setMaxCellWeight(double weight) {
		// TODO Auto-generated method stub
		
	}

	public void setMaxEdgeWeight(double weight) {
		// TODO Auto-generated method stub
		
	}

	public void setMinCellWeight(double weight) {
		// TODO Auto-generated method stub
		
	}

	public void setMinEdgeWeight(double weight) {
		// TODO Auto-generated method stub
		
	}
	
	// listener action

	public void dataCleared(DataEvent e) {
		
	}

	public void dataRefreshed(DataEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void itemAdded(DataEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void itemChanged(DataEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void itemRemoved(DataEvent e) {
		// TODO Auto-generated method stub
		
	}
}
