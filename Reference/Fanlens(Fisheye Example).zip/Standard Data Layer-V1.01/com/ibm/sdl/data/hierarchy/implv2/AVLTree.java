package com.ibm.sdl.data.hierarchy.implv2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibm.sdl.data.AbstractData;
import com.ibm.sdl.data.graph.impl.Edge;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.prop.Property;

public class AVLTree extends AbstractData implements BalancedSearchTree {

	private static final long serialVersionUID = -9117938897631804107L;

	public static final String PROP_TREENODE_HEIGHT = "#HEIGHT#";

	protected Object m_root = null;

	public Map TAG = null;

	protected List m_nodes = new ArrayList(0);
	protected Map m_rightChild = new HashMap(0);
	protected Map m_leftChild = new HashMap(0);
	protected Map m_parent = new HashMap(0);
	protected Map m_balance = new HashMap(0);

	protected Class edgeType = null;
	protected Comparator m_comparator = null;

	public AVLTree() {
		this(null);
	}

	public AVLTree(Comparator c) {
		m_comparator = c;
	}

	public void setEdgeType(Class type) {
		edgeType = type;
	}

	public void setComparator(Comparator c) {
		m_comparator = c;
	}

	public Comparator getComparator() {
		return m_comparator;
	}

	public Object getTreeRoot() {
		return m_root;
	}

	public boolean isEmpty() {
		return m_nodes.isEmpty();
	}

	public boolean contains(Object elem) {
		boolean flag = m_nodes.contains(elem);
		return flag;
	}

	public Object getParent(Object elem) {
		return m_parent.get(elem);
	}

	public Object getLeftChild(Object elem) {
		if (null == elem)
			return null;
		return m_leftChild.get(elem);
	}

	public Object getRightChild(Object elem) {
		if (null == elem)
			return null;
		return m_rightChild.get(elem);
	}

	public Object[] getNodes() {
		return m_nodes.toArray();
	}

	public void insertNode(Object elem) {
		if (null == elem)
			return;

		m_root = insert(elem, m_root);
		m_parent.remove(m_root);
	}

	public void removeNode(Object elem) {
		if (null == elem)
			return;

		m_root = remove(elem, m_root);
		m_parent.remove(m_root);
	}

	public boolean containsNode(Object elem) {
		if (null == m_root)
			return false;

		Object current = m_root;
		do {
			int r = m_comparator.compare(elem, current);
			if (r > 0)
				current = getRightChild(current);
			else if (r < 0)
				current = getLeftChild(current);
			else
				return true;
		} while (current != null);

		return current != null;
	}

	public Object findMax() {
		return findMax(m_root);
	}

	public Object findMin() {
		return findMin(m_root);
	}

	public Object findMax(Object elem) {
		if (elem == null)
			return elem;

		Object node = elem;
		Object child = elem;
		do {
			node = child;
			child = getRightChild(node);
		} while (child != null);

		return node;
	}

	public Object findMin(Object elem) {
		if (elem == null)
			return elem;

		Object node = elem;
		Object child = getLeftChild(node);
		while (child != null) {
			node = child;
			child = getLeftChild(node);
		}

		return node;
	}
	/**
	 * @return The most closest node in the tree.
	 */
	public Object findSucc(Object elem) {
		if (elem == null || null == m_root)
			return null;

		Object current = null;
		Object child = m_root;
		int r = 0;
		do {
			current = child;
			r = m_comparator.compare(elem, current);
			if (r < 0) {
				child = getLeftChild(current);
			} else if(r>0) {
				child = getRightChild(current);
			}else {
				return current;
			}
		} while (child != null);

		do {
			r = m_comparator.compare(elem, current);
			if (r < 0) {
				break;
			} else if(r>0){
				current = getParent(current);
			}else{
				return current;
			}
		} while (null != current);

		return current;
	}

	/***************************************************************************
	 * Inner Operation
	 **************************************************************************/
	protected Object insert(Object elem, Object node) {
		if (null == elem)
			return null;

		Object lChild = null;
		Object rChild = null;
		int lh = 0;
		int rh = 0;

		// insert into the left child tree
		if (null == node) {
			addNode(elem);
			node = elem;
		}
		// insert into the left child tree
		else if (m_comparator.compare(elem, node) < 0) {
			lChild = getLeftChild(node);
			rChild = getRightChild(node);

			lChild = insert(elem, lChild);
			setLeftChild(node, lChild);

			lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					lChild);
			rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					rChild);

			if ((lh - rh) > 1) {
				if (m_comparator.compare(elem, lChild) < 0)
					node = rotateLeftChild(node);
				else
					node = doubleRotateLeftChild(node);
			}
		}
		// insert into the right child tree
		else if (m_comparator.compare(elem, node) > 0) {
			lChild = getLeftChild(node);
			rChild = getRightChild(node);

			rChild = insert(elem, rChild);
			setRightChild(node, rChild);

			lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					lChild);
			rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					rChild);

			if ((rh - lh) > 1) {
				if (m_comparator.compare(elem, rChild) > 0)
					node = rotateRightChild(node);
				else
					node = doubleRotateRightChild(node);
			}
		}

		lChild = getLeftChild(node);
		rChild = getRightChild(node);
		lh = PropOperator.getInstance()
				.getInteger(PROP_TREENODE_HEIGHT, lChild);
		rh = PropOperator.getInstance()
				.getInteger(PROP_TREENODE_HEIGHT, rChild);
		PropOperator.getInstance().setProperty(node, PROP_TREENODE_HEIGHT,
				Math.max(lh, rh) + 1);

		return node;
	}

	protected Object remove(Object elem, Object node) {
		if (null == elem)
			return null;

		Object lChild = null;
		Object rChild = null;
		int lh = 0;
		int rh = 0;

		// NULL??
		if (null == node) {
			// addNode(elem);
			// node = elem;
		}
		// delete the current node
		else if (m_comparator.compare(elem, node) == 0) {
			lChild = getLeftChild(node);
			rChild = getRightChild(node);

			if (null == lChild && null == rChild)
				m_nodes.remove(elem);
			else if (null != lChild) {
				node = findMax(lChild);

				lChild = remove(node, lChild);
				setLeftChild(node, lChild);

			} else if (null != rChild) {
				node = findMin(rChild);

				rChild = remove(node, rChild);
				setRightChild(node, rChild);
			}
			node = null;
		}
		// delete from the left child tree
		else if (m_comparator.compare(elem, node) < 0) {
			lChild = getLeftChild(node);
			rChild = getRightChild(node);

			lChild = remove(elem, lChild);
			setLeftChild(node, lChild);

			lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					lChild);
			rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					rChild);

			if ((lh - rh) > 1) {
				if (m_comparator.compare(elem, lChild) < 0)
					node = rotateLeftChild(node);
				else
					node = doubleRotateLeftChild(node);
			}
		}
		// delete from the right child tree
		else if (m_comparator.compare(elem, node) > 0) {
			lChild = getLeftChild(node);
			rChild = getRightChild(node);

			rChild = remove(elem, rChild);
			setRightChild(node, rChild);

			lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					lChild);
			rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
					rChild);

			if ((rh - lh) > 1) {
				if (m_comparator.compare(elem, rChild) > 0)
					node = rotateRightChild(node);
				else
					node = doubleRotateRightChild(node);
			}
		}

		lChild = getLeftChild(node);
		rChild = getRightChild(node);
		lh = PropOperator.getInstance()
				.getInteger(PROP_TREENODE_HEIGHT, lChild);
		rh = PropOperator.getInstance()
				.getInteger(PROP_TREENODE_HEIGHT, rChild);
		PropOperator.getInstance().setProperty(node, PROP_TREENODE_HEIGHT,
				Math.max(lh, rh) + 1);

		return node;
	}

	protected Object rotateLeftChild(Object node) {
		Object lchild = getLeftChild(node);
		Object lrchild = getRightChild(lchild);
		setLeftChild(node, lrchild);
		setRightChild(lchild, node);

		int lh, rh;
		lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
				lrchild);
		rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
				getRightChild(node));
		PropOperator.getInstance().setProperty(node, PROP_TREENODE_HEIGHT,
				Math.max(lh, rh) + 1);

		lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
				getLeftChild(lchild));
		rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT, node);
		PropOperator.getInstance().setProperty(lchild, PROP_TREENODE_HEIGHT,
				Math.max(lh, rh) + 1);

		return lchild;
	}

	protected Object rotateRightChild(Object node) {
		Object rchild = getRightChild(node);
		Object rlchild = getLeftChild(rchild);

		setRightChild(node, rlchild);
		setLeftChild(rchild, node);

		int lh, rh;
		rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
				rlchild);
		lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
				getLeftChild(node));
		PropOperator.getInstance().setProperty(node, PROP_TREENODE_HEIGHT,
				Math.max(lh, rh) + 1);

		rh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT,
				getRightChild(rchild));
		lh = PropOperator.getInstance().getInteger(PROP_TREENODE_HEIGHT, node);
		PropOperator.getInstance().setProperty(rchild, PROP_TREENODE_HEIGHT,
				Math.max(lh, rh) + 1);

		return rchild;
	}

	protected Object doubleRotateLeftChild(Object node) {
		Object lchild = getLeftChild(node);
		lchild = rotateRightChild(lchild);
		setLeftChild(node, lchild);

		return rotateLeftChild(node);
	}

	protected Object doubleRotateRightChild(Object node) {
		Object child = getRightChild(node);
		child = rotateLeftChild(child);
		setRightChild(node, child);

		return rotateRightChild(node);
	}

	/**
	 * Structual Operations
	 * 
	 * @param node
	 * @return
	 */
	protected Object addNode(Object node) {
		m_nodes.add(node);
		return node;
	}

	protected void setLeftChild(Object node1, Object node2) {
		if (m_leftChild.containsKey(node1)) {
			m_leftChild.remove(node1);
		}
		if (m_parent.containsKey(node2)) {
			m_parent.remove(node2);
		}
		m_leftChild.put(node1, node2);
		m_parent.put(node2, node1);

	}

	protected void setRightChild(Object node1, Object node2) {
		if (m_rightChild.containsKey(node1)) {
			m_rightChild.remove(node1);
		}
		if (m_parent.containsKey(node2)) {
			m_parent.remove(node2);
		}
		m_rightChild.put(node1, node2);
		m_parent.put(node2, node1);
	}

	/**
	 * Test Operations
	 */
	public void printTree(Object node) {
		if (node != null) {
			Object lChild = getLeftChild(node);
			Object rChild = getRightChild(node);

			printTree(lChild);
			if (null != TAG)
				System.out.println(node + " value = " + TAG.get(node));
			else
				System.out.println(node);
			printTree(rChild);
		}
	}

	public void printNodeHeight() {

		for (int i = 0; i < m_nodes.size(); i++) {
			int height = PropOperator.getInstance().getInteger(
					PROP_TREENODE_HEIGHT, m_nodes.get(i));
			int value = PropOperator.getInstance().getInteger("value",
					m_nodes.get(i));
			System.out.println("value = " + value);
			System.out.println("height = " + height);
		}
	}

	public static void main(String[] args) {
		AVLTree bst = new AVLTree();
		bst.setEdgeType(Edge.class);

		bst.setComparator(new Comparator() {

			public int compare(Object first, Object second) {
				double o1 = (Integer) PropOperator.getInstance().getProperty(
						"value", first);
				double o2 = (Integer) PropOperator.getInstance().getProperty(
						"value", second);
				if (o1 > o2)
					return 1;
				else if (o1 < o2)
					return -1;
				else
					return 0;
			}

		});

		Property p = null;
		for (int i = 0; i < 10; i++) {
			p = new Property() {
				public String toString() {
					return PropOperator.getInstance().getString("value", this);
				}
			};
			PropOperator.getInstance().setProperty(p, "value", i);
			bst.insertNode(p);
		}
		// System.out.println(bst.getNodes().length);
		//
		bst.printTree(bst.getTreeRoot());
		// bst.printNodeHeight();
		for (int i = 0; i < 10; i++) {

			p = new Property() {
				public String toString() {
					return PropOperator.getInstance().getString("value", this);
				}
			};
			int search = i;
			PropOperator.getInstance().setProperty(p, "value", search);
			System.out.println("search = " + search);
			System.out.println(bst.findSucc(p));
		}
	}
}