package com.ibm.sdl.data.hierarchy.implv2;


import java.util.Comparator;

public interface BalancedSearchTree {

	public void setEdgeType(Class type);
	
	public void setComparator(Comparator c);
	
	public Comparator getComparator();
	
	public Object getTreeRoot();
	
	public Object getParent(Object elem);
	
	public Object getLeftChild(Object elem);
	
	public Object getRightChild(Object elem);
	
	public Object[] getNodes();
	
	public void insertNode(Object elem);
	
	public void removeNode(Object elem);
	
	public boolean containsNode(Object elem);
	
	public Object findMax();
	
	public Object findMin();

	public Object findSucc(Object elem);
	
    /**
     * Find the min elem that bigger than the input elem,
     * if equal, return itself
     */
	public Object findMax(Object elem);

    /**
     * Find the max elem that lesser than the input elem
     */
	public Object findMin(Object elem);
}
