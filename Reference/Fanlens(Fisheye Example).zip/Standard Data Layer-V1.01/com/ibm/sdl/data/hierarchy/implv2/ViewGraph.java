package com.ibm.sdl.data.hierarchy.implv2;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;

public class ViewGraph extends EntityGraph implements IViewGraph {

	private static final long serialVersionUID = 1L;

	protected IHierarchicalGraph m_hgraph = null;
	
	protected Map STATUS = null;
	
	protected Map EWEIGHT = null;
	
	protected double m_nmax = -Double.MAX_VALUE;
	
	protected double m_nmin = Double.MAX_VALUE;
	
	protected double m_emax = -Double.MAX_VALUE;
	
	protected double m_emin = Double.MAX_VALUE;

	public ViewGraph() {
		this(null, null);
	}

	public ViewGraph(IHierarchicalGraph hgraph, Class edgeType) {
		STATUS = new HashMap();
		EWEIGHT = new HashMap();
		setEdgeType(edgeType);
		setHierarchicalGraph(hgraph);
	}

	public void setHierarchicalGraph(IHierarchicalGraph hgraph) {
		super.clear();
		if(hgraph != null) {
			Object[] nodes = ((HierarchicalGraph)hgraph).getGraph().getNodes(
					null, null);
			if (null != nodes) {
				double w = 0;
				for (int i = 0; i < nodes.length; i++) {
					w = PropOperator.getInstance().getWeight(nodes[i]);
					m_nmax = Math.max(m_nmax, w);
					m_nmin = Math.min(m_nmin, w);
					add(nodes[i]);
				}
			}
			IEdge[] edges = ((HierarchicalGraph) hgraph).getGraph().getEdges(
					null, null);
			if (null != edges) {
				double w = 0;
				for (int i = 0; i < edges.length; i++) {
					add(edges[i].getFirstNode(), edges[i].getSecondNode());
					w = PropOperator.getInstance().getWeight(edges[i]);
					m_emax = Math.max(w, m_emax);
					m_emin = Math.min(w, m_emin);
				}
			}
		}
		m_hgraph = hgraph;
	}

	public IHierarchicalGraph getHierarchicalGraph() {
		return m_hgraph;
	}

	/***************************************************************************
	 * Navigational Operations
	 * 
	 * @throws InvalidateTypeException
	 **************************************************************************/
	public IViewGraph collapse(Object node) {
		if (m_hgraph.isLeaf(node))
			return this;

		double w = PropOperator.getInstance().getWeight(node);
		m_nmax = Math.max(w, m_nmax);
		m_nmin = Math.min(w, m_nmin);
		setCollapsed(node, true);
		
		Object[] children = m_hgraph.getSubNodes(node);
		m_nodes.add(node);
		Object child = null;
		List edges = null, temp = null;
		IEdge edge = null, etemp = null;;
		Object neighbour = null;
		HashSet adjacents1 = new HashSet(0);
		HashSet adjacents2 = new HashSet(0);
		double eweight = 0;
		int ecnt = 0;
		for (int i = 0; i < children.length; i++) {
			child = children[i];
			edges = (List)m_edgesFromNode1.get(child);
			if (null != edges) {
				ecnt = edges.size();
				for (int j = 0; j < ecnt; j++) {
					edge = (IEdge)edges.get(j);
					eweight = PropOperator.getInstance().getWeight(edge);
					EWEIGHT.put(edge.toString(), eweight);
					neighbour = edge.getSecondNode();
					if (!neighbour.equals(node)
							&& !m_hgraph.getParent(neighbour).equals(node)) {
						if (!adjacents1.contains(neighbour)) {
							adjacents1.add(neighbour);
							etemp = add(node, neighbour);
							PropOperator.getInstance().
								setWeight(etemp, eweight);
						} else {
							etemp = getEdge(node, neighbour);
						double ww = PropOperator.getInstance().getWeight(etemp);
						PropOperator.getInstance().
							setWeight(etemp, ww + eweight);
						}
					}
					temp = (List)m_edgesFromNode2.get(neighbour);
					if(temp != null && !temp.isEmpty()) {
						temp.remove(edge);
					}
					m_edges.remove(edge);
				}
				edges.clear();
			}

			edges = (List)m_edgesFromNode2.get(child);
			if (null != edges) {
				ecnt = edges.size();
				for (int j = 0; j < ecnt; j++) {
					edge = (IEdge)edges.get(j);
					eweight = PropOperator.getInstance().getWeight(edge);
					EWEIGHT.put(edge.toString(), eweight);
					neighbour = edge.getFirstNode();
					if (!neighbour.equals(node)
							&& !m_hgraph.getParent(neighbour).equals(node)) {
						double ww  = 0;
						if (!adjacents2.contains(neighbour)) {
							adjacents2.add(neighbour);
							etemp = add(neighbour, node);
							PropOperator.getInstance().
							setWeight(etemp, eweight);
						} else {
							etemp = getEdge(neighbour, node);
							ww = PropOperator.getInstance().getWeight(etemp);
							PropOperator.getInstance().
								setWeight(etemp, ww + eweight);
						}
						ww = PropOperator.getInstance(). getWeight(etemp);
						m_emax = Math.max(ww, m_emax);
						m_emin = Math.min(ww, m_emin);
					}
					temp = (List)m_edgesFromNode1.get(neighbour);
					if(temp != null && !temp.isEmpty()) {
						temp.remove(edge);
					}
					m_edges.remove(edge);
				}
				edges.clear();	
			}
			m_nodes.remove(child);
		}

		adjacents1.clear();
		adjacents2.clear();

		return this;
	}

	public IViewGraph expand(Object node) {
		if (m_hgraph.isLeaf(node))
			return this;

		Object parent = m_hgraph.getParent(node);
		Object[] children = null;

		IEdge[] edges = null;
		IEdge edge = null;
		Object neighbor = null;
		
		// Expand the edge with adjacent nodes
		edges = getEdgesWithFirstNode(node);
		if (null != edges) {
			for (int i = 0; i < edges.length; i++) {
				edge = edges[i];
				neighbor = edge.getSecondNode();
				if (!neighbor.equals(parent)
						&& !m_hgraph.getParent(neighbor).equals(node)) {
					children = m_hgraph.expandEdge(edge, node);
					remove(edge);
					for (int j = 0; j < children.length; ++j) {
						edge = add(children[j], neighbor);
						Double ww = (Double)EWEIGHT.remove(edge.toString());
						if(ww != null) {
							PropOperator.getInstance().
								setWeight(edge, ww.doubleValue());
						}
					}
				}
			}
		}

		edges = (IEdge[]) getEdgesWithSecondNode(node);
		if (null != edges) {
			for (int i = 0; i < edges.length; i++) {
				edge = edges[i];
				neighbor = edge.getFirstNode();
				if (!neighbor.equals(parent)
						&& !m_hgraph.getParent(neighbor).equals(node)) {
					children = m_hgraph.expandEdge(edge, node);
					remove(edge);
					for (int j = 0; j < children.length; ++j) {
						edge = add(neighbor, children[j]);		
						Double ww = (Double)EWEIGHT.remove(edge.toString());
						if(ww != null) {
							PropOperator.getInstance().
							setWeight(edge, ww.doubleValue());
						}
					}
				}
			}
		}
		
		// Generate the internal edges between the children
		children = m_hgraph.getSubNodes(node);
		for (int i = 0; i < children.length; i++) {
			add(children[i]);
			for (int j = i + 1; j < children.length; j++) {
				if (m_hgraph.inducedEdge(children[i], children[j])) {
					edge = add(children[i], children[j]);
					Double ww = (Double)EWEIGHT.remove(edge.toString());
					if(ww != null) {
						PropOperator.getInstance().
							setWeight(edge, ww.doubleValue());
					}
				} else if (m_hgraph.inducedEdge(children[j], children[i])) {
					edge = add(children[j], children[i]);
					Double ww = (Double)EWEIGHT.remove(edge.toString());
					if(ww != null) {
						PropOperator.getInstance().
							setWeight(edge, ww.doubleValue());
					}
				}
			}
		}
		
		setCollapsed(node, false);
		remove(node);

		return this;
	}

	public boolean isCollapsed(Object node) {
		ViewStatusItem item = getViewStatusItem(node);
		return item.isCollapsed;
	}

	public void setCollapsed(Object node, boolean bCollapsed) {
		ViewStatusItem item = getViewStatusItem(node);
		item.isCollapsed = bCollapsed;
	}

	public synchronized ViewStatusItem getViewStatusItem(Object node) {
		ViewStatusItem item = (ViewStatusItem)STATUS.get(node);
		if(null == item) {
			item = new ViewStatusItem();
			STATUS.put(node, item);
		}
		return item;
	}

	public void reset() {
		STATUS.clear();
		EWEIGHT.clear();
	}

	public double getMaxCellWeight() {
		return m_nmax;
	}

	public double getMinCellWeight() {
		return m_nmin;
	}
	
	public double getMaxEdgeWeight() {
		return m_emax;
	}
	
	public double getMinEdgeWeight() {
		return m_emin;
	}
	
	public void setMaxCellWeight(double weight) {
		m_nmax = weight;
	}
	
	public void setMinCellWeight(double weight) {
		m_nmin = weight;
	}
	
	public void setMaxEdgeWeight(double weight) {
		m_emax = weight;
	}
	
	public void setMinEdgeWeight(double weight) {
		m_emin = weight;
	}
}