package com.ibm.sdl.data.hierarchy.implv2;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.graph.impl.Edge;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.prop.IProperty;
import com.ibm.sdl.util.prop.Property;

public class Test {

	public static final String label = "Label";
	
	public static void main(String[] args) {
		
		Test.HGraphTest();
		
//		try {
//			Test.ViewGraphTest__WithComplicateEdges();
//		} catch (InvalidateTypeException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
	
	public static void ViewGraph() {
		
	}
	
	public static void HGraphTest() {
		AVLTree avl = new AVLTree();
		avl.setEdgeType(Edge.class);
		avl.setComparator(new Comparator() {

			public int compare(Object arg0, Object arg1) {
				int i = (Integer)arg0;
				int j = (Integer)arg1;
				
				if(i<j)
					return 1;
				else if(i<j)
					return -1;
				else
					return 0;
			}
			
		});
	
		for(int i=0; i< 100000; i++) {
			avl.insertNode(i);
		}

		System.out.println(avl.getNodes().length);
	}
	
	public static void ViewGraphTest__WithComplicateEdges() throws InvalidateTypeException {
		Object[] nodes = null;
		Object[] edges = null;
		
		/*********************
		 * Initialization Test
		 *********************/
		EntityGraph graph = new EntityGraph();
		graph.setEdgeType(Edge.class);
		
		HierarchicalGraph hgraph = new HierarchicalGraph(graph, null, Edge.class);

		Property root = new Property() {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		root.addProperty(label, "IBM");
		hgraph.setSuperNode(root);
		
		Property node1 = new Property()  {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		node1.addProperty(label, "Intern");
		Property node2 = new Property()  {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		node2.addProperty(label, "Contractor");
		Property node3 = new Property()  {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		node3.addProperty(label, "Regular");
		
		graph.addNode(node1);
		graph.addNode(node2);
		graph.addNode(node3);
		graph.addEdge(node1, node2);
		graph.addEdge(node1, node3);
		graph.addEdge(node2, node3);
		
//		hgraph.depthTraversalGraph();

//		nodes = graph.getNodes(null, null);
//		for(int i=0; i<nodes.length; i++) {
//			System.out.println(nodes[i]);
//		}
//		edges = graph.getEdges(null, null);
//		for(int i=0; i<edges.length; i++) {
//			System.out.println(edges[i]);
//		}
//		System.out.println("Node count = " + graph.getNodeCount());	
//		System.out.println("Edge count = " + graph.getEdgeCount());
		
		/*******************************
		 * Hirarchical Graph Test
		 *******************************/
		Property middle = new Property() {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		middle.addProperty(label, "middle");
		Property high = new Property() {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		high.addProperty(label, "high");
		Property another = new Property() {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		another.addProperty(label, "another");
		
		
//		//Split Test
		hgraph.split(middle, new Object[]{node1, node2});
		hgraph.split(high, new Object[]{middle});
		hgraph.split(another, new Object[]{node3});

		//Merge Test
//		hgraph.merge(high);
		
//		hgraph.printNodes();
//		hgraph.depthTraversalGraph();

//		nodes = hgraph.getNodes(null, null);
//		for(int i=0; i<nodes.length; i++) {
//			System.out.println(nodes[i]);
//		}
//		edges = hgraph.getEdges(null, null);
//		for(int i=0; i<edges.length; i++) {
//			System.out.println(edges[i]);
//		}
//		System.out.println("Node count = " + hgraph.getNodeCount());
//		System.out.println("Edge count = " + hgraph.getEdgeCount());

		/*******************************
		 * View Manager Test
		 *******************************/
//		IViewManager vManager = ViewManager.getInstance();
//		ViewManager.getInstance().setEdgeType(Edge.class);
//
//		IGraphDataEx view = vManager.getView(hgraph);
//		
//		//Collapse Test
//		view = vManager.collapse(hgraph, middle);
//		view = vManager.collapse(hgraph, another);
//		view = vManager.collapse(hgraph, high);
////		view = vManager.collapse(hgraph, root);
//		
//		//Expand Test
//		view = vManager.expand(hgraph, high);
//		view = vManager.expand(hgraph, middle);
//
//		nodes = view.getNodes(null, null);
//		for(int i=0; i<nodes.length; i++) {
//			System.out.println(nodes[i]);
//		}
//		edges = view.getEdges(null, null);
//		for(int i=0; i<edges.length; i++) {
//			System.out.println(edges[i]);
//		}
//		System.out.println("Node count = " + view.getNodeCount());	
//		System.out.println("Edge count = " + view.getEdgeCount());
	}

	public static void ViewGraphTest__WithOnlySimpleNodes() throws InvalidateTypeException {
		
		/*********************
		 * Initialization Test
		 *********************/
		EntityGraph graph = new EntityGraph();
		graph.setEdgeType(Edge.class);
		
		HierarchicalGraph hgraph = new HierarchicalGraph(graph, null, Edge.class);

		Property root = new Property() {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		root.addProperty(label, "Root");
		hgraph.setSuperNode(root);
		
		int count = 3;
		Property node = null;
		List leftHalf = new ArrayList();
		for(int i=0; i<count; i++) {
			node = new Property(){
				public String toString() {
					return (String)getProperty(label);
				}
			};
			node.addProperty(label, ""+i);
			graph.addNode(node);
			if(i<50) 
				leftHalf.add(node);
		}

		/*******************************
		 * Hirarchical Graph Test
		 *******************************/
		Property middle = new Property() {
			public String toString() {
				return (String)getProperty(label);
			}
		};
		middle.addProperty(label, "Middle");
		
		//Split Test
		hgraph.split(middle, leftHalf.toArray());

		//Merge Test
//		hgraph.merge(middle);
		
//		hgraph.printNodes();
//		hgraph.depthTraversalGraph();

		/*******************************
		 * View Manager Test
		 *******************************/
//		ViewGraph vgraph = ViewManager.getInstance();
//
//		IGraphDataEx view = vManager.getView(hgraph);
//		
//		//Collapse Test
//		view = vManager.collapse(hgraph, middle);
//
//		//Expand Test
//		view = vManager.expand(hgraph, middle);
//		
//		System.out.println("Node count = " + view.getNodeCount());	
//		System.out.println("Edge count = " + view.getEdgeCount());
	}
	
	public static void EntityGraphTest() {
		EntityGraph graph = new EntityGraph();
		graph.setEdgeType(Edge.class);
		
			Object node = new Object();
			graph.addNode(node);
			graph.addNode(node);
			graph.addNode(node);
			graph.addNode(node);
	}
	
	public static void HierarchicalGraphTest() {
		EntityGraph graph = new EntityGraph();
		graph.setEdgeType(Edge.class);
		
		Property root = new Property();
		
		
		IHierarchicalGraph hgraph = new HierarchicalGraph(graph,null,Edge.class);
		hgraph.setSuperNode(root);
		IHierarchicalGraph hgraph2 = new HierarchicalGraph(graph,null,Edge.class);
		hgraph2.setSuperNode(root);
		
		graph.addDataListener(hgraph);
		graph.addDataListener(hgraph2);
		
		long t1 = System.currentTimeMillis();
		int times = 1000;
		IProperty node = null;
		List test = new ArrayList(0);
		for(int i=0; i<times; i++) {
			node = new Property(){
				public String toString(){
					return getProperty("name").toString();
				}
			};
			node.setProperty("name", i);
			
			try {
				hgraph.addNode(node);
			} catch (InvalidateTypeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		int size = test.size();
		for(int i=0; i<size; i++) {
			hgraph.merge(test.get(size - i -1));
		}

		long t2 = System.currentTimeMillis();
		System.out.println("Time Cost = " + (t2-t1));

	}
}
