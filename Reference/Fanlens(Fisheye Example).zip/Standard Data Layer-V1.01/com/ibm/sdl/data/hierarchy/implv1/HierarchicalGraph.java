/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.hierarchy.implv1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibm.sdl.data.AbstractData;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.prop.IWeight;

public class HierarchicalGraph extends AbstractData implements IHierarchicalGraph {

	private static final long serialVersionUID = 82711669084260116L;
	
	private List m_graphs = null;
	
	private Object m_super = null;
	
	private Class m_edgeType = null;
	
	private Map m_pool = null;
	
	private Map m_map = null;

	public HierarchicalGraph() {
		this(null);
	}
	
	public HierarchicalGraph(IGraphDataEx graph) {
		m_graphs = new ArrayList(0);
		m_pool = new HashMap(0);
		m_map = new HashMap(10);
		setGraph(graph);
	}
	
	public void setEdgeType(Class type) {
		m_edgeType = type;
	}
	
	public void setGraph(IGraphDataEx graph) {
		
		if(null == graph) return;
		
		clear();
		
		IEdge[] edges = graph.getEdges(null, null);
		Object[] nodes = graph.getNodes(null, null);
		
		EntityGraph ginit = getGraph(0, true);
		ginit.setEdgeType(m_edgeType);
		
		HierarchicalNode hn = null;
		for(int i = 0; i < nodes.length; ++i) {
			hn = new HierarchicalNode();
			hn.setObject(nodes[i]);
			hn.setHeight(0);
			hn.setParent(null);
			ginit.addNode(nodes[i]);
			m_map.put(nodes[i], hn);
		}
		
		Object n1 = null;
		Object n2 = null;
		for(int i = 0; i < edges.length; ++i) {
			n1 = edges[i].getFirstNode();
			n2 = edges[i].getSecondNode();
			ginit.addEdge(n1, n2);
		}
	}
		
	public IGraphDataEx getSubGraph(Object parent) {
		try {
			HierarchicalNode p = null;
			if(parent instanceof HierarchicalNode) {
				p = (HierarchicalNode)parent;
			} else {
				p = getHierarchicalNode(parent);
			}
			
			if(p == null || p.isLeaf()) {
				return null;
			}
			
			EntityGraph subgraph = (EntityGraph)m_pool.get(p);
			if(subgraph == null) {			
				subgraph = new EntityGraph();
				EntityGraph g = getGraph(p.getHeight() - 1, false);
				HierarchicalNode[] nodes = p.getSubNodes();
				subgraph.addNodes(nodes);
				IEdge edge1 = null, edge2 = null;
				for(int i = 0; i < nodes.length; ++i) {
					for(int j = i; j < nodes.length; ++i) {
						if(j == i) continue;
						edge1 = g.getEdge(nodes[i], nodes[j]);
						if(edge1 != null) {
							subgraph.addEdge(nodes[i], nodes[j]);
						}
						edge2 = g.getEdge(nodes[j], nodes[i]);
						if(edge2 != null) {
							subgraph.addEdge(nodes[j], nodes[i]);
						}
					}
				}
				m_pool.put(p, subgraph);
			}
			return subgraph;
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
			return null;
		}
	}

	public IGraphDataEx getSubGraph(int height) {
		return getGraph(height, false);
	}

	public Object[] getNodes(int height) {
		EntityGraph g = getGraph(height, false);
		return g == null ? null : g.getNodes(null, null);
	}

	public Object[] getSubNodes(Object parent) {
		
		HierarchicalNode node = null;
		
		if(parent instanceof HierarchicalNode) {
			node = (HierarchicalNode)parent;
		} else {
			node = getHierarchicalNode(parent);
		}
		if(null == node) {
			return null;
		}
		
		HierarchicalNode[] subnodes = node.getSubNodes();
		if(null == subnodes) {
			return null;
		}
		Object[] nodes = new Object[subnodes.length];
		for(int i = 0; i < subnodes.length; ++i) {
			nodes[i] = subnodes[i].getObject();
		}
		return nodes;
	}

	public Object[] getLeaves(Object parent) {
		
		return null;
	}

	public boolean isLeaf(Object node) {
		HierarchicalNode n = null;
		if(node instanceof HierarchicalNode) {
			n = (HierarchicalNode)node;
		} else {
			n = getHierarchicalNode(node);
		}
		return n.isLeaf();
	}

	public Object getParent(Object node) {
		HierarchicalNode n = null;
		if(node instanceof HierarchicalNode) {
			n = (HierarchicalNode)node;
		} else {
			n = getHierarchicalNode(node);
		}
		HierarchicalNode p = n.getParent();
		
		return p == null ? null : p.getObject();
	}
	
	public int getHeight() {
		return m_graphs.size() - 1;
	}
	
	public int getHeight(IGraphDataEx graph) {
		return m_graphs.indexOf(graph);
	}

	public int getHeight(Object node) {
		HierarchicalNode n = null;
		if(node instanceof HierarchicalNode) {
			n = (HierarchicalNode)node;
		} else {
			n = getHierarchicalNode(node);
		}
		if(null == n) {
			return -1;
		}
		return n.getHeight();
	}

	public Object getSuperNode() {
		return m_super;
	}
	
	public void setSuperNode(Object snode) {
		
		if(m_super == snode) {
			return;
		}
		
		HierarchicalNode supernode = null;
		if(snode instanceof HierarchicalNode) {
			supernode = (HierarchicalNode)snode;
		} else {
			supernode = getHierarchicalNode(snode);
		}
		
		if(supernode == null) {
			supernode = new HierarchicalNode();
			supernode.setObject(snode);
			supernode.setHeight(getHeight() + 1);
			m_map.put(snode, supernode);
		}
		
		m_pool.remove(m_super);
		m_map.remove(m_super);
		m_super = snode;
		
		HierarchicalNode node = null;
		Object[] nodes = getNodes(getHeight());
		double w = 0;
		for(int i = 0; i < nodes.length; ++i) {
			node = (HierarchicalNode)m_map.get(nodes[i]);
			supernode.addSubNode(node);
			w += PropOperator.getInstance().getWeight(nodes[i]);
		}
		PropOperator.getInstance().
			setProperty(m_super, IWeight.PROP_WEIGHT, new Double(w));
	}

	public HierarchicalNode clusterNodes(Object metanode, Object[] nodes, int height) {
		HierarchicalNode supernode = null;
		if(metanode instanceof HierarchicalNode) {
			supernode = (HierarchicalNode)metanode;
		} else {
			supernode = getHierarchicalNode(metanode);
		}
		
		if(supernode == null) {
			supernode = new HierarchicalNode();
			supernode.setObject(metanode);
			supernode.setHeight(height + 1);
			m_map.put(metanode, supernode);
			EntityGraph g = (EntityGraph)getGraph(height + 1, true);
			g.addNode(metanode);
		}
		
		for(int i = 0; i < nodes.length; ++i) {
			HierarchicalNode node = null;
			if(nodes[i] instanceof HierarchicalNode) {
				node = (HierarchicalNode)nodes[i];
				node.setHeight(height);
				supernode.addSubNode(node);
			} else {
//				System.out.println("else cnodes = " + nodes[i]);
				node = getHierarchicalNode(nodes[i]);
				if(null == node) {
					node = supernode.addSubNode();
					node.setObject(nodes[i]);
					node.setHeight(height);
					m_map.put(nodes[i], node);
				} else {
					node.setHeight(height);
					supernode.addSubNode(node);
				}
			}
		}
		return supernode;
	}
	
	public void clusterEdges(int height) {
		
		if(height < 1) {
			return;
		}
		
		EntityGraph gparent = getGraph(height, false);
		EntityGraph gchild = getGraph(height - 1, false);
		Object[] nodes = gchild.getNodes(null, null);
//		IEdge[] edges = gchild.getEdges(null, null);
		
		IEdge edge1 = null;
		IEdge edge2 = null;
		IEdge e = null;
		HierarchicalNode p1 = null, p2 = null;
		HierarchicalNode n1 = null, n2 = null;
		
		for(int i = 0; i < nodes.length; ++i) {
			for(int j = i + 1; j < nodes.length; ++j) {
				n1 = getHierarchicalNode(nodes[i]);
				n2 = getHierarchicalNode(nodes[j]);
				
				p1 = n1.getParent();
				p2 = n2.getParent();
				if(p1 == p2) {
					continue;
				}
				
				edge1 = gchild.getEdge(nodes[i], nodes[j]);
				if(null != edge1) {
					e = gparent.getEdge(p1.getObject(), p2.getObject());
					if(e == null) {
						e = gparent.addEdge(p1.getObject(), p2.getObject());
						e.addProperty(IWeight.PROP_WEIGHT, new Integer(1));
					} else {
						int w = ((Integer)e.getProperty(IWeight.PROP_WEIGHT)).intValue();
						e.addProperty(IWeight.PROP_WEIGHT, new Integer(w + 1));
					}
				}
				
				edge2 = gchild.getEdge(nodes[j], nodes[i]);
				if(null != edge2) {
					e = gparent.getEdge(p2.getObject(), p1.getObject());
					if(e == null) {
						e = gparent.addEdge(p2.getObject(), p1.getObject());
						e.addProperty(IWeight.PROP_WEIGHT, new Integer(1));
					} else {
						int w = ((Integer)e.getProperty(IWeight.PROP_WEIGHT)).intValue();
						e.addProperty(IWeight.PROP_WEIGHT, new Integer(w + 1));
					}					
				}
			}
		}
	}
	
	public HierarchicalNode getHierarchicalNode(Object node) {
		return (HierarchicalNode)m_map.get(node);
	}
	
	private EntityGraph getGraph(int height, boolean create) {
		if(height < 0) {
			return null;
		}
		if(!create && height >= m_graphs.size()) {
			System.err.println("the input depth is out of range");
			return null;
		}
		EntityGraph g = null;
		if(height >= m_graphs.size()) {
			g = new EntityGraph();
			g.setEdgeType(m_edgeType);
			m_graphs.add(g);
		} else {
			g = (EntityGraph)m_graphs.get(height);
		}
		return g;
	}
	
	public void clear() {
		m_super = null;
		m_graphs.clear();
		m_pool.clear();
		m_map.clear();
		super.clear();
	}

	public boolean isEmpty() {
		return m_graphs.isEmpty();
	}

	public boolean contains(Object elem) {
		
		Object node = null;
		if(elem instanceof IEdge) {
			node = ((IEdge)elem).getFirstNode();
		} else {
			node = elem;
		}
		
		HierarchicalNode n = null;
		if(node instanceof HierarchicalNode) {
			n = (HierarchicalNode)node;
		} else {
			n = getHierarchicalNode(node);
		}
		
		return getGraph(n.getHeight(), false).contains(n.getObject());
	}

	public Object getAncestor(Object node, int level) {
		Object parent = getParent(node);
		
		if(null == parent) {
			return null;
		}
		
//		System.out.println("level = " + level + ", height = " + getHeight(parent));
		
		if(level == (getHeight() - getHeight(parent) + 1)) {
			return parent;
		}
		
		return getAncestor(parent, level);
	}
	
	public Object[] getOffsprings(Object node, int level) {
		
		List nodes = new ArrayList(1);
		if(level == (getHeight() - getHeight(node))) {
			return new Object[]{node};
		}
		
		Object[] subnodes = getSubNodes(node);
		Object[] offsprings = null;
		for(int i = 0; i < subnodes.length; ++i) {
			nodes.add(subnodes[i]);
			offsprings = getOffsprings(subnodes[i], level);
		}
		
		return nodes.toArray();	
	}

	public IGraphDataEx collapse(Object parent) {
				
//		int height = getHeight(parent);
//		Object[] subnodes = getSubNodes(parent);
//		if(null == subnodes) {
//			return getSubGraph(height);
//		}
		
		int height = getHeight(parent);
		if(height == 0) {
			return getSubGraph(height);
		}
		
		IGraphDataEx graph = getSubGraph(height - 1);
		
		return collapse(parent, graph);
	}
	
	public IGraphDataEx collapse(Object parent, IGraphDataEx graph) {
		
		if(null == graph || graph.isEmpty()) {
			return null;
		}
		
		EntityGraph newgraph = new EntityGraph();
		newgraph.setEdgeType(m_edgeType);
		
		int cnt = 0;
		Object node = null;
		Object n1 = null, n2 = null, p1 = null, p2 = null;
		IEdge edge = null, ee = null;
		
		// 1. init nodes
		newgraph.addNode(parent);
		cnt = graph.getNodeCount();
		for(int i = 0; i < cnt; ++i) {
			node = graph.getNode(i);
			if(parent == getParent(node)) {
				continue;
			}
			newgraph.addNode(node);
		}
		
		double max = Double.MIN_VALUE;
		double min = Double.MAX_VALUE;
		// 2. merge edges
		cnt = graph.getEdgeCount();
		for(int i = 0; i < cnt; ++i) {
			edge = graph.getEdge(i);
			n1 = edge.getFirstNode();
			n2 = edge.getSecondNode();
			p1 = getParent(n1);
			p2 = getParent(n2);
			if(p1 == parent && p2 == parent) {
				continue;
			}
			double w = PropOperator.getInstance().getWeight(edge);
			if(p1 == parent) {
				ee = newgraph.getEdge(parent, n2);
				if(ee == null) {
					ee = newgraph.addEdge(parent, n2);
				} else {
					w += PropOperator.getInstance().getWeight(ee);
				}
			} else if(p2 == parent) {
				ee = newgraph.getEdge(n1, parent);
				if(ee == null) {
					ee = newgraph.addEdge(n1, parent);
				} else {
					w += PropOperator.getInstance().getWeight(ee);					
				}
			} else {
				ee = newgraph.getEdge(n1, n2);
				if(ee == null) {
					ee = newgraph.addEdge(n1, n2);
				} else {
					w += PropOperator.getInstance().getWeight(ee);
				}
			}
			ee.addProperty(IWeight.PROP_WEIGHT, new Double(w));
			
			if(w > max) {
				max = w;
			}
			
			if(w < min) {
				min = w;
			}
		}
		
		System.out.println("max = " + max + ", min = " + min);
		
		IEdge[] edges = newgraph.getEdges(null, null);
		double w = 0;
		for(int i = 0; i < edges.length; ++i) {
			w = PropOperator.getInstance().getWeight(edges[i]);
			w = (w - min) / (max - min);
			w = w == 0D ? 0.03 : w;
			edges[i].addProperty(IWeight.PROP_WEIGHT, new Double(w));
		}
		
		return newgraph;
	}

	public IGraphDataEx expand(Object metanode) {
		
		int height = getHeight(metanode);
		Object[] subnodes = getSubNodes(metanode);
		if(null == subnodes) {
			return getSubGraph(height);
		}
		
		EntityGraph newgraph = new EntityGraph();
		newgraph.setEdgeType(m_edgeType);
		
		IGraphDataEx hgraph = getSubGraph(height);
		IGraphDataEx lgraph = getSubGraph(height - 1);
		int cnt = 0;
		Object node = null;
		Object n1 = null, n2 = null;
		IEdge edge = null;
		
		// 1. init nodes
		newgraph.addNode(metanode);
		cnt = hgraph.getNodeCount();
		for(int i = 0; i < cnt; ++i) {
			node = newgraph.getNode(i);
			if(node == metanode) {
				for(int j = 0; j < subnodes.length; ++j) {
					newgraph.addNode(subnodes[j]);
				}
			} else {
				newgraph.addNode(node);
			}
		}
		
		// 2. merge edges
		cnt = hgraph.getEdgeCount();
		for(int i = 0; i < cnt; ++i) {
			edge = hgraph.getEdge(i);
			n1 = edge.getFirstNode();
			n2 = edge.getSecondNode();
			if(n1 != metanode && n2 != metanode) {
				newgraph.addEdge(n1, n2);
			}			
		}
		
		IEdge[] edges = null, subedge = null;
		edges = hgraph.getEdgesWithFirstNode(metanode);
		for(int i = 0; i < edges.length; ++i) {
			n1 = edges[i].getSecondNode();
			for(int j = 0; j < subnodes.length; ++j) {
				subedge = lgraph.getEdgesWithFirstNode(subnodes[j]);
				for(int k = 0; k < subedge.length; ++k) {
					n2 = subedge[k].getSecondNode();
					if(n1 == getParent(n2)) {
						newgraph.addEdge(subnodes[j], n1);
					}
				}
			}
		}
		
		edges = hgraph.getEdgesWithSecondNode(metanode);
		for(int i = 0; i < edges.length; ++i) {
			n1 = edges[i].getFirstNode();
			for(int j = 0; j < subnodes.length; ++j) {
				subedge = lgraph.getEdgesWithSecondNode(subnodes[j]);
				for(int k = 0; k < subedge.length; ++k) {
					n2 = subedge[k].getFirstNode();
					if(n1 == getParent(n2)) {
						newgraph.addEdge(n1, subnodes[j]);
					}
				}
			}
		}
		
		return newgraph;
	}
}
