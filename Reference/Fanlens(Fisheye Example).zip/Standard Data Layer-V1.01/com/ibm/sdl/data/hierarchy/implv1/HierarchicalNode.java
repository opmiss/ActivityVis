/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.hierarchy.implv1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class HierarchicalNode implements Serializable {

	private static final long serialVersionUID = -7818182229223732071L;
	private List m_subnodes = null;
	private HierarchicalNode m_parent = null;
	private int m_height = 0;
	private Object m_node = null;
	
	public HierarchicalNode() {
		m_subnodes = new ArrayList(0);
	}
	
	public HierarchicalNode[] getSubNodes() {
		return null == m_subnodes || m_subnodes.isEmpty() ? 
				null : (HierarchicalNode[])m_subnodes.toArray(new HierarchicalNode[]{});
	}
	
	public boolean hasSubNode(HierarchicalNode node) {
		return m_subnodes.contains(node);
	}
	
	public HierarchicalNode addSubNode() {
		HierarchicalNode node = new HierarchicalNode();
		node.setParent(this);
		m_subnodes.add(node);
		return node;
	}
	
	public void addSubNode(HierarchicalNode node) {
		node.setParent(this);
		m_subnodes.add(node);
	}
	
	public boolean removeSubNode(HierarchicalNode node) {
		return m_subnodes.remove(node);
	}
	
	public void setParent(HierarchicalNode parent) {
		m_parent = parent;
	}
	
	public HierarchicalNode getParent() {
		return m_parent;
	}
	
	public int getHeight() {
		return m_height;
	}
	
	public void setHeight(int height) {
		m_height = height;
	}
	
	public void setObject(Object obj) {
		m_node = obj;
	}
	
	public Object getObject() {
		return m_node;
	}
	
	public boolean isLeaf() {
		return m_subnodes.isEmpty();
	}
}
