package com.ibm.sdl.data.hierarchy.implv3;


import com.ibm.sdl.data.IDataListener;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphDataEx;

public interface IHierarchicalGraph extends IGraphDataEx, IDataListener {

	public void setSuperNode(Object node);

	/**
	 * Get the super node of the hierarchy.
	 * 
	 * @return the super node
	 */
	public Object getSuperNode();

	/**
	 * Get the parent of a specified node
	 * 
	 * @param node
	 * @return the parent of the input node
	 */
	public Object getParent(Object node);
	
	public boolean isCollapsed(Object node);
	
	public Object getAncestor(Object node, int height);

	public Object[] getNodes(int height);
	
	public Object[] getNodes(Object parent, int height);
	/**
	 * Get the children of specified node
	 * 
	 * @param parent
	 * @return
	 */
	public Object[] getSubNodes(Object parent);
	
	
	public void addSubNode(Object parent, Object node);

	/**
	 * Whether the Hierarchical Graph contains the edge
	 * 
	 * @param node1
	 * @param node2
	 * @return
	 */
	public boolean containsEdge(Object node1, Object node2);

	/**
	 * Whether the specified node is leaf in the Hierarchical Graph
	 * 
	 * @param node
	 * @return
	 */
	public boolean isLeaf(Object node);
	
	/**
	 * Get the input node's height in this hierarchical graph
	 * @param node
	 * @return
	 */
	public int getHeight(Object node);

	/**
	 * Get the height of this Hierarchical Graph
	 * @return
	 */
	public int getHeight();

	/***************************************************************************
	 * Structure Operation
	 **************************************************************************/
	public void split(Object node, Object[] children)
			throws InvalidateTypeException;

	public void merge(Object node);

	/***************************************************************************
	 * Operations for View Generation
	 **************************************************************************/
	public boolean inducedEdge(Object node1, Object node2);

	public Object[] expandEdge(IEdge edge, Object node);

	public boolean isDescendantOf(Object ancestor, Object decendent);

	/**
	 * View Generators
	 */
	
	public IViewGraph getView();
	
	public IViewGraph createView();
	
	public IViewGraph getSubView(Object node);
	
	public IViewGraph getSubView(int height);
	
	public IViewGraph getSubView(Object node, int height);
	
	public Object getNode(String id);
	
//	PropOperator.getInstance().getID();
}
