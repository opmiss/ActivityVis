/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.hierarchy.implv1;

import com.ibm.sdl.data.IData;
import com.ibm.sdl.data.api.IGraphDataEx;


public interface IHierarchy extends IData {
	
	public Object[] getNodes(int height);

	public Object[] getSubNodes(Object parent);

	public Object[] getLeaves(Object parent);

	public boolean isLeaf(Object node);

	public Object getParent(Object n);
	
	public int getHeight();
	
	public int getHeight(IGraphDataEx graph);

	public int getHeight(Object node);

	public Object getSuperNode();

	public HierarchicalNode clusterNodes(Object metanode, Object[] nodes, int height);

	public HierarchicalNode getHierarchicalNode(Object metanode);
	
	public Object getAncestor(Object node, int level);
	
	public Object[] getOffsprings(Object node, int level);
}
