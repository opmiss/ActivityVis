/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.hierarchy.implv1;

import com.ibm.sdl.data.AbstractData;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.util.filter.IItemFilter;

public class Hierarchy extends AbstractData implements IHierarchy {

	private static final long serialVersionUID = 5484874519731907285L;

	public Hierarchy() {
	}
	
	public Object[] getNodes(int height) {
		return null;
	}

	public Object[] getSubNodes(Object parent) {
		return null;
	}

	public Object[] getLeaves(Object parent) {
		return null;
	}

	public boolean isLeaf(Object node) {
		return false;
	}

	public Object getParent(Object n) {
		return null;
	}

	public int getHeight(Object node) {
		return 0;
	}

	public Object getSuperNode() {
		return null;
	}
	
	public void addSubNode(Object parent, Object subnode) {
		
	}
	
	public void removeSubNode(Object subnode) {
		
	}
	
	public HierarchicalNode clusterNodes(Object metanode, Object[] nodes,
			int height) {
		return null;
	}

	public HierarchicalNode getHierarchicalNode(Object metanode) {
		return null;
	}

	public boolean isEmpty() {
		return false;
	}

	public boolean contains(Object elem) {
		return false;
	}

	public int getHeight() {
		return 0;
	}

	public int getHeight(IGraphDataEx graph) {
		return 0;
	}

	public Object getAncestor(Object node, int level) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object[] getOffsprings(Object node, int level) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object[] getElements(IItemFilter filter) {
		return null;
	}
}
