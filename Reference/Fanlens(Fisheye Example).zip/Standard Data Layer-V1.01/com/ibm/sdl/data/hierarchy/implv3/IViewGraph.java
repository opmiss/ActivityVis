package com.ibm.sdl.data.hierarchy.implv3;


import com.ibm.sdl.data.IDataListener;
import com.ibm.sdl.data.api.IGraphDataEx;


public interface IViewGraph extends IGraphDataEx, IDataListener {
		
	public void setNumericAttr(String[] keys);
	
	public String[] getNumericAttr();
	
	public double getMaxWeight(String key);
	
	public double getMinWeight(String key);
	
	/**
	 * Expand the input node's children to current View
	 * @param node
	 * @return
	 */
	public IViewGraph expand(Object node);
	
	/**
	 * Collapse the input node's children and show input node on the current View
	 * @param node
	 * @return
	 */
	public IViewGraph collapse(Object node);
	
	/**
	 * Set the specific node be collapsed, only used for ViewManager
	 * @param node
	 * @param flag
	 */
	public void setCollapsed(Object node, boolean flag);

	public boolean isCollapsed(Object node);
	
	public void reset();
	
}
