package com.ibm.sdl.data.hierarchy.implv2;

import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;

public class HierarchicalGraph extends EntityGraph implements
		IHierarchicalGraph {

	private static final long serialVersionUID = 8295187354892886946L;

	private static final double CENTER_TAG = 0;

	private static final double INCREMENTAL = 100;

	protected Comparator m_comparator = null;

	protected IGraphDataEx m_graph = null;

	protected IViewGraph m_view = null;

	protected Object m_root = null;

	// -------------------------
	protected LinkedList NODE_LIST = null;

	public Map TAG = null;

	// -------------------------
	protected Map CLUSTOR = null;

	protected Map NEIGHBOR = null;

	protected Map PARENT = null;
	
	private static final double e = 1E-6;

	public HierarchicalGraph() {
		this(null, null, null);
	}

	public HierarchicalGraph(IGraphDataEx graph, Object supernode,
			Class edgeType) {
		try {
			NODE_LIST = new LinkedList();
			TAG = new HashMap();
			CLUSTOR = new HashMap();
			NEIGHBOR = new HashMap();
			PARENT = new HashMap();
			m_comparator = new Comparator() {
				public int compare(Object node1, Object node2) {
					double tag1 = (Double) TAG.get(node1); // Debug: root
					double tag2 = (Double) TAG.get(node2); // Debug: Ben
					double d = tag1 - tag2;
					if(Math.abs(d) <= e) {
						return 0;
					}
					return d > 0 ? 1 : -1;
				}
			};
			super.setEdgeType(edgeType);
			if (null != supernode) {
				setSuperNode(supernode);
			}
			if (null != graph) {
				graph.addDataListener(this);
				setGraph(graph);
			}
		} catch (InvalidateDataException ex) {
			ex.printStackTrace();
		}
	}

	public void setGraph(IGraphDataEx graph) throws InvalidateDataException {
		if (null == m_root) {
			throw new InvalidateDataException(
					"Hierarchical Graph Root can not be null!");
		}
		m_graph = graph;
		
		Object[] nodes = graph.getNodes(null, null);
		for (int i = 0; i < nodes.length; i++) {
			addNode(nodes[i]);
		}
		
		IEdge[] edges = graph.getEdges(null, null);
		Object n1 = null; 
		Object n2 = null;
		for (int i = 0; i < edges.length; i++) {
			n1 = edges[i].getFirstNode();
			n2 = edges[i].getSecondNode();
			addEdge(n1, n2);
		}
	}

	public synchronized IGraphDataEx getGraph() {
		return m_graph;
	}

	public void setSuperNode(Object node) {
		Object[] children = getSubNodes(m_root);
		if (null == children) {
			super.removeNode(m_root);
			m_root = node;
			super.addNode(m_root);
		} else {
			for (int i = 0; i < children.length; i++) {
				super.removeEdge(m_root, children[i]);
				super.addEdge(node, children[i]);
			}
			super.removeNode(m_root);
			m_root = node;
			super.addNode(node);
		}
	}

	public Object getSuperNode() {
		return m_root;
	}

	public Object getParent(Object node) {
		return PARENT.get(node);
	}

	public Object[] getSubNodes(Object parent) {
		if (null == m_graph || m_graph.contains(parent))
			return null;

		List edges = (List) this.m_edgesFromNode1.get(parent);
		if (edges == null) {
			return null;
		}

		int size = edges.size();
		IEdge edge = null;
		Object[] set = new Object[edges.size()];
		for (int i = 0; i < size; ++i) {
			edge = (IEdge) edges.get(i);
			set[i] = edge.getSecondNode();
		}
		return set;
	}

	public boolean containsEdge(Object node1, Object node2) {
		IEdge edge = getEdge(node1, node2);
		return null != edge;
	}

	public boolean isLeaf(Object node) {
		if (0 == getHeight(node))
			return true;
		else
			return false;
	}

	public int getHeight(Object node) {
		return getMetaInfo(node).height;
	}

	public int getHeight() {
		return getHeight(m_root);
	}

	/**
	 * Cluster Set of each metanode, contains only two nodes, the most left and
	 * the most right
	 * 
	 * @param metanode
	 * @param bcreate
	 * @return
	 */
	protected synchronized MetaInfo getMetaInfo(Object metanode) {
		MetaInfo c = (MetaInfo) CLUSTOR.get(metanode);
		if (c == null) {
			c = new MetaInfo();
			CLUSTOR.put(metanode, c);
		}
		return c;
	}

	/**
	 * Neighbor Set of each metanode, contains all the nodes adjacent to the
	 * current node, saved in a BalancedSearchTree, for the search cost is
	 * log(n).
	 * 
	 * @param metanode
	 * @return
	 */
	protected synchronized BalancedSearchTree getNeighborTree(Object metanode) {
		BalancedSearchTree t = (BalancedSearchTree) NEIGHBOR.get(metanode);
		if (null == t) {
			t = new AVLTree();
			t.setEdgeType(edgeType);
			((AVLTree) t).TAG = TAG;
			t.setComparator(m_comparator);
			NEIGHBOR.put(metanode, t);
		}
		return t;
	}

	/**
	 * Add node1 to node2's neighbor tree
	 * 
	 * @param node1
	 * @param node2
	 */
	protected void addToNeighborTree(Object node1, Object node2) {

	}

	/**
	 * Get the next node beside current one in the ordered node list of this
	 * hierarchical Graph
	 * 
	 * @param node
	 * @return
	 */
	protected Object getNext(Object node) {
		int index = NODE_LIST.indexOf(node);
		if (++index >= NODE_LIST.size())
			return null;
		return NODE_LIST.get(index);
	}

	/**
	 * Get the previous node beside current one in the ordered node list of this
	 * hierarchical Graph
	 * 
	 * @param node
	 * @return
	 */
	protected Object getPrevious(Object node) {
		int index = NODE_LIST.indexOf(node);
		if (--index < 0)
			return null;
		return NODE_LIST.get(index);
	}

	/***************************************************************************
	 * Structure Operations
	 **************************************************************************/

	/**
	 * Split the current children with their parent, and replace it with node,
	 * the sequence must be same as they are in the Hierarchical Graph
	 * 
	 * @param parent
	 * @param children
	 * @throws InvalidateTypeException
	 */
	public void split_old(Object node, Object[] children)
			throws InvalidateTypeException {
		if (null == node || null == children)
			return;

		Object preParent = getParent(children[0]);
		for (int i = 1; i < children.length; i++) {
			if (!preParent.equals(getParent(children[i])))
				throw new InvalidateTypeException(
						"The children must have the same parent!");
			if (!contains(children[i]))
				throw new InvalidateTypeException(
						"Child does not exist in Current Hierarchy!");
		}

		// refresh the structure
		super.addNode(node);
		super.addEdge(preParent, node);
		PARENT.put(node, preParent);
		for (int i = 0; i < children.length; i++) {
			super.removeEdge(preParent, children[i]);
			super.addEdge(node, children[i]);
			PARENT.put(children[i], node);
		}

		// refresh the data set
		MetaInfo miC = getMetaInfo(children[0]);
		MetaInfo miN = getMetaInfo(node);
		miN.height = miC.height + 1;
		MetaInfo miP = null;
		do {
			miP = getMetaInfo(preParent);
			miP.height = miP.height == miN.height + 1 ? miP.height
					: miN.height + 1;
			preParent = getParent(preParent);
		} while (null != preParent);

		IEdge[] edges = null;
		Object adj = null;

		BalancedSearchTree bst = getNeighborTree(node);

		if (isLeaf(children[0])) {
			miN.start = children[0];
			miN.end = children[children.length - 1];

			for (int i = 0; i < children.length; i++) {
				miN.weight++;
				edges = (IEdge[]) getEdgesWithFirstNode(children[i]);
				for (int j = 0; j < edges.length; j++) {
					adj = edges[j].getSecondNode();
					if (!node.equals(adj)) {
						bst.insertNode(adj);
					}
				}
				edges = (IEdge[]) getEdgesWithSecondNode(children[i]);
				for (int j = 0; j < edges.length; j++) {
					adj = edges[j].getFirstNode();
					if (!node.equals(adj)) {
						bst.insertNode(adj);
					}
				}
			}
		} else {
			MetaInfo c1 = getMetaInfo(children[0]);
			MetaInfo c2 = getMetaInfo(children[children.length - 1]);
			miN.start = c1.start;
			miN.end = c2.end;

			BalancedSearchTree bstC = null;
			Object adjs[] = null;
			Object child = null;

			for (int i = 0; i < children.length; i++) {
				child = children[i];
				miC = getMetaInfo(child);
				miN.weight += miC.weight;

				bstC = getNeighborTree(child);
				adjs = bstC.getNodes();
				for (int j = 0; j < adjs.length; j++) {
					if (!node.equals(adjs[j])) {
						bst.insertNode(adjs[j]);
					}
				}
			}
		}
	}

	/**
	 * Split the current children with their parent, and replace it with node,
	 * the sequence must be same as they are in the Hierarchical Graph
	 * 
	 * @param parent
	 * @param children
	 * @throws InvalidateTypeException
	 */
	public void split(Object node, Object[] children)
			throws InvalidateTypeException {
		if (null == node || null == children)
			return;

		Object preParent = getParent(children[0]);
		Double minTag = getStartTag(children[0]);
		Object min = children[0];

		// find the min value
		for (int i = 1; i < children.length; i++) {
			if (!preParent.equals(getParent(children[i])))
				throw new InvalidateTypeException(
						"The children must have the same parent!");
			if (!contains(children[i]))
				throw new InvalidateTypeException(
						"Child does not exist in Current Hierarchy!");
			Double tagI = getStartTag(children[i]);
			if (tagI < minTag) {
				minTag = tagI;
				min = children[i];
			}
		}
		Object previous = min;
		for (int i = 0; i < children.length; i++) {
			Object tagI = getStartTag(children[i]);
			if (!minTag.equals(tagI)) {
				buildAllIndex(previous, children[i]);
				previous = children[i];
			}
		}

		// refresh the structure
		super.addNode(node);
		super.addEdge(preParent, node);
		PARENT.put(node, preParent);
		for (int i = 0; i < children.length; i++) {
			super.removeEdge(preParent, children[i]);
			super.addEdge(node, children[i]);
			PARENT.remove(children[i]);
			PARENT.put(children[i], node);
		}

		// refresh the data set
		MetaInfo miC = getMetaInfo(children[0]);
		MetaInfo miN = getMetaInfo(node);
		miN.height = miC.height + 1;
		MetaInfo miP = null;
		do {
			miP = getMetaInfo(preParent);
			miP.height = miP.height == miN.height + 1 ? miP.height
					: miN.height + 1;
			preParent = getParent(preParent);
		} while (null != preParent);

		IEdge[] edges = null;
		Object adj = null;
		BalancedSearchTree bst = getNeighborTree(node);

		if (isLeaf(children[0])) {
			miN.start = children[0];
			miN.end = children[children.length - 1];

			for (int i = 0; i < children.length; i++) {
				miN.weight++;
				edges = (IEdge[]) getEdgesWithFirstNode(children[i]);
				for (int j = 0; j < edges.length; j++) {
					adj = edges[j].getSecondNode();
					if (!node.equals(adj)) {
						bst.insertNode(adj);
					}
				}
				edges = (IEdge[]) getEdgesWithSecondNode(children[i]);
				for (int j = 0; j < edges.length; j++) {
					adj = edges[j].getFirstNode();
					if (!node.equals(adj)) {
						bst.insertNode(adj);
					}
				}
			}
		} else {
			MetaInfo c1 = getMetaInfo(children[0]);
			MetaInfo c2 = getMetaInfo(children[children.length - 1]);
			miN.start = c1.start;
			miN.end = c2.end;

			BalancedSearchTree bstC = null;
			Object adjs[] = null;
			Object child = null;

			for (int i = 0; i < children.length; i++) {
				child = children[i];
				miC = getMetaInfo(child);
				miN.weight += miC.weight;

				bstC = getNeighborTree(child);
				adjs = bstC.getNodes();
				for (int j = 0; j < adjs.length; j++) {
					if (!node.equals(adjs[j])) {
						bst.insertNode(adjs[j]);
					}
				}
			}
		}
	}

	/**
	 * 
	 * @param object
	 * @return node's start tag
	 */
	private Double getStartTag(Object node) {
		MetaInfo meta = (MetaInfo) CLUSTOR.get(node);
		return (Double) TAG.get(meta.start);
	}

	private void buildAllIndex(Object a, Object nb) {

		MetaInfo smallmeta = (MetaInfo) CLUSTOR.get(a);
		if (smallmeta.start.equals(a)) {
			double debug = 0;
		}
		MetaInfo bigmeta = (MetaInfo) CLUSTOR.get(nb);
		if (compare(smallmeta.start, bigmeta.start) >= 0) {
			MetaInfo temp = smallmeta;
			smallmeta = bigmeta;
			bigmeta = temp;
		}
		int is = NODE_LIST.indexOf(bigmeta.start);
		int ie = NODE_LIST.indexOf(bigmeta.end);
		Object prev = smallmeta.end;
		for (int i = is; i < ie + 1; i++) {
			Object o = NODE_LIST.get(i);
			NODE_LIST.remove(o);
			buildIndex(prev, o);
			prev = o;
		}
	}

	private int compare(Object a, Object b) {
		return m_comparator.compare(a, b);
	}

	/**
	 * Insert the node to the previous 's next position. Change the TAG to
	 * represent the situation.
	 * 
	 * @param previous
	 * @param node
	 */
	protected void buildIndex(Object previous, Object node) {
		if (null == node)
			return;

		if (null == previous) {
			TAG.put(node, CENTER_TAG);
			NODE_LIST.add(node);
		} else {
			int preindex = NODE_LIST.indexOf(previous);

			Object next = getNext(previous);
			double previousTag = (Double) TAG.get(previous);
			double nextTag = 0;
			if (null == next) {
				nextTag = previousTag + INCREMENTAL;
			} else {
				nextTag = (Double) TAG.get(next);
			}
			double currentTag = previousTag + (nextTag - previousTag) * Math.random();

			TAG.put(node, currentTag);
			NODE_LIST.add(++preindex, node);

			double pTag = (Double) TAG.get(previous);
			double cTag = (Double) TAG.get(node);

			if (cTag - pTag < 1E-7) {
				// The difference is too small,so we need to rebuild the index.
				Object[] nodes = new Object[NODE_LIST.size()];
				for (int i = 0; i < nodes.length; i++) {
					nodes[i] = NODE_LIST.get(i);
				}
				previousTag = CENTER_TAG - INCREMENTAL;
				for (int i = 0; i < nodes.length; i++) {
					cTag = previousTag + INCREMENTAL;
					previousTag += INCREMENTAL;
					TAG.remove(nodes[i]);
					TAG.put(nodes[i], cTag);
				}
			}
		}
	}

	/**
	 * /** Merge the current node's child directly to its parent
	 * 
	 * @param node
	 */
	public void merge(Object node) {
		if (node == m_root) {
			return;
		}

		if (isLeaf(node)) {
			return;
		}

		Object parent = getParent(node);
		Object[] children = getSubNodes(node);
		super.removeNode(node);
		PARENT.remove(node);
		CLUSTOR.remove(node);
		NEIGHBOR.remove(node);

		for (int i = 0; i < children.length; ++i) {
			super.addEdge(parent, children[i]);
			PARENT.put(children[i], parent);
		}

		// refresh the data set
		MetaInfo miP = null;
		do {
			miP = getMetaInfo(parent);
			miP.height--;
			parent = getParent(parent);
		} while (null != parent);

	}

	/***************************************************************************
	 * Internal Operations
	 **************************************************************************/

//	public boolean inducedEdge(Object nodeU, Object nodeV) {
//		
//		if(this.isLeaf(nodeU) && this.isLeaf(nodeV)) {
//			return getEdge(nodeU, nodeV) != null;
//		}
//		
//		MetaInfo cU = getMetaInfo(nodeU);
//		MetaInfo cV = getMetaInfo(nodeV);
//		Object startU = cU.start;
//		Object startV = cV.start;
//		BalancedSearchTree bst = null;
//		Object previous = null;
//		Object succ = null;
//
//		if (m_comparator.compare(startU, startV) < 0) {
//			bst = getNeighborTree(nodeV);
//			previous = getPrevious(startU);
//			if (null == previous) {
//				Object min = bst.findMin();
//				if (m_comparator.compare(min, cU.end) <= 0) {
//					return true;
//				} else {
//					return false;
//				}
//			}
//			succ = bst.findSucc(previous);
//			if (null != succ && m_comparator.compare(succ, cU.end) <= 0) {
//				return true;
//			} else {
//				// succ = bst.findSucc(previous);
//				// System.out.println("**** " + bst.containsNode(nodeU));
//				// System.out.println("nodeU = " + nodeU + " value = " +
//				// TAG.get(nodeU));
//				// System.out.println("nodeV = " + nodeV + " value = " +
//				// TAG.get(nodeV));
//				// System.out.println("previous = " + previous + " value = " +
//				// TAG.get(previous));
//				// System.out.println("succ = " + succ);
//				// System.out.println("cU.end = " + cU.end);
//				// ((AVLTree)bst).printTree(bst.getTreeRoot());
//				// System.out.println("-----------------------------");
//				return false;
//			}
//		} 
//		return false;
////		else {
////			bst = getNeighborTree(nodeU);
////			previous = getPrevious(startV);
////			if (null == previous) {
////				Object min = bst.findMin();
////				if (m_comparator.compare(min, cV.end) <= 0) {
////					return true;
////				} else {
////					return false;
////				}
////			}
////			succ = bst.findSucc(previous);
////			if (null != succ && m_comparator.compare(succ, cV.end) <= 0) {
////				return true;
////			} else {
////				return false;
////			}
////		}
//	}

	
	public boolean inducedEdge(Object nodeU, Object nodeV) {		
		if(this.isLeaf(nodeU) && this.isLeaf(nodeV)) {
			return getEdge(nodeU, nodeV) != null;
		}			
		BalancedSearchTree bst = getNeighborTree(nodeU);
		MetaInfo small = getMetaInfo(nodeV);
		Object succ = bst.findSucc(small.start);
		if (null != succ && m_comparator.compare(succ, small.end) <= 0) {
			return true;
		}
		return false;
	}
	
	public Object[] expandEdge(IEdge edge, Object nodeV) {
		Object first = edge.getFirstNode();
		Object second = edge.getSecondNode();
		Object nodeU = nodeV.equals(first) ? second : first;
		boolean bfirst = false;
		if(nodeV.equals(first)) {
			bfirst = true;
			nodeU = second;
		} else {
			nodeU = first;
		}
		List neighbors = new ArrayList();
		Object[] children = getSubNodes(nodeV);
		for (int i = 0; i < children.length; i++) {
			if(bfirst) {
				if(inducedEdge(children[i], nodeU)) {
					neighbors.add(children[i]);
				}
			} else {
				if(inducedEdge(nodeU, children[i])) {
					neighbors.add(children[i]);
				}
			}
		}

		return neighbors.toArray();
	}

	public boolean isDecendantOf(Object ancestor, Object decendent) {
		MetaInfo d = getMetaInfo(decendent);
		MetaInfo a = getMetaInfo(ancestor);

		if (m_comparator.compare(d.start, a.start) >= 0
				&& m_comparator.compare(d.end, a.end) <= 0)
			return true;
		else
			return false;
	}

	/*
	 * TODO: Methods of IDataListener
	 * 
	 */
	public void itemChanged(DataEvent e) {
	}

	public void itemRemoved(DataEvent e) {
		switch (e.getType()) {
		case DataEvent.NODE_REMOVED_EVENT:
			Object node = e.getItem();
			if (contains(node))
				super.removeNode(node);
			break;
		case DataEvent.EDGE_REMOVED_EVENT:
			IEdge edge = (IEdge) e.getItem();
			Object n1 = edge.getFirstNode();
			Object n2 = edge.getSecondNode();

			if (containsEdge(n1, n2) && null != m_root) {
				super.removeEdge(n1, n2);
			}
			break;
		}
	}

	public void itemAdded(DataEvent e) {
		switch (e.getType()) {
		case DataEvent.NODE_ADDED_EVENT:
			Object node = e.getItem();
			if (!contains(node) && null != m_root) {
				addNode(node);
			}
			break;
		case DataEvent.EDGE_ADDED_EVENT:
			IEdge edge = (IEdge) e.getItem();
			Object n1 = edge.getFirstNode();
			Object n2 = edge.getSecondNode();

			if (!containsEdge(n1, n2) && null != m_root) {
				addEdge(n1, n2);
			}
			break;
		}
	}

	public void dataCleared(DataEvent e) {

	}

	public void dataRefreshed(DataEvent e) {

	}

	public void addNode(Object node) {
		addSubNode(m_root, node);
	}

	/**
	 * Add a Node2 to the Hierarchical Graph as the child of Inner Node1
	 * 
	 * @param node1
	 * @param node2
	 */
	public void addSubNode(Object parent, Object node) {
		MetaInfo c1 = getMetaInfo(parent);
		MetaInfo c2 = getMetaInfo(node);
		c2.start = node;
		c2.end = node;
		c1.height = c1.height == 0 ? 1 : c1.height;
		c1.weight++;
		c2.weight = 1;

		if (null == c1.start) {
			c1.start = c1.end = node;
			TAG.put(node, CENTER_TAG);
			NODE_LIST.add(node);
		} else {
			int index = NODE_LIST.indexOf(c1.end);
			Object next = getNext(c1.end);
			double previousTag = (Double) TAG.get(c1.end);
			double nextTag = 0;
			if (null == next) {
				nextTag = previousTag + INCREMENTAL;
			} else {
				nextTag = (Double) TAG.get(next);
			}
			double currentTag = previousTag + (nextTag - previousTag)* Math.random();
			TAG.put(node, currentTag);
			NODE_LIST.add(++index, node);
			c1.end = node;
		}

		PARENT.put(node, parent);

		super.addNode(node);
		super.addEdge(parent, node);
	}

	public IEdge addEdge(Object n1, Object n2) {
		IEdge edge = getEdge(n1, n2);
		if (null != edge) {
			return edge;
		}

		edge = super.addEdge(n1, n2);
		
		Object p1 = n1;
		Object p2 = n2;
		BalancedSearchTree bst1 = null;
		BalancedSearchTree bst2 = null;

//		TODO: TAG StackOverflow bug fixed
		while (null != p1 && m_root != p1) {
			bst1 = getNeighborTree(p1);
			bst1.insertNode(n2);
			p1 = getParent(p1);
		}

		do {
			bst2 = getNeighborTree(p2);
			if (bst2.containsNode(n1))
				break;
			bst2.insertNode(n1);
			p2 = getParent(p2);
		} while (!p2.equals(m_root));

		return edge;
	}

	public void addEdge(IEdge edge) {
		addEdge(edge.getFirstNode(), edge.getSecondNode());
	}

	public void removeBranch(Object node){
		MetaInfo mi = getMetaInfo(node);
		if (mi.height == 0) {
			NODE_LIST.remove(node);
			PARENT.remove(node);	
		} 	
		super.removeNode(node);
		Object []children = getSubNodes(node);
		int size = 0 ;
		if(children!=null) size = children.length;
		for(int i = 0 ;i<size;i ++ ){
			removeBranch(children[i]);
		}
		fireItemRemoved(node, DataEvent.NODE_REMOVED_EVENT);
	}
	public void removeNode(Object node) {
//		if(true) return ;
		MetaInfo mi = getMetaInfo(node);
		if (mi.height == 0) {
			NODE_LIST.remove(node);
			PARENT.remove(node);	
			super.removeNode(node);
		} else {
			removeInnerNode(node);
		}		
		fireItemRemoved(node, DataEvent.NODE_REMOVED_EVENT);
	}

	
	/**
	 * TODO .... 1. Make the children of the node connect with the parent of the
	 * node. 2. Remove the edge from the node to its parent. 3. Remove the node.
	 * Note:NODE_LIST doesnot contain any inner-node.
	 */
	private void removeInnerNode(Object node) {
		Object parent = PARENT.get(node);
		Object[] children = getSubNodes(node);
		for (int i = 0; i < children.length; i++) {
			PARENT.put(children[i], parent);
			addEdge(children[i],parent);
		}
		super.removeNode(node);		
	}
	public void removeEdge(IEdge edge) {
		removeEdge(edge.getFirstNode(), edge.getSecondNode());
	}
	//TODO 
	public void removeEdge(Object n1, Object n2) {
		if (isInnerNode(n1) || isInnerNode(n2)) {
			throw new InvalidParameterException();
		}
		super.removeEdge(n1, n2);
		//TODO rebuild neighbor tree.
		Object p1 = n1;
		Object p2 = n2;
		BalancedSearchTree bst1 = null;
		BalancedSearchTree bst2 = null;
		while (null != p1) {
			bst1 = getNeighborTree(p1);
			bst1.removeNode(n2);
			p1 = getParent(p1);
		}
		do {
			bst2 = getNeighborTree(p2);
			if (!bst2.containsNode(n1))
				break;
			bst2.removeNode(n1);
			p2 = getParent(p2);
		} while (!p2.equals(m_root));
		
	}
	private boolean isInnerNode(Object n2) {
		boolean r = false;
		MetaInfo mi = getMetaInfo(n2);
		if (mi.height > 0)
			r = true;
		return r;
	}



	public void depthTraversalGraph() {
		List visited = new Vector(0);
		printGraph(m_root, visited);
	}

	private void printGraph(Object node, List visited) {
		System.out.println(node);
		visited.add(node);

		Object[] children = getSubNodes(node);
		if (null != children) {
			for (int i = 0; i < children.length; i++) {
				if (!visited.contains(children[i])) {
					printGraph(children[i], visited);
				}
			}
		}
	}

	public void printNodes() {
		for (int i = 0; i < m_nodes.size(); i++) {
			System.out.println(m_nodes.get(i));
			System.out
					.println("weight = " + getMetaInfo(m_nodes.get(i)).weight);
			System.out
					.println("height = " + getMetaInfo(m_nodes.get(i)).height);
			System.out.println("----------");
		}
	}

	public Object getAncestor(Object node, int height) {
		int h = getHeight(node);

		if (h == height) {
			return node;
		}

		Object parent = getParent(node);
		if (null == parent) {
			return null;
		}

		return getAncestor(parent, height);
	}

	public Object[] getNodes(int height) {
		List nodes = new ArrayList(0);

		getNodes(m_root, height, nodes);

		return nodes.toArray();
	}
	
	public Object getNode(String name){
		Object r = null;
		for(int i = 0; i<m_nodes.size();i++){
			Object node = m_nodes.get(i);
			String s = PropOperator.getInstance().getName(node);
			if(s.equals(name))
				return node;
		}
		return r;
	}

	public Object[] getNodes(Object node, int height) {
		List nodes = new ArrayList(0);

		getNodes(node, height, nodes);

		return nodes.toArray();
	}

	private void getNodes(Object node, int height, List nodes) {
		int h = getHeight(node);

		if (h == height) {
			nodes.add(node);
		} else if (h > height) {
			Object[] children = getSubNodes(node);
			for (int i = 0; i < children.length; i++) {
				getNodes(children[i], height, nodes);
			}
		}
	}

	/**
	 * View Generators
	 */
	public synchronized IViewGraph getView() {
		if (null == m_view) {
			m_view = new ViewGraph(this, edgeType);
		}
		return m_view;
	}
	
	public synchronized void setView(IViewGraph view) {
		m_view = view;
	}

	public IViewGraph createView() {
		IViewGraph view = new ViewGraph(this, edgeType);
		return view;
	}

	public IViewGraph getSubView(Object node) {
		try {
			IViewGraph view = new ViewGraph();
			((ViewGraph) view).setEdgeType(edgeType);

			Object[] nodes = ((HierarchicalGraph) this).getGraph().getNodes(
					null, null);
			if (null != nodes)
				for (int i = 0; i < nodes.length; i++) {
					if (this.isDecendantOf(node, nodes[i])) {
						view.addNode(nodes[i]);
					}
				}

			IEdge[] edges = ((HierarchicalGraph) this).getGraph().getEdges(
					null, null);
			Object n1 = null, n2 = null;
			if (null != edges)
				for (int i = 0; i < edges.length; i++) {
					n1 = edges[i].getFirstNode();
					n2 = edges[i].getSecondNode();
					if (this.isDecendantOf(node, n1)
							&& this.isDecendantOf(node, n2)) {
						view.addEdge(n1, n2);
					}
				}
			return view;
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
			return null;
		}
	}

	public IViewGraph getSubView(int height) {
		try {
			IViewGraph view = new ViewGraph();
			((ViewGraph) view).setEdgeType(edgeType);

			Object[] nodes = getNodes(height);

			// add node
			for (int i = 0; i < nodes.length; i++) {
				view.addNode(nodes[i]);
			}

			// add edge
			if (null != nodes) {
				for (int i = 0; i < nodes.length; i++) {
					for (int j = i + 1; j < nodes.length; j++) {
						if (inducedEdge(nodes[i], nodes[j])) {
							view.addEdge(nodes[i], nodes[j]);
						}
					}
				}
			}
			return view;
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * direct children's view .
	 */
public IViewGraph getSubView(Object node, int height) {
		
		try {
			if(node == getSuperNode()) {
				System.out.println("return oringal view");
				return m_view;
			}
			
			IViewGraph view = new ViewGraph();
			((ViewGraph) view).setEdgeType(edgeType);
			
			HashSet set = new HashSet();
			Object[] nodes = getSubNodes(node);
			for (int i = 0; i < nodes.length; i++) {
				view.addNode(nodes[i]);
				set.add(nodes[i]);
			}
			IEdge[] edges = null;
			for(int i = 0; i < nodes.length; ++i) {
				edges = this.getEdgesWithFirstNode(nodes[i]);
				if(null != edges) {
					for(int j = 0; j < edges.length; ++j) {
						Object n2 = edges[j].getSecondNode();
						if(set.contains(n2) && null == view.getEdge(nodes[i], n2)) {
							view.addEdge(nodes[i], n2);
						}
					}
				}
				edges = this.getEdgesWithSecondNode(nodes[i]);
				if(null != edges) {
					for(int j = 0; j < edges.length; ++j) {
						Object n1 = edges[j].getFirstNode();
						if(set.contains(n1) && null == view.getEdge(n1, nodes[i])) {
							view.addEdge(n1, nodes[i]);
						}
					}
				}
			}
			
			System.out.println(
					"return view (" + view.getNodeCount() + ", " + 
					view.getEdgeCount() + "), " + isCollapsed(node) + 
					", node = " + node);
			
			return view;
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
			return null;
		}
	}

	public boolean isCollapsed(Object node) {
		return getView().isCollapsed(node);
	}
	
	public String getName(Object node){
		return PropOperator.getInstance().getName(node);
	}
}