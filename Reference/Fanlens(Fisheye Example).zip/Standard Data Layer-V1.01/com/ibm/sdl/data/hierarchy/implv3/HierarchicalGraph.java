package com.ibm.sdl.data.hierarchy.implv3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;

public class HierarchicalGraph extends EntityGraph implements IHierarchicalGraph {

	private static final long serialVersionUID = -3691289727293617963L;
	
	private static final int MAX_NODE_CNT = 1024;
	
	private Object root;
	private IGraphDataEx baseGraph;
	private String[] attrs;
	
	private HashMap idNode = new HashMap();
	private HashMap nodeIndex = new HashMap();
	private Object[] allNodes = new Object[MAX_NODE_CNT];
	
	private IdPool idPool = new IdPool(MAX_NODE_CNT);
	private int[][] induced = new int[MAX_NODE_CNT][MAX_NODE_CNT];
	
	private IViewGraph view;

	public HierarchicalGraph() {
	}
		
	public HierarchicalGraph(IGraphDataEx baseGraph, Object root, Class edgeType) {
		this(baseGraph, root, null, edgeType);
	}
	
	@SuppressWarnings("unchecked")
	public HierarchicalGraph(IGraphDataEx baseGraph, Object root, String[] attrs, Class edgeType) {
		this.root = root;
		setNumericAttr(attrs);
		setEdgeType(edgeType);
		addNode(root);
		setGraph(baseGraph);
	}
	
	public void setGraph(IGraphDataEx graph) {
		this.baseGraph = graph;
		int numNodes = baseGraph.getNodeCount();
		for (int i = 0; i < numNodes; ++i) {
			Object node = baseGraph.getNode(i);
			addNode(node);
			addEdge(root, node);
			for(int j = 0; j < attrs.length; ++j) {
				setAttr(root, attrs[j], getAttr(root, attrs[j]) + getAttr(node, attrs[j]));
			}
		}
		
		int numEdges = baseGraph.getEdgeCount();
		for (int i = 0; i < numEdges; ++i) {
			IEdge edge = baseGraph.getEdge(i);
			int u = indexOf(edge.getFirstNode());
			int v = indexOf(edge.getSecondNode());
			induced[u][v]= induced[v][u] = 1;
		}
	}
	
	public IGraphDataEx getGraph() {
		return baseGraph;
	}
	
	private static double getAttr(Object node, Object attr) {
		return PropOperator.getInstance().getDouble(attr, node);
	}
	
	private static void setAttr(Object node, Object attr, Object value) {
		PropOperator.getInstance().setProperty(node, attr, value);
	}
	
//	private void setWeight(Object node, double weight) {
//		PropOperator.getInstance().setWeight(node, weight);
//	}
//	
//	private double getWeight(Object node) {
//		return PropOperator.getInstance().getWeight(node);
//	}
//	
	public Object[] getNodes() {
		int numNodes = getNodeCount();
		Object[] nodes = new Object[numNodes];
		for (int i = 0; i < numNodes; ++i)
			nodes[i] = getNode(i);
		return nodes;
	}
	
	public IEdge[] getEdges() {
		int numEdges = getEdgeCount();
		IEdge[] edges = new IEdge[numEdges];
		for (int i = 0; i < numEdges; ++i)
			edges[i] = getEdge(i);
		return edges;
	}
	
	public Object[] getLeaves() {
		int numLeaves = baseGraph.getNodeCount();
		Object[] l = new Object[numLeaves];
		for (int i = 0; i < numLeaves; ++i)
			l[i] = baseGraph.getNode(i);
		return l;
	}
	
	public IEdge[] getBaseEdges() {
		int numEdges = baseGraph.getEdgeCount();
		IEdge[] e = new IEdge[numEdges];
		for (int i = 0; i < numEdges; ++i)
			e[i] = baseGraph.getEdge(i);
		return e;
	}
	
	// for unitest
	Object[] copyOfAllNodes() {
		Object[] a = new Object[allNodes.length];
		for (int i = 0; i < allNodes.length; ++i)
			a[i] = allNodes[i];
		return a;
	}
	
	// for unitest
	int[][] copyOfInduced() {
		int n = induced.length;
		int[][] a = new int[n][n];
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				a[i][j] = induced[i][j];
		return a;
	}
	
	public IGraphDataEx getBaseGraph() {
		return baseGraph;
	}
	
	public String[] getNumericAttr() {
		return attrs;
	}

	public void setNumericAttr(String[] attrs) {
		this.attrs = attrs;
	}
	
	public Object getParent(Object node) {
		if (node.equals(root)) 
			return null;
		IEdge[] edges = getEdgesWithSecondNode(node);
		if (edges.length != 1) 
			throw new InvalidTreeException("too many parents!");
		return edges[0].getFirstNode();
	}
	
	public int getHeight() {
		return getHeight(root);
	}

	public int getHeight(Object node) {
		if (node == null)
			return -1;
		IEdge[] edges = getEdgesWithFirstNode(node);
		int res = 0;
		for (IEdge e : edges)
			res = Math.max(res, 1 + getHeight(e.getSecondNode()));
		return res;
	}

	public boolean containsEdge(Object node1, Object node2) {
		return getEdge(node1, node2) != null;
	}

	public boolean isLeaf(Object node) {
		return node != null && getEdgesWithFirstNode(node).length == 0;
	}
	
	/**
	 * get the root of the hierarchy
	 */
	public Object getSuperNode() {
		return root;
	}
	
	/**
	 * get the children of parent
	 */
	public Object[] getSubNodes(Object parent) {
		List edges = (List) m_edgesFromNode1.get(parent);
		if (edges == null || edges.size() == 0)
			return new Object[]{};
		Object[] res = new Object[edges.size()];
		int i = 0;
		for (Object edge : edges) 
			res[i++] = ((IEdge) edge).getSecondNode();
		return res;
	}
	
	/**
	 * get the node according to it's id
	 */
	public Object getNode(String id) {
		return idNode.get(id);
	}

	/**
	 * get all the nodes of the specified height
	 * the leaves' height is zero
	 */
	public Object[] getNodes(int height) {
		return getNodes(root, height);
	}

	/**
	 * get the descendants of parent with specified height 
	 */
	public Object[] getNodes(Object parent, int height) {
		List res = new ArrayList();
		getNodes(res, parent, height);
		return res.toArray();
	}
	
	@SuppressWarnings("unchecked")
	private void getNodes(List res, Object parent, int height  ) {
		int h = getHeight(parent);
		if (h < height)
			return;
		if (h == height) { 
			res.add(parent);
			return;
		}
		for (Object child : getSubNodes(parent))
			getNodes(res, child, height);
	}
	
	/**
	 * return ancestor at specified height (or level)
	 * need improvement
	 */
	public Object getAncestor(Object node, int height) {
		int h = getHeight(node);
		if (h > height)
			return null;
		for (; h < height && node != null; ++h)
			node = getParent(node);
		return node;
	}
	
	public boolean inducedEdge(Object node1, Object node2) {
//		if (isDescendantOf(node1, node2) || isDescendantOf(node2, node1))
//			throw new InvalidArgumentsException(getId(node1) + " and "  + getId(node2) + " has ancestor-descendant relation");
		return induced[indexOf(node1)][indexOf(node2)] > 0;
	}
	
	private String getId(Object node) {
		return PropOperator.getInstance().getID(node);
	}
	
	int indexOf(Object node) {
		return (Integer) nodeIndex.get(node);
	}

	/**
	 * return whether the default view is collapsed
	 */
	public boolean isCollapsed(Object node) {
		return getView().isCollapsed(node);
	}
	
	/**
	 * return whether the descendant is a descendant of ancestor
	 */
	public boolean isDescendantOf(Object ancestor, Object descendant) {
		while ((descendant = getParent(descendant)) != null) 
			if (descendant.equals(ancestor))
				return true;
		return false;
	}
	
	// modification

	/**
	 * set the root of the hierarchy
	 */
	public void setSuperNode(Object node) {
		if (contains(node))
			throw new InvalidArgumentsException("Duplicate node " + getId(node));
		
		addNode(node);
		
		Object[] children = getSubNodes(root);
		for (Object child : children) {
			removeEdge(root, child);
			addEdge(node, child);
		}
		
		for(int j = 0; j < attrs.length; ++j) {
			setAttr(node, attrs[j], getAttr(root, attrs[j]));
		}

		Object t = root;
		root = node;
		removeNode(t);
	}

	
	public void addNode(Object node) {
		if (contains(node))
			throw new InvalidArgumentsException("Duplicate node " + getId(node));
		super.addNode(node);
		newNode(node);
	}
	
	public void removeNode(Object node) {
		if (!contains(node))
			throw new InvalidArgumentsException("Unexisted node " + getId(node));
		if (node.equals(root))
			throw new InvalidArgumentsException("Cannot remove root " + getId(node));
		freeNode(node);
		super.remove(node);
	}
	
	@SuppressWarnings("unchecked")
	private int newNode(Object node) {
		int id = idPool.allocate();
		nodeIndex.put(node, id);
		idNode.put(PropOperator.getInstance().getID(node), node);
		allNodes[id] = node;
		return id;
	}
	
	private void freeNode(Object node) {
		int id = indexOf(node);
		idPool.free(id);
		nodeIndex.remove(node);
		idNode.remove(PropOperator.getInstance().getID(node));
		allNodes[id] = null;
	}

////////////////////////////////////////////////////////////////////
	/**
	 * add node to parent as a child
	 */
	public void addSubNode(Object parent, Object node)  {
		try {
			if (isLeaf(node) && !baseGraph.contains(node))
				baseGraph.addNode(node);
			if (isLeaf(parent) && !parent.equals(root)) {
				if (!baseGraph.contains(parent))
					throw new InvalidTreeException("isolated parent " + PropOperator.getInstance().getID(parent));
				baseGraph.removeNode(parent);
			}
		} catch (InvalidateTypeException  ite) {
			ite.printStackTrace();
		}
		addEdge(parent, node);
	}
///////////////////////////////////////////////////////////////////////
	
	@SuppressWarnings("unchecked")
	public Object[] expandEdge(IEdge edge, Object node) {
		Object node1 = edge.getFirstNode();
		Object node2 = edge.getSecondNode();
		if (node2.equals(node)) {
			Object t = node1;
			node1 = node2;
			node2 = t;
		}
		if (!node1.equals(node))
			throw new InvalidArgumentsException(getId(node) + " is not one of the end of edge " + getId(node1) + " - " + getId(node2));
		if (!inducedEdge(node1, node2))
			throw new InvalidArgumentsException(getId(node1) + " and " + getId(node2) + " are not induced.");
		ArrayList res = new ArrayList();
		for (Object child : getSubNodes(node1))
			if (inducedEdge(child, node2))
				res.add(child);
		return res.toArray();
	}
	
	public void split(Object node, Object[] children) {
		if (contains(node))
			throw new InvalidArgumentsException("Duplicate node " + getId(node));
		Object parent = getParent(children[0]);
		if (parent == null)
			throw new InvalidArgumentsException("no parent");
		for (Object child : children)
			if (!getParent(child).equals(parent))
				throw new InvalidArgumentsException("Children don't have a common parent.");
		
		addNode(node);
		addEdge(parent, node);
		
		for (Object child : children) {
			removeEdge(parent, child);
			addEdge(node, child);
			for(int j = 0; j < attrs.length; ++j) {
				setAttr(node, attrs[j], getAttr(node, attrs[j]) + getAttr(child, attrs[j]));
			}
		}
		
		int u = indexOf(node);
		for (int v = 0; v < induced.length; ++v) 
			if (allNodes[v] != null && !isDescendantOf(allNodes[v], node) && !isDescendantOf(node, allNodes[v])) {
				for (Object child : children) {
					int c = indexOf(child);
					induced[u][v] = (induced[v][u] += induced[c][v]);
				}
			}
	}
	
	public void merge(Object node) {
		if (isLeaf(node))
			throw new InvalidArgumentsException("cannot merge a leaf node " + getId(node));
		Object parent = getParent(node);
		Object[] children = getSubNodes(node);
		int u = indexOf(node);
		for (Object child : children) {
			removeEdge(node, child);
			addEdge(parent, child);
		}
		for (int i = 0; i < induced.length; ++i)
			induced[u][i] = induced[i][u] = 0;
		removeNode(node);	
	}
	
	// view
	
	/**
	 * create a new view
	 */
	public IViewGraph createView() {
		return new ViewGraph(this, attrs, edgeType);
	}
	
	public void setView(IViewGraph view) {
		if(view == view) {
			this.view = view;
		}
	}
	
	/**
	 *  get the default view
	 */
	public IViewGraph getView() {
		if(view == null) {
			view = createView();
		}
		return view;
	}

	/**
	 * get the subgraph of the current view rooted at the specified node
	 */
	public IViewGraph getSubView(Object node) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * get the subview of the current view at specified height
	 */
	public IViewGraph getSubView(int height) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * Get the subview at the specified height of the view rooted at parent
	 */
	public IViewGraph getSubView(Object parent, int height) {
		// TODO Auto-generated method stub
		return null;
	}
	
	// listener action
	// implementation delayed
	
	public void dataCleared(DataEvent e) {
		
	}

	public void dataRefreshed(DataEvent e) {
		
	}

	public void itemAdded(DataEvent e) {
		
	}

	public void itemChanged(DataEvent e) {
		
	}

	public void itemRemoved(DataEvent e) {
		
	}
	
	private static class IdPool {
		int[] next;
		int free;
		
		IdPool(int n) {
			next = new int[n + 1];
			free = n;
			next[free] = 0;
			for (int i = 0; i < n - 1; ++i)
				next[i] = i + 1;
			next[n - 1] = -1;
		}
		
		void free(int id) {
			if (id < 0 || id > next.length - 3)
				throw new InvalidArgumentsException("id out of bound");
			next[id] = next[free];
			next[free] = id;
		}
		
		int allocate() {
			if (next[free] == -1)
				throw new IdPoolOverflowException();
			int t = next[free];
			next[free] = next[t];
			return t;
		}
	}
}

class InvalidTreeException extends RuntimeException {
	private static final long serialVersionUID = 3099770344728257960L;
	
	public InvalidTreeException() {
	}
	
	public InvalidTreeException(String msg) {
		super(msg);
	}
}

class UnexistedNodeException extends RuntimeException {
	private static final long serialVersionUID = -1318878701955640388L;
	
	public UnexistedNodeException() {
	}
	
	public UnexistedNodeException(String msg) {
		super(msg);
	}
}

class InvalidArgumentsException extends RuntimeException {
	private static final long serialVersionUID = 7308431813300008107L;
	
	public InvalidArgumentsException() {
	}
	
	public InvalidArgumentsException(String msg) {
		super(msg);
	}
}

class IdPoolOverflowException extends RuntimeException {
	private static final long serialVersionUID = 6515118355860052512L;
}


