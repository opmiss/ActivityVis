package com.ibm.sdl.data.hierarchy.implv2;

public class ViewStatusItem {

	public boolean isCollapsed = false;
	
}
