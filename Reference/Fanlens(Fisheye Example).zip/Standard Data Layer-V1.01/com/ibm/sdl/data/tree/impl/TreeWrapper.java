/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss(jesse.kriss@us.ibm.com), CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.tree.impl;

import com.ibm.sdl.data.AbstractData;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.ITreeData;
import com.ibm.sdl.util.filter.IItemFilter;

public class TreeWrapper extends AbstractData implements ITreeData {

	private static final long serialVersionUID = 9150245337817239974L;
	private ITreeData tree;
	
	public TreeWrapper() {
	}
	
	public TreeWrapper(ITreeData tree) {
		this.tree = tree;
	}
	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.ITreeData#getParent(java.lang.Object)
	 */
	public Object getParent(Object child) {
		return tree.getParent(child);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.ITreeData#getChild(java.lang.Object, int)
	 */
	public Object getChild(Object parent, int index) {
		return tree.getChild(parent, index);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.ITreeData#getChildCount(java.lang.Object)
	 */
	public int getChildCount(Object parent) {
		return tree.getChildCount(parent);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.ITreeData#getIndexOfChild(java.lang.Object, java.lang.Object)
	 */
	public int getIndexOfChild(Object parent, Object child) {
		return tree.getIndexOfChild(parent, child);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.ITreeData#getRoot()
	 */
	public Object getTreeRoot() {
		return tree.getTreeRoot();
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.ITreeData#isLeaf(java.lang.Object)
	 */
	public boolean isLeaf(Object obj) {
		return tree.isLeaf(obj);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#isDirected()
	 */
	public boolean isDirected() {
		return tree.isDirected();
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#getNodeCount()
	 */
	public int getNodeCount() {
		return tree.getNodeCount();
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#getNode(int)
	 */
	public Object getNode(int index) {
		return tree.getNode(index);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#getNodePairCount()
	 */
	public int getEdgeCount() {
		return tree.getEdgeCount();
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#getNodePair(int)
	 */
	public IEdge getEdge(int index) {
		return getEdge(index);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#getNodePairsWithFirstNode(java.lang.Object)
	 */
	public IEdge[] getEdgesWithFirstNode(Object firstNode) {
		return tree.getEdgesWithFirstNode(firstNode);
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.cue.visualization.api.data.IGraphData#getNodePairsWithSecondNode(java.lang.Object)
	 */
	public IEdge[] getEdgesWithSecondNode(Object secondNode) {
		return tree.getEdgesWithSecondNode(secondNode);
	}
	
	public boolean isEmpty() {
		return tree.isEmpty();
	}
	
	public boolean contains(Object elem) {
		return tree.contains(elem);
	}

}
