/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.sdl.data.tree.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.prop.IWeight;

public class EntityTree extends EntityGraph implements ITreeDataEx {

	private static final long serialVersionUID = -3203978578241080270L;

	public static final String PROP_PARENT_URL = "#PROP_PARENT_URL#";
	
	protected Object m_root = null;
	
	protected int m_height = 0;
	
	public EntityTree() {
		super();
	}
	
	public EntityTree(Object root) {
		super();
		this.setTreeRoot(root);
	}
	
	public void clear() {
		m_root = null;
		super.clear();
	}
	
	public void refresh() {
		refreshDepth();
	}
	 	
	//////////////////////////////////////////////////////////
	// TODO : Implementations of ITreeDataEx
	//////////////////////////////////////////////////////////
	public void setTreeRoot(Object root) {
		PropOperator.getInstance().setProperty(root, PROP_TREENODE_DEPTH, new Integer(0));
		this.m_root = root;
		if(!m_nodes.contains(root)) {
			m_nodes.add(root);
		}
	}
	
	public void changeParent(Object treenode, Object newParent) {
		if(treenode == m_root) {
			return;
		}
		
		Object parent = getParent(treenode);
		
		if(parent == newParent) {
			return;
		}
//		minus(treenode, PropOperator.getInstance().getWeight(treenode));
		remove(parent, treenode);
		
		add(newParent, treenode);
//		plus(treenode, PropOperator.getInstance().getWeight(treenode));
		fireItemChanged(treenode, parent, newParent, DataEvent.STRUCTURE_CHANGED_EVENT);
	}
	
	public void addChild(Object parent, Object child) {
		this.add(child);
		this.add(parent, child);
//		this.plus(child, PropOperator.getInstance().getWeight(child));
//		int depth = getDepth(parent) + 1;
//		PropOperator.getInstance().setProperty(child, PROP_TREENODE_DEPTH, depth);
//		this.m_height = Math.max(m_height, depth);
		fireItemAdded(child, DataEvent.TREE_CHILD_ADDED_EVENT);
	}
	
	public void addChildren(Object parent, Collection children) {
		Iterator it = children.iterator();
		Object child = null;
		
//		int depth = getDepth(parent) + 1;
//		this.m_height = Math.max(m_height, depth);
		
		while(it.hasNext()) {
			child = it.next();
			add(child);
			add(parent, child);
//			plus(child, PropOperator.getInstance().getWeight(child));
//			PropOperator.getInstance().setProperty(child, PROP_TREENODE_DEPTH, depth);
		}
		
		fireItemAdded(children, DataEvent.TREE_CHILDREN_ADDED_EVENT);
	}
	
	public void removeChild(Object node) {
		minus(node, PropOperator.getInstance().getWeight(node));
		removeBranch(node);
//		refreshDepth();
		fireItemRemoved(node, DataEvent.TREE_CHILD_REMOVED_EVENT);
	}
	
	public void removeChildren(Collection children) {
		Iterator it = children.iterator();
		Object node = null;
		while(it.hasNext()) {
			node = it.next();
			minus(node, PropOperator.getInstance().getWeight(node));
			removeBranch(node);
		}
//		refreshDepth();
		fireItemRemoved(children, DataEvent.TREE_CHILDREN_REMOVED_EVENT);
	}
	
	public Object[] getChildren(Object parent, Comparator c) {
		List edges = (List)this.m_edgesFromNode1.get(parent);
		if(edges == null) {
			return null;
		}
		
		List children = new ArrayList(0);
		Iterator it = edges.iterator();
		IEdge edge = null;
		while(it.hasNext()) {
			edge = (IEdge)it.next();
			Object obj = edge.getSecondNode();
			children.add(obj);
		}
		
		Object[] set = children.toArray();
		if(null != c) {
			Arrays.sort(set, c);
		}
		
		return set;
	}
	
	public boolean containsChild(Object parent, Object child) {
		List edges = (List)this.m_edgesFromNode2.get(child);
		
		if(edges == null)return false;
		
		IEdge e = (IEdge)edges.get(0);
		
		if(e == null) return false;
		
		return e.getFirstNode().equals(parent);
	}
	
	/**
	 * Get the height of the tree structure
	 * 
	 * @return the height of the tree structure
	 */
	public int getTreeHeight() {
		return m_height;
	}
	
	public int getDepth(Object node) {
		if(!m_nodes.contains(node)) {
			return -1;
		}
		
		return PropOperator.getInstance().getInteger(PROP_TREENODE_DEPTH, node);
	}
	
	////////////////////////////////////////////////////
	// TODO: Addtional Operations
	////////////////////////////////////////////////////
	public void refreshDepth() {
		m_height = refreshDepth(m_root, 0);
	}
	
	//////////////////////////////////////////////////////////
	// TODO : Implementations of ITreeData
	//////////////////////////////////////////////////////////
	public Object getChild(Object parent, int index) {
		List edges = (List)this.m_edgesFromNode1.get(parent);
		if(edges == null || edges.isEmpty() || index >= edges.size()) {
			return null;
		}
		IEdge edge = (IEdge)edges.get(index);
		return edge.getSecondNode();
	}

	public int getChildCount(Object parent) {
		List edges = (List)this.m_edgesFromNode1.get(parent);
		if(edges == null || edges.isEmpty()) {
			return 0;
		}
		return edges.size();
	}

	public int getIndexOfChild(Object parent, Object child) {
		List edges = (List)this.m_edgesFromNode1.get(parent);
		if(edges == null || edges.isEmpty()) {
			return -1;
		}
		int idx = -1;
		int size = edges.size();
		for(int i = 0; i < size; ++i) {
			IEdge edge = (IEdge)edges.get(i);
			Object node = edge.getSecondNode(); 
			
			if(node != null && node.equals(child)){
				idx = i;
			}
		}
		return idx;
	}
	
	public Object getTreeRoot() {
		return m_root;
	}

	public boolean isLeaf(Object obj) {
		return getChildCount(obj) == 0;
	}
	
	public Object getParent(Object child) {
		
		List edges = (List)this.m_edgesFromNode2.get(child);
		if(edges == null || edges.isEmpty()) {
			return null;
		}
		
		IEdge edge = (IEdge)edges.get(0);
		
		return edge.getFirstNode();
	}
	
	///////////////////////////////////////////////////////
	// TODO: Background Operations
	///////////////////////////////////////////////////////
	protected void removeBranch(Object node) {
		int count = getChildCount(node);
		for(int i = 0; i < count; ++i) {
			this.removeBranch(getChild(node, i));
		}
		this.remove(node);
	}
	
	/**
	 * Calculate the height information of the tree
	 * <br>
	 * This method is only be called when the visual tree is created.
	 * 
	 * @param visParent the root of the tree or the subtree
	 * @param depth the depth of each level
	 * @return the height of the tree or subtree
	 */
	protected int refreshDepth(Object parent, int depth) {
		int size = getChildCount(parent);
		int h = 0;
		
		PropOperator.getInstance().setProperty(parent, PROP_TREENODE_DEPTH, new Integer(depth));
		if(size == 0) {
			h = 1;
		} else {
			Object child = null;
			for(int i = 0; i < size; ++i) {
				child = getChild(parent, i);
				h = Math.max(h, refreshDepth(child, depth + 1) + 1);
			}
		}
		return h;
	}
	
	protected void plus(Object node, double weight) {
		Object parent = getParent(node);
		
		if(null == parent) {
			return;
		}
		
		double w = 0;
		w = PropOperator.getInstance().getWeight(parent);
		if(w == 0D) {
			return;
		}
		w += weight;
		PropOperator.getInstance().setProperty(parent, IWeight.PROP_WEIGHT, new Double(weight));
		plus(parent, weight);
	}
	
	protected void minus(Object node, double weight) {
		Object parent = getParent(node);
		
		if(null == parent) {
			return;
		}
		
		double w = 0;
		w = PropOperator.getInstance().getWeight(parent);
		if(w == 0D) {
			return;
		}
		w -= weight;
		PropOperator.getInstance().setProperty(parent, IWeight.PROP_WEIGHT, new Double(weight));
		
		minus(parent, weight);		
	}

	public Object getAncestor(Object node, int level) {
		Object parent = getParent(node);
		
		if(null == parent) {
			return null;
		}
		
		if(level == getDepth(parent)) {
			return parent;
		}
		
		return getAncestor(parent, level);
	}
}
