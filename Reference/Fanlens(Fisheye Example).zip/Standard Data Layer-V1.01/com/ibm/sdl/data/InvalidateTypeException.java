/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data;

public class InvalidateTypeException extends Exception {

	private static final long serialVersionUID = 4531637082724953355L;

	public InvalidateTypeException() {
		super();
	}
	
	public InvalidateTypeException(String msg) {
		super(msg);
	}
}
