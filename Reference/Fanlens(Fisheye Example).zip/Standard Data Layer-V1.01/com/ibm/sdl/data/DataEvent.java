/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data;

import java.util.EventObject;

public class DataEvent extends EventObject {

	public static final int DATA_CLEAR_EVENT = -1;
	public static final int NODE_ADDED_EVENT = 0;
	public static final int NODE_COLLECTION_ADDED_EVENT = 1;
	public static final int EDGE_ADDED_EVENT = 2;
	public static final int EDGE_COLLECTION_ADDED_EVENT = 3;
	public static final int NODE_REMOVED_EVENT = 4;
	public static final int NODE_COLLECTION_REMOVED_EVENT = 5;
	public static final int EDGE_REMOVED_EVENT = 6;
	public static final int EDGE_COLLECTION_REMOVED_EVENT = 7;
	public static final int PROP_CHANGED_EVENT = 8;
	public static final int STRUCTURE_CHANGED_EVENT = 9;
	
	public static final int TREE_CHILD_ADDED_EVENT = 10;
	public static final int TREE_CHILDREN_ADDED_EVENT = 11;
	public static final int TREE_CHILD_REMOVED_EVENT = 12;
	public static final int TREE_CHILDREN_REMOVED_EVENT = 13;
	
	public static final int TABLE_ROW_ADDED_EVENT = 14;
	public static final int TABLE_ROW_REMOVED_EVENT = 15;
	public static final int TABLE_COLUMN_ADDED_EVENT = 16;
	public static final int TABLE_COLUMN_REMOVED_EVENT = 17;
	public static final int TABLE_CELL_CHANGED_EVENT = 18;
	public static final int TABLE_ROWNAME_CHANGED_EVENT = 19;
	public static final int TABLE_COLNAME_CHANGED_EVENT = 20;
	
	private static final long serialVersionUID = 1L;
	protected Object m_key;
	protected Object m_value;
	protected Object m_item;
	protected Object m_invoker;
	protected int m_type;
	
	public DataEvent() {
		this(null);
	}
	
	public DataEvent(Object source) {
		super(source);
	}
	
	public DataEvent(Object source, Object item) {
		this(source);
		m_item = item;
	}
	
	public DataEvent(Object source, Object item, Object key, Object value) {
		this(source, item);
		this.m_key = key;
		this.m_value = value;
	}
	
	public void setInvoker(Object invoker) {
		this.m_invoker = invoker;
	}
	
	public Object getInvoker() {
		return m_invoker;
	}
	
	public void setSource(Object source) {
		this.source = source;
	}
	
	public void setKey(Object key) {
		m_key = key;
	}
	
	public void setValue(Object value) {
		m_value = value;
	}
	
	public void setItem(Object item) {
		m_item = item;
	}
	
	public Object getKey() {
		return m_key;
	}
	
	public Object getValue() {
		return m_value;
	}
	
	public Object getItem() {
		return m_item;
	}
	
	public void setType(int type) {
		m_type = type;
	}
	
	public int getType() {
		return m_type;
	}
}
