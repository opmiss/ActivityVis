/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import java.text.DateFormat;
import java.util.Date;

import com.ibm.sdl.data.api.IColumn.HasDate;
import com.ibm.sdl.data.api.IColumn.HasObject;

/**
 * @author Jesse Kriss
 *
 */
public abstract class DateColumn extends AbstractColumn implements HasDate, HasObject {

	private static Class m_type = Date.class;
	private DateFormat dateFormat = null;
	
	public DateColumn() {
		super();
	}
	
	public DateColumn(String name) {
		super(name);
	}

	public Class getType() {
		return m_type;
	}

	public void setDateFormat(DateFormat dateFormat) {
		this.dateFormat = dateFormat;
	}
	
	public Date getDate(int i) {
		return getDate(getDataTable().getRow(i));
	}
	
	public Object getObject(int i) {
		return getDate(i);
	}

	public String toString(int i) {
		if (dateFormat != null)
			return dateFormat.format(getDate(i));
		else
			return getDate(i).toString();
	}
	
	public abstract Date getDate(Object obj);

}
