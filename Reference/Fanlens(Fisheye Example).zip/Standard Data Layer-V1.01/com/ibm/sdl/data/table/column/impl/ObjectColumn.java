/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import com.ibm.sdl.data.api.IColumn.HasObject;

/**
 * @author Jesse Kriss
 *
 */
public abstract class ObjectColumn extends AbstractColumn implements HasObject {

	private static Class m_type = Object.class;
	
	public ObjectColumn() {
		super();
	}
	
	public ObjectColumn(String name) {
		super(name);
	}
	
	public ObjectColumn(String name, Class[] classes) {
		super(name);
	}

	public Object getObject(int i) {
		return getObject(getDataTable().getRow(i));
	}
	
	public String getString(int i) {
		return getObject(i).toString();
	}
	
	public abstract Object getObject(Object obj);

	public Class getType() {
		return m_type;
	}

}
