/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import com.ibm.sdl.data.api.IColumn.HasBoolean;
import com.ibm.sdl.data.api.IColumn.HasInt;
import com.ibm.sdl.data.api.IColumn.HasObject;
import com.ibm.sdl.data.api.IColumn.HasString;

public abstract class BooleanColumn extends AbstractColumn implements HasBoolean, HasInt, HasString, HasObject {

	private static Class m_type = boolean.class;
	
	public BooleanColumn() {
		super();
	}
	
	public BooleanColumn(String name) {
		super(name);
	}

	public Class getType() {
		return m_type;
	}

	public boolean getBoolean(int i) {
		return getBoolean(getDataTable().getRow(i));
	}
	
	public int getInt(int i) {
		return getBoolean(i) ? 1 : 0;
	}
	
	public String getString(int i) {
		return String.valueOf(getBoolean(i));
	}
	
	public Object getObject(int i) {
		return new Boolean(getBoolean(i));
	}
	
	public abstract boolean getBoolean(Object obj);
	
}
