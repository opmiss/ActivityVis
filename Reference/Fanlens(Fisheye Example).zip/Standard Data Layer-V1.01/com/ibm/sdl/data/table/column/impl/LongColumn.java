/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import com.ibm.sdl.data.api.IColumn.HasLong;
import com.ibm.sdl.data.api.IColumn.HasObject;
import com.ibm.sdl.data.api.IColumn.HasString;

public abstract class LongColumn extends AbstractColumn implements HasLong, HasString, HasObject {

	private static Class m_type = long.class;
	
	public LongColumn() {
		super();
	}
	
	public LongColumn(String name) {
		super(name);
	}

	public Class getType() {
		return m_type;
	}

	public long getLong(int i) {
		return getLong(getDataTable().getRow(i));
	}
	
	public String getString(int i) {
		return String.valueOf(getLong(i));
	}
	
	public Object getObject(int i) {
		return new Long(getLong(i));
	}
	
	public abstract long getLong(Object r);
}
