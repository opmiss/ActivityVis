/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.ibm.sdl.data.AbstractData;
import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.IData;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IColumn;
import com.ibm.sdl.data.api.ITableDataEx;
import com.ibm.sdl.data.table.column.impl.AbstractColumn;
import com.ibm.sdl.data.table.column.impl.DateColumn;
import com.ibm.sdl.data.table.column.impl.DoubleColumn;
import com.ibm.sdl.data.table.column.impl.IntColumn;
import com.ibm.sdl.data.table.column.impl.LongColumn;
import com.ibm.sdl.data.table.column.impl.ObjectColumn;
import com.ibm.sdl.data.table.column.impl.StringColumn;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IProperty;
import com.ibm.sdl.util.prop.Property;

public class EntityTable extends AbstractData implements ITableDataEx, IData {

	private static final long serialVersionUID = -4698646950615203281L;
	
	protected List m_rows = null;
	protected List m_schemes = null;
	protected List m_colnames = null;
	protected List m_rownames = null;
	protected List m_columns = null;
	
	protected Class m_rowtype = Property.class;
	
	private Map m_colMap = null;
	private Map m_colnameMap = null;
	private Map m_rownameMap = null;
	
	public EntityTable() {
		super();
		
		m_rows = new ArrayList(0);
		m_schemes = new ArrayList(0);
		m_colnames = new ArrayList(0);
		m_rownames = new ArrayList(0);
		m_columns = new ArrayList(0);
		m_colMap = new HashMap(0);
		m_colnameMap = new HashMap(0);
		m_rownameMap = new HashMap(0);
		
		m_colnames.add(PROP_ROWNAME);
		m_schemes.add(String.class);
	}
	
	public EntityTable(String[] colName, Class[] schemes) throws InvalidateDataException {
		this();
		for(int i = 0; i < colName.length; ++i) {
			m_colnames.add(colName[i]);
		}
		for(int i = 0; i < schemes.length; ++i) {
			m_schemes.add(schemes[i]);
		}
//		Collections.addAll(m_colnames, colName);
//		Collections.addAll(m_schemes, schemes);
		create();
	}
	
	public void setRowType(Class type) {
		m_rowtype = type;
	}
	
	public Class getRowType() {
		return m_rowtype;
	}
	
	public void clear() {
		m_rows.clear();
		m_rownames.clear();
		m_rownameMap.clear();
		super.clear();
	}
	
	public void clearAll() {
		m_rows.clear();
		m_rownames.clear();
		m_rownameMap.clear();
		m_colMap.clear();
		m_colnameMap.clear();
		m_colnames.clear();
		m_schemes.clear();
		m_columns.clear();
		super.clear();
	}
	
	/////////////////////////////////////////////////////////////
	// TODO: implementations of ITableDataEx
	/////////////////////////////////////////////////////////////
	public boolean isEmpty() {
		return m_rows.isEmpty();
	}
	
	public boolean contains(Object elem) {
		return m_rows.contains(elem);
	}
	
	public void setData(Object[][] data) {
		try {
			int colcount = m_colnames.size();
			int rowcount = data.length / colcount + 1;
			IProperty node = null;
			for(int i = 0; i < rowcount; ++i) {
				node = (IProperty)m_rowtype.newInstance();
				for(int j = 0; j < colcount; ++j) {
					node.addProperty(m_colnames.get(j), data[i][j]);
				}
				m_rows.add(node);
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
	}
	
	public void setColumnNames(String[] names) throws InvalidateDataException {
		m_colnames.clear();
		m_colnames.add(PROP_ROWNAME);
		for(int i = 0; i < names.length; ++i) {
			m_colnames.add(names[i]);
		}
//		Collections.addAll(m_colnames, names);
		if(!m_schemes.isEmpty()) {
			System.out.println(m_schemes);
			System.out.println(m_colnames);
			create();
		}
	}

	public void setSchemes(Class[] schemes) throws InvalidateDataException {
		m_schemes.clear();
		m_schemes.add(String.class);
		for(int i = 0; i < schemes.length; ++i) {
			m_schemes.add(schemes[i]);
		}
//		Collections.addAll(m_schemes, schemes);
		if(!m_colnames.isEmpty()) {
			create();
		}
	}
	
	public Class[] getSchemes() {
		return (Class[])m_schemes.toArray(new Class[]{});
	}
	
	////////////////////////////////////////////////////////////////
	// TODO: Value Operations
	////////////////////////////////////////////////////////////////
	public Object getValue(int row, int col) {
		if(null == m_columns) {
			return null;
		}
		
		IColumn c = (IColumn)m_columns.get(col);
		
		if(c == null) {
			return null;
		}
		
		Class type = c.getType();
		
		if(type.equals(double.class) || type.equals(Double.class)) {
			return new Double(c.getDouble(row));
		} else if(type.equals(int.class) || type.equals(Integer.class)) {
			return new Integer(c.getInt(row));
		} else if(type.equals(long.class) || type.equals(Long.class)) {
			return new Long(c.getLong(row));
		} else if(type.equals(String.class)) {
			return c.getString(row);
		} else if(type.equals(Date.class)) {
			return c.getDate(row);
		} else {
			return c.getObject(row);
		}
	}
	
	public void setValue(int row, int col, Object value) {
		Object r = set(row, col, value);
		if(r == null) return;
		fireItemChanged(r, m_columns.get(col), value, DataEvent.TABLE_CELL_CHANGED_EVENT);
	}
	
	public Object getValue(String row, String col) {
		
		int ridx = getRowIndex(row);
		
		if(ridx == -1) {
			return null;
		}
		
		IColumn c = getColumn(col);
		
		if(null == c) {
			return null;
		}
		
		return c.getObject(ridx);
	}
	
	public void addValue(String rowname, String colname, Object value) {
		
		Class scheme = value.getClass();
		int csize = 0;
		
		int cidx = getColumnIndex(colname);
		if(cidx == -1) {
			cidx = m_columns.size();
			addColumn(scheme, colname);
		}
		
		int ridx = getRowIndex(rowname);
		if(ridx == -1) {
			try {
				ridx = m_rows.size();
				Object row = m_rowtype.newInstance();
				addRow(rowname, row);
//				for(int i = 0; i < csize; ++i) {
//					IColumn c = (IColumn)m_columns.get(i);
//					Class s = (Class)m_schemes.get(i);
//					formatRow(s, c.getName(), row);
//				}
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvalidateTypeException e) {
				e.printStackTrace();
			}
		}
		setValue(ridx, cidx, value);
	}
	
	//////////////////////////////////////////////////////////////
	// TODO: row operations
	//////////////////////////////////////////////////////////////
	public Object[] getRows(IItemFilter filter, Comparator c) {
		if(filter == null) {
			return m_rows.toArray();
		}
		
		List temp = new ArrayList(0);
		Iterator it = m_rows.iterator();
		Object node = null;
		while(it.hasNext()) {
			node = it.next();
			if(filter.accept(node)) {
				temp.add(node);
			}
		}
		
		if(null != c) {
			Collections.sort(temp, c);
		}
		
		return temp.toArray();
	}
	
	public int getRowCount() {
		return m_rows.size();
	}

	public Object getRow(int i) {
		return m_rows.get(i);
	}

	public Object getRow(String name) {
		int index = ((Integer)m_rownameMap.get(name)).intValue();
		return m_rows.get(index);
	}
	
	public void addRow(String name, Object row) throws InvalidateTypeException {
		
		if(!PropOperator.isSubClassOf(row.getClass(), m_rowtype)) {
			throw new InvalidateTypeException("Miss match of the row type");
		}
		
		PropOperator.getInstance().setProperty(row, PROP_ROWNAME, name);
		m_rownameMap.put(name, new Integer(m_rows.size()));
		m_rownames.add(name);
		m_rows.add(row);
		fireItemAdded(row, DataEvent.TABLE_ROW_ADDED_EVENT);
	}
	
	public void addRow(Object row) throws InvalidateTypeException {
		String name = "" + m_rows.size();
		addRow(name, row);
	}
	
	public void removeRow(Object row) {
		String name = getRowName(row);
		removeRow(name);
	}

	public Object removeRow(String name) {
		int idx = ((Integer)m_rownameMap.remove(name)).intValue();
		if(idx == -1) {
			return null;
		}
		m_rownames.remove(idx);
		Object r = m_rows.remove(idx);
		fireItemRemoved(r, DataEvent.TABLE_ROW_REMOVED_EVENT);
		return r;
	}

	public Object removeRow(int idx) {
		if(idx < 0 || idx > m_rows.size()) {
			return null;
		}
		Object r = m_rows.remove(idx);
		m_rownameMap.remove(m_rownames.remove(idx));
		fireItemRemoved(r, DataEvent.TABLE_ROW_REMOVED_EVENT);
		return r;
	}

	public void setRowName(int row, String name) {
		Object r = m_rows.get(row);
		String oldname = getRowName(row);
		PropOperator.getInstance().setProperty(r, PROP_ROWNAME, name);
		
		Object value = m_rownameMap.remove(oldname);
		m_rownameMap.put(name, value);
		
		Collections.replaceAll(m_rownames, oldname, name);
		
		fireItemChanged(new Integer(row), getColumn(PROP_ROWNAME), name, DataEvent.TABLE_ROWNAME_CHANGED_EVENT);
	}

	public int getRowIndex(Object row) {		
		String name = (String)PropOperator.getInstance().getProperty(PROP_ROWNAME, row);
		return getRowIndex(name);
	}
	
	public int getRowIndex(String name) {
		Object obj = m_rownameMap.get(name);
		return obj == null ? -1 : ((Integer)obj).intValue();
	}
	
	public String getRowName(int row) {
		return (String)m_rownames.get(row);
	}
	
	public String getRowName(Object row) {
		int idx = getRowIndex(row);
		return (String)m_rownames.get(idx);
	}

	///////////////////////////////////////////////////////////
	// TODO: Column Operations
	///////////////////////////////////////////////////////////
	public int getColumnCount() {
		return m_columns.size();
	}

	public int getColumnIndex(IColumn c) {
		return getColumnIndex(c.getName());
	}
	
	public int getColumnIndex(String name) {
		Object obj = m_colnameMap.get(name);
		return obj == null ? -1 : ((Integer)obj).intValue();
	}

	public String[] getColumnNames() {
		return (String[])m_colnames.toArray(new String[]{});
	}

	public IColumn getColumn(String columnName) {
		if(m_columns.isEmpty()) {
			return null;
		}
		
		Object obj = m_colnameMap.get(columnName);
		
		int index = obj == null ? -1 : ((Integer)obj).intValue();
		
		if(index < 0 || index > m_columns.size()) {
			return null;
		}
		
		return (IColumn)m_columns.get(index);
	}

	public IColumn[] getColumns() {
		if(m_columns.isEmpty()) {
			return null;
		}
		return (IColumn[])m_columns.toArray(new IColumn[]{});
	}

	public IColumn[] getColumns(Class valueType) {
		try {
			if(null == m_columns) {
				create();
			}
			if(valueType.equals(Integer.class)) {
				valueType = int.class;
			} else if(valueType.equals(Long.class)) {
				valueType = long.class;
			} else if(valueType.equals(Double.class)) {
				valueType = double.class;
			}
			List list = (List)m_colMap.get(valueType);
			return list == null ? null : (IColumn[])list.toArray(new IColumn[]{});
		} catch (InvalidateDataException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public IColumn addColumn(Class scheme, String name) {
		int index = m_columns.size();
		IColumn c = add(index, scheme, name);
		if(null != c) {
			fireItemAdded(c, DataEvent.TABLE_COLUMN_ADDED_EVENT);
		}
		return c;
	}
	
	public IColumn addColumn(int index, Class scheme, String name) {
		IColumn c = add(index, scheme, name);
		if(c != null) {
			fireItemAdded(c, DataEvent.TABLE_COLUMN_ADDED_EVENT);
		}
		return c;
	}

	public void removeColumn(IColumn col) {
		remove(col);
		fireItemRemoved(col, DataEvent.TABLE_COLUMN_REMOVED_EVENT);
	}

	public IColumn removeColumn(int index) {
		IColumn c = remove(index);
		fireItemRemoved(c, DataEvent.TABLE_COLUMN_REMOVED_EVENT);
		return null;
	}

	public IColumn removeColumn(String name) {
		IColumn c = remove(name);
		fireItemRemoved(c, DataEvent.TABLE_COLUMN_REMOVED_EVENT);
		return null;
	}

	
	////////////////////////////////////////////////////////////
	// TODO: background operations
	////////////////////////////////////////////////////////////
	protected Object set(int row, int col, Object value) {
		if(m_columns.isEmpty()) {
			return null;
		}
		
		IColumn c = (IColumn)m_columns.get(col);
		
		Object r = m_rows.get(row);
		PropOperator.getInstance().setProperty(r, c.getName(), value);
		return r;
	}
	
	protected IColumn add(int index, Class scheme, String name) {
		IColumn c = getColumn(name);
		
		if(c == null) {
			c = create(scheme, name);
			
			if(scheme.equals(int.class) || scheme.equals(Integer.class) || 
			   scheme.equals(double.class) || scheme.equals(Double.class) || 
			   scheme.equals(long.class) || scheme.equals(Long.class) ||
			   scheme.equals(short.class) || scheme.equals(Short.class) || 
			   scheme.equals(BigDecimal.class)) {
				addColumnIntoPool(Number.class, name, c);
			}
			
			addColumnIntoPool(scheme, name, c);
			m_columns.add(index, c);
			m_schemes.add(index, scheme);
			m_colnames.add(index, name);;

//			int size = m_rows.size();
//			for(int i = 0; i < size; ++i) {
//				formatRow(scheme, name, m_rows.get(i));
//			}
			
			return c;
		} else {
			return null;
		}
	}
	
	protected void remove(IColumn col) {
		int idx = m_columns.indexOf(col);
		remove(idx);
	}
	
	protected IColumn remove(String name) {
		IColumn c = getColumn(name);
		if(c != null) {
			remove(c);
		}
		return c;
	}
	
	protected IColumn remove(int idx) {
		
		int csize = m_columns.size();
		if(idx >= csize || idx < 0) {
			return null;
		}
				
		IColumn c = (IColumn)m_columns.remove(idx);
		Class type = (Class)m_schemes.remove(idx);
		String name = (String)m_colnames.remove(idx);
		removeColumnFromPool(type, name, c);
		
		int size = m_rows.size();
		for(int i = 0; i < size; ++i) {
			Object r = m_rows.get(i);
			PropOperator.getInstance().removeProperty(r, c);
		}
		return c;
	}
	
	protected IColumn create(Class scheme, String name) {
		
		IColumn column = null;
		
		if(double.class.equals(scheme) || Double.class.equals(scheme)) {
			column = new DoubleColumn(name) {
				public double getDouble(Object r) {
					return PropOperator.getInstance().getDouble(getName(), r);
				}
			};
			addColumnIntoPool(double.class, name, column);
		} else if(int.class.equals(scheme) || Integer.class.equals(scheme)) {
			column = new IntColumn(name) {
				public int getInt(Object r) {
					return PropOperator.getInstance().getInteger(getName(), r);
				}
			};
			addColumnIntoPool(int.class, name, column);
		} else if(long.class.equals(scheme) || Long.class.equals(scheme)) {
			column = new LongColumn(name) {
				public long getLong(Object r) {
					return PropOperator.getInstance().getLong(getName(), r);
				}
			};
			addColumnIntoPool(long.class, name, column);
		} else if(String.class.equals(scheme)) {
			column = new StringColumn(name) {
				public String getString(Object r) {
					return PropOperator.getInstance().getString(getName(), r);
				}
			};
			addColumnIntoPool(String.class, name, column);
		} else if(Date.class.equals(scheme)) {
			column = new DateColumn(name) {
				public Date getDate(Object r) {
					return PropOperator.getInstance().getDate(getName(), r);
				}
			};
			addColumnIntoPool(Date.class, name, column);
		} else {
			column = new ObjectColumn(name) {
				public Object getObject(Object r) {
					return PropOperator.getInstance().getProperty(getName(), r);
				}
			};
			addColumnIntoPool(Object.class, name, column);
		}
		
		if(scheme.equals(int.class) || scheme.equals(Integer.class) || 
				   scheme.equals(double.class) || scheme.equals(Double.class) || 
				   scheme.equals(long.class) || scheme.equals(Long.class) ||
				   scheme.equals(short.class) || scheme.equals(Short.class) || 
				   scheme.equals(BigDecimal.class)) {
			addColumnIntoPool(Number.class, name, column);
		}
		
		((AbstractColumn)column).setTable(this);
		
		return column;
	}
	
	private void create() throws InvalidateDataException {
		
		if(m_schemes.isEmpty()) {
			throw new InvalidateDataException("The schemes of the table columns is null");
		}
		
		if(m_colnames.isEmpty()) {
			throw new InvalidateDataException("The names of the table columns is null");
		}
		
		if(m_schemes.size() != m_colnames.size()) {
			throw new InvalidateDataException("Mismatch of the schemes and the column names");
		}
		
		m_columns.clear();
		m_colnameMap.clear();
		m_colMap.clear();
		int size = m_schemes.size();
		for(int i = 0; i < size; ++i) {
			IColumn c = create((Class)m_schemes.get(i), (String)m_colnames.get(i));
			m_columns.add(c);
		}
		System.gc();
	}
	
	private void addColumnIntoPool(Class type, String name, IColumn column) {
		List list = (List)m_colMap.get(type);
		if(null == list) {
			list = new ArrayList(1);
			list.add(column);
			m_colMap.put(type, list);
		} else {
			list.add(column);
		}
		m_colnameMap.put(name, new Integer(m_columns.size()));
	}
	
	private void removeColumnFromPool(Class type, String name, IColumn column) {
		m_colnameMap.remove(name);
		List list = (List)m_colMap.get(type);
		if(null == list) {
			return;
		} else {
			list.remove(column);
		}
	}
	
	private void formatRow(Class scheme, String name, Object row) {
		if(double.class.equals(scheme) || Double.class.equals(scheme)) {
			PropOperator.getInstance().setProperty(row, name, new Double(0D));
		} else if(int.class.equals(scheme) || Integer.class.equals(scheme)) {
			PropOperator.getInstance().setProperty(row, name, new Integer(0));
		} else if(long.class.equals(scheme) || Long.class.equals(scheme)) {
			PropOperator.getInstance().setProperty(row, name, new Long(0L));
		} else if(String.class.equals(scheme)) {
			PropOperator.getInstance().setProperty(row, name, "");
		} else if(Date.class.equals(scheme)) {
			PropOperator.getInstance().setProperty(row, name, new Date());
		} else {
			PropOperator.getInstance().setProperty(row, name, "");
		}
	}
}
