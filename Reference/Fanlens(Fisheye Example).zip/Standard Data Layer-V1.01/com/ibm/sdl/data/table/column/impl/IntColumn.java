/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import com.ibm.sdl.data.api.IColumn.HasInt;
import com.ibm.sdl.data.api.IColumn.HasObject;
import com.ibm.sdl.data.api.IColumn.HasString;

public abstract class IntColumn extends AbstractColumn implements HasInt, HasString, HasObject {

	private static Class m_type = int.class;
	
	public IntColumn() {
		super();
	}
	
	public IntColumn(String name) {
		super(name);
	}

	public int getInt(int i) {
		return getInt(getDataTable().getRow(i));
	}
	
	public String getString(int i) {
		return String.valueOf(getInt(i));
	}
	
	public Object getObject(int i) {
		return new Integer(getInt(i));
	}
	
	public abstract int getInt(Object obj);

	public Class getType() {
		return m_type;
	}

}
