/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import java.util.Date;

import com.ibm.sdl.data.api.IColumn;
import com.ibm.sdl.data.api.ITableData;

public class AbstractColumn implements IColumn {

	private static final long serialVersionUID = -3314428552489485048L;
	private String name;
	private Class type = null; 
	private ITableData table;
	
	private static final String ERROR = "column doesn't contain values of type ";
	
	public AbstractColumn() {
		this("");
	}
	
	public AbstractColumn(String name) {
		this.name = name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setTable(ITableData table) {
		this.table = table;
	}
	
	public ITableData getDataTable() {
		return table;
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getClasses()
	 */
	public Class getType() {
		return type;
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getInt(int)
	 */
	public int getInt(Object obj) {
		throw new DataTypeException(ERROR + "int");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getDouble(int)
	 */
	public double getDouble(Object obj) {
		throw new DataTypeException(ERROR + "double");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getBoolean(int)
	 */
	public boolean getBoolean(Object obj) {
		throw new DataTypeException(ERROR + "boolean");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getLong(int)
	 */
	public long getLong(Object obj) {
		throw new DataTypeException(ERROR + "long");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getString(int)
	 */
	public String getString(Object obj) {
		throw new DataTypeException(ERROR + "String");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getDate(int)
	 */
	public Date getDate(Object obj) {
		throw new DataTypeException(ERROR + "Date");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getObject(int)
	 */
	public Object getObject(Object obj) {
		throw new DataTypeException(ERROR + "Object");
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getInt(int)
	 */
	public int getInt(int i) {
		return getInt(table.getRow(i));
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getDouble(int)
	 */
	public double getDouble(int i) {
		return getDouble(table.getRow(i));
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getBoolean(int)
	 */
	public boolean getBoolean(int i) {
		return getBoolean(table.getRow(i));
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getLong(int)
	 */
	public long getLong(int i) {
		return getLong(table.getRow(i));
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getString(int)
	 */
	public String getString(int i) {
		return getString(table.getRow(i));
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getDate(int)
	 */
	public Date getDate(int i) {
		return getDate(table.getRow(i));
	}

	/* (non-Javadoc)
	 * @see com.ibm.research.vistools.data.api.IColumn#getObject(int)
	 */
	public Object getObject(int i) {
		return getObject(table.getRow(i));
	}
	
}
