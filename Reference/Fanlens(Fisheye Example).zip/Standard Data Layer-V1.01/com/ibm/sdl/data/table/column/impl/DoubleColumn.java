/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import com.ibm.sdl.data.api.IColumn.HasDouble;
import com.ibm.sdl.data.api.IColumn.HasInt;
import com.ibm.sdl.data.api.IColumn.HasObject;
import com.ibm.sdl.data.api.IColumn.HasString;

/**
 * @author Jesse Kriss
 *
 */
public abstract class DoubleColumn extends AbstractColumn implements HasDouble, HasInt, HasString, HasObject {

	private static Class m_type = double.class;
	
	public DoubleColumn() {
		super();
	}
	
	public DoubleColumn(String name) {
		super(name);
	}

	public Class getType() {
		return m_type;
	}

	public double getDouble(int i) {
		return getDouble(getDataTable().getRow(i));
	}
	
	public int getInt(int i) {
		return (int)getDouble(i);
	}
	
	public String getString(int i) {
		return String.valueOf(getDouble(i));
	}
	
	public Object getObject(int i) {
		return new Double(getInt(i));
	}
	
	public abstract double getDouble(Object r);
}
