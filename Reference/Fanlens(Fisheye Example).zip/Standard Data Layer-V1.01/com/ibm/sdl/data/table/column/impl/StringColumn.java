/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

import com.ibm.sdl.data.api.IColumn.HasObject;
import com.ibm.sdl.data.api.IColumn.HasString;

public abstract class StringColumn extends AbstractColumn implements HasString, HasObject {

	private static Class m_type = String.class;
	
	public StringColumn() {
		super();
	}
	
	public StringColumn(String name) {
		super(name);
	}

	public Class getType() {
		return m_type;
	}

	public String getString(int i) {
		return getString(getDataTable().getRow(i));
	}
	
	public Object getObject(int i) {
		return getString(i);
	}

	public abstract String getString(Object obj);

}
