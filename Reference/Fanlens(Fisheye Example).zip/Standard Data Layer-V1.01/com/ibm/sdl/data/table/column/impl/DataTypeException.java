/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.table.column.impl;

public class DataTypeException extends RuntimeException {

	private static final long serialVersionUID = -1801215631740286658L;

	public DataTypeException() {
		super("");
	}
	
	public DataTypeException(String message) {
		super(message);
	}
	
}
