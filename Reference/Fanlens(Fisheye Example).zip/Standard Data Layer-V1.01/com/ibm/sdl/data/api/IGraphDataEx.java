/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import java.util.Collection;
import java.util.Comparator;

import com.ibm.sdl.data.IData;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.util.filter.IItemFilter;

public interface IGraphDataEx extends IGraphData, IData {
	
	public Object[] getNodes(Object[] a, IItemFilter filter, Comparator c);
	
	public Object[] getNodes(IItemFilter filter, Comparator c);
	
	public IEdge[] getEdges(IItemFilter filter, Comparator c);
	
	public ITreeDataEx getSpanningTree(Object root);
	
	public void setDirected(boolean bDirected);
	
	public void addNode(Object node) throws InvalidateTypeException;
	
	public void addNodes(Collection nodes) throws InvalidateTypeException;
	
	public void addNodes(Object[] nodes) throws InvalidateTypeException;
		
	public void removeNode(Object node) throws InvalidateTypeException;
	
	public void removeNodes(Collection nodes) throws InvalidateTypeException;
	
	public IEdge addEdge(Object node1, Object node2) throws InvalidateTypeException;
	
	public void addEdge(IEdge edge) throws InvalidateDataException;
	
	public void addEdges(Collection edges) throws InvalidateDataException;
	
	public void addEdges(IEdge[] edges) throws InvalidateDataException;
	
	public void removeEdge(Object node1, Object node2) throws InvalidateTypeException;
	
	public void removeEdge(IEdge edge) throws InvalidateTypeException;
	
	public IEdge getEdge(Object node1, Object node2);
	
	public void removeEdges(Collection edeges) throws InvalidateTypeException;
	
	public void changeProperty(Object elem, Object key, Object prop);
	
	public int getDegrees(Object node);
	
	public int getInDegree(Object node);
	
	public int getOutDegree(Object node);

}
