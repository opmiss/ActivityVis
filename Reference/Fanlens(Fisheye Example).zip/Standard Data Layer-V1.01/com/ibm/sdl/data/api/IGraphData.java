/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import com.ibm.sdl.data.IData;

public interface IGraphData extends IData {

	public boolean isDirected();
	
	public int getNodeCount();
	public Object getNode(int index);
	
	public int getEdgeCount();
	public IEdge getEdge(int index);
	
	public IEdge[] getEdgesWithFirstNode(Object firstNode);
	public IEdge[] getEdgesWithSecondNode(Object secondNode);
	
}
