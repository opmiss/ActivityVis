/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import com.ibm.sdl.data.IData;

public interface ITableData extends IData {

	public int getRowCount();
	public Object getRow(int i);

	public String[] getColumnNames();
	public IColumn getColumn(String columnName);
	public IColumn[] getColumns();
	public IColumn[] getColumns(Class valueType);
}