package com.ibm.sdl.data.api;

import com.ibm.sdl.util.filter.IItemFilter;


public interface ICubeData {

	public void setFactFields(Object[] fields);
	
	public Object[] getFactFields();
	
	public Object getFactField(int field);
	
	public int getFactFieldCount();
	
	public void setDimensions(Object[][] dimensions);
	
	public Object[][] getDimensions();
	
	public int size();

	public int getDimensionCount();
	
	public int getDimensionSize(int dimension);

	public Object[] getDimension(int dimension);
	
	public Object[] getDimensionVector(Object elem);
	
	public Object[] getDiemensionVector(int[] ivector);
	
	public int[] getVector(Object elem);
	
	public Object getCubicElem(int[] vector);
	
	public Object getCubicElem(int idx);
	
	public void addCubicElem(int[] vector, Object value);

	public boolean isEmpty();

	public boolean contains(Object elem);
	
	public void clear();
	
	public int vectorToIndex(int[] vector);
	
	public int[] indexToVector(int idx);
	
	public Object[] getCubics(IItemFilter filter);
	
	public double getMaxValue(int field);
	
	public double getMinValue(int field);
	
	public double[] getMaxValues();
	
	public double[] getMinValues();
	
	public void setMaxValues(double[] values);
	
	public void setMinValues(double[] values);
}
