/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import java.io.Serializable;
import java.util.Date;

public interface IColumn extends Serializable{

	public String getName();
	public Class getType();
	public void setName(String name);
	
	ITableData getDataTable();
	
	public int getInt(int i);
	public double getDouble(int i);
	public boolean getBoolean(int i);
	public long getLong(int i);
	public String getString(int i);
	public Date getDate(int i);
	public Object getObject(int i);

//	public int getInt(Object obj);
//	public double getDouble(Object obj);
//	public boolean getBoolean(Object obj);
//	public long getLong(Object obj);
//	public String getString(Object obj);
//	public Date getDate(Object obj);
//	public Object getObject(Object obj);
	
	public static interface HasInt {}
	public static interface HasDouble {}
	public static interface HasBoolean {}
	public static interface HasLong {}
	public static interface HasString {}
	public static interface HasDate {}
	public static interface HasObject {}

}
