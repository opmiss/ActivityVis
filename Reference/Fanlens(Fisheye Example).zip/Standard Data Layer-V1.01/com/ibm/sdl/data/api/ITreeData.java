/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

public interface ITreeData extends IGraphData {

	public Object getParent(Object child);
	public Object getChild(Object parent, int index);
	public int getChildCount(Object parent);
	public int getIndexOfChild(Object parent, Object child);
	public Object getTreeRoot();
	public boolean isLeaf(Object obj);
	
}
