/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import java.io.Serializable;

import com.ibm.sdl.util.prop.IProperty;

public interface IEdge extends IProperty, Serializable {

	public static final String PROP_FIRST_NODE = "#first#";
	public static final String PROP_SECOUND_NODE = "#secound#";
	
	public Object getFirstNode();
	public Object getSecondNode();
	
	public void setFirstNode(Object node);
	public void setSecondNode(Object node);

}