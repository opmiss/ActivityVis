/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import java.util.Collection;
import java.util.Comparator;

import com.ibm.sdl.data.IData;
import com.ibm.sdl.data.InvalidateTypeException;

public interface ITreeDataEx extends ITreeData, IGraphDataEx, IData {
	
	public static final String PROP_TREENODE_DEPTH = "#DEPTH#";
	
	public void setTreeRoot(Object root);
	
	public Object[] getChildren(Object parent, Comparator c);
	
	public boolean containsChild(Object parent, Object child);
	
	public void addChild(Object parent, Object node) throws InvalidateTypeException;
	
	public void addChildren(Object parent, Collection children) throws InvalidateTypeException;
	
	public void removeChild(Object child) throws InvalidateTypeException;
	
	public void removeChildren(Collection children) throws InvalidateTypeException;
	
	public void changeParent(Object node, Object newParent) throws InvalidateTypeException;
	
	public int getTreeHeight();
	
	public int getDepth(Object node);
	
	public Object getAncestor(Object node, int level);
	
}
