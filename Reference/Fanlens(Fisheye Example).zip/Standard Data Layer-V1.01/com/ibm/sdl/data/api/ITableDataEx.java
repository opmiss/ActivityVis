/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.api;

import java.util.Comparator;

import com.ibm.sdl.data.IData;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.util.filter.IItemFilter;


public interface ITableDataEx extends ITableData, IData {
	
	public static final String PROP_ROWNAME = "#RowName#";
	
	/////////////////////////////////////////////////////////
	// TODO: Table Operations
	/////////////////////////////////////////////////////////
	public void setSchemes(Class[] scehmes) throws InvalidateDataException;
	
	public Class[] getSchemes();
	
	public void setData(Object[][] data) throws InvalidateDataException;
	
	public void setRowType(Class type);
	
	public Class getRowType();
	
	public void clearAll();
	
	////////////////////////////////////////////////////////
	// TODO: Value Operations
	////////////////////////////////////////////////////////
	public void setValue(int row, int col, Object value);
	
	public void addValue(String rowName, String colName, Object value);
	
	public Object getValue(int row, int col);
	
	public Object getValue(String row, String col);
	
	
	///////////////////////////////////////////////////////
	// TODO: Row Operations
	///////////////////////////////////////////////////////
	public Object getRow(String name); 
	
	public Object[] getRows(IItemFilter filter, Comparator comparator);
	
	public void addRow(Object row) throws InvalidateTypeException;
	
	public void addRow(String name, Object row) throws InvalidateTypeException;
	
	public void removeRow(Object row);
	
	public Object removeRow(String name);
	
	public Object removeRow(int idx);
	
	public void setRowName(int row, String name);
	
	public int getRowIndex(Object row);
	
	public int getRowIndex(String name);
	
	public String getRowName(int rowIndex);
	
	public String getRowName(Object row);
	
	
	///////////////////////////////////////////////////////
	// TODO: Column Operations
	///////////////////////////////////////////////////////
	public void setColumnNames(String[] names) throws InvalidateDataException;
	
	public IColumn addColumn(Class type, String name) throws InvalidateDataException;
	
	public IColumn addColumn(int index, Class type, String name);
	
	public void removeColumn(IColumn col);
	
	public IColumn removeColumn(int index);
	
	public IColumn removeColumn(String name);
	
	public int getColumnCount();
	
	public int getColumnIndex(IColumn c);
	
	public int getColumnIndex(String name);
	
}
