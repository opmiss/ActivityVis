/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractData implements IData {

	protected List m_listeners = null;
	
	protected DataEvent m_event = null;
	
	public AbstractData() {
		m_listeners = new ArrayList(0);
		m_event = new DataEvent(this);
	}
	
	public void addDataListener(IDataListener listener) {
		if(!m_listeners.contains(listener)) {
			m_listeners.add(listener);
		}
	}

	public void removeDataListener(IDataListener listener) {
		m_listeners.remove(listener);
	}

	public IDataListener[] getDataListeners() {
		return (IDataListener[])m_listeners.toArray(new IDataListener[]{});
	}

	public IDataListener[] removeDataListeners() {
		IDataListener[] listeners = (IDataListener[])m_listeners.toArray(new IDataListener[]{});
		m_listeners.clear();
		return listeners;
	}
	
	public void clear() {
		this.fireDataCleared();
	}
	
	public void refresh() {
		this.fireDataRefreshed();
	}
	
	public void fireItemRemoved(Object item, int type) {
		int size = m_listeners.size();
		m_event.setItem(item);
		m_event.setType(type);
		IDataListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IDataListener)m_listeners.get(i);
			if(!l.equals(m_event.getInvoker())) {
				l.itemRemoved(m_event);
			}
		}
	}
	
	public void fireItemAdded(Object item, int type) {
		int size = m_listeners.size();
		m_event.setItem(item);
		m_event.setType(type);
		IDataListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IDataListener)m_listeners.get(i);
			if(!l.equals(m_event.getInvoker())) {
				l.itemAdded(m_event);
			}
		}
	}
	
	public void fireItemChanged(Object item, Object key, Object value, int type) {
		int size = m_listeners.size();
		m_event.setItem(item);
		m_event.setKey(key);
		m_event.setValue(value);
		m_event.setType(type);
		IDataListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IDataListener)m_listeners.get(i);
			if(!l.equals(m_event.getInvoker())) {
				l.itemChanged(m_event);
			}
		}
	}
	
	public void fireDataCleared() {
		int size = m_listeners.size();
		m_event.setItem(null);
		m_event.setKey(null);
		m_event.setValue(null);
		m_event.setType(DataEvent.DATA_CLEAR_EVENT);
		IDataListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IDataListener)m_listeners.get(i);
			if(!l.equals(m_event.getInvoker())) {
				l.dataCleared(m_event);
			}
		}
	}
	
	public void fireDataRefreshed() {
		int size = m_listeners.size();
		m_event.setItem(null);
		m_event.setKey(null);
		m_event.setValue(null);
		m_event.setType(DataEvent.DATA_CLEAR_EVENT);
		IDataListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IDataListener)m_listeners.get(i);
			if(!l.equals(m_event.getInvoker())) {
				l.dataRefreshed(m_event);
			}
		}
	}
}
