/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data;

public class InvalidateDataException extends Exception {

	private static final long serialVersionUID = -8865533425761366970L;

	public InvalidateDataException() {
		super();
	}
	
	public InvalidateDataException(String msg) {
		super(msg);
	}
}
