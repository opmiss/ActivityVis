/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data;

public interface IDataListener {
	
	public void itemChanged(DataEvent e);
	
	public void itemRemoved(DataEvent e);
	
	public void itemAdded(DataEvent e);
	
	public void dataCleared(DataEvent e);
	
	public void dataRefreshed(DataEvent e);
}
