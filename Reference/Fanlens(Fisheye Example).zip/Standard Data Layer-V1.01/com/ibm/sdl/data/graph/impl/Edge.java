/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author Jesse Kriss, CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.graph.impl;

import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.util.prop.Property;

public class Edge extends Property implements IEdge {
	
	private static final long serialVersionUID = 5025922082960818213L;
	
	public Edge() {
		this(null, null);
	}
	
	public Edge(Object a, Object b) {
		setFirstNode(a);
		setSecondNode(b);
	}

	public Object getFirstNode() {
		return getProperty(PROP_FIRST_NODE);
	}

	public void setFirstNode(Object a) {
		addProperty(PROP_FIRST_NODE, a);
	}

	public Object getSecondNode() {
		return getProperty(PROP_SECOUND_NODE);
	}

	public void setSecondNode(Object b) {
		addProperty(PROP_SECOUND_NODE, b);
	}

	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (obj instanceof Edge) {
			IEdge a = (IEdge) obj;
			return (a.getFirstNode().equals(getFirstNode()) && a.getSecondNode().equals(getSecondNode()));
		} else {
			return false;
		}
	}
	
	public String toString() {
		return "[" + getFirstNode() + "]->[" + getSecondNode() + "]";
	}
	
}
