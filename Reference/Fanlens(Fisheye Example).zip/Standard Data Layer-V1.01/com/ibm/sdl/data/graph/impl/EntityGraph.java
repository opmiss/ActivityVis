/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.graph.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.ibm.sdl.data.AbstractData;
import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.filter.IItemFilter;

public class EntityGraph extends AbstractData implements IGraphDataEx {

	private static final long serialVersionUID = -641960860215018993L;
	
	protected boolean m_bDirected = false;
	protected List m_edges = new ArrayList(0);
	protected List m_nodes = new ArrayList(0);
	protected Map m_edgesFromNode1 = new HashMap(0);
	protected Map m_edgesFromNode2 = new HashMap(0);
	
	protected ITreeDataEx m_spanning = null;
	
	protected Class edgeType = null;
	
	public EntityGraph() {
		super();
	}
	
	public void setEdgeType(Class edge) {
		edgeType = edge;
	}
	
	/////////////////////////////////////////////////////////////
	// TODO: Implementations of IGraphData methods
	/////////////////////////////////////////////////////////////
	public boolean isDirected() {
		return m_bDirected;
	}

	public int getNodeCount() {
		return m_nodes.size();
	}

	public Object getNode(int index) {
		return m_nodes.get(index);
	}
	
	public int getEdgeCount() {
		return m_edges.size();
	}

	public IEdge getEdge(int index) {
		return (IEdge)m_edges.get(index);
	}
	
	public IEdge getEdge(Object node1, Object node2) {
		
		if(node1 == null || node2 == null) {
			return null;
		}
		
		List edges1 = (List)m_edgesFromNode1.get(node1);
		if(edges1 == null || edges1.isEmpty()) {
			return null;
		}
		
		List edges2 = (List)m_edgesFromNode2.get(node2);
		if(edges2 == null || edges2.isEmpty()) {
			return null;
		}
		
		IEdge edge = null;
		int size = 0;
		if(edges1.size() < edges2.size()) {
			size = edges1.size();
			for(int i = 0; i < size; ++i) {
				edge = (IEdge)edges1.get(i);
				if(node2.equals(edge.getSecondNode())) {
					return edge;
				}
			}
		} else {
			size = edges2.size();
			for(int i = 0; i < size; ++i) {
				edge = (IEdge)edges2.get(i);
				if(node1.equals(edge.getFirstNode())) {
					return edge;
				}				
			}
		}
		
		return null;
	}
	
	public IEdge[] getEdgesWithFirstNode(Object firstNode) {
		List edges = (List)m_edgesFromNode1.get(firstNode);
		if(null == edges) return new IEdge[]{}; 
		return (IEdge[])edges.toArray(new IEdge[]{});
	}

	public IEdge[] getEdgesWithSecondNode(Object secondNode) {
		List edges = (List)m_edgesFromNode2.get(secondNode);
		if(null == edges) return new IEdge[]{}; 
		return (IEdge[])edges.toArray(new IEdge[]{});
	}

	////////////////////////////////////////////////////////////
	// TODO: Implementations of IGraphDataEx methods
	////////////////////////////////////////////////////////////
	public boolean isEmpty() {
		return m_nodes.isEmpty();
	}
	
	public boolean contains(Object elem) {
		boolean flag = m_nodes.contains(elem);
		if(!flag) {
			flag = m_edges.contains(elem);
		}
		return flag;
	}
	
	public void setDirected(boolean bDirected) {
		this.m_bDirected = bDirected;
	}
	
	public Object[] getNodes(IItemFilter filter, Comparator c) {
		
		Object[] nodes = null;
		
		if(filter == null) {
			nodes = m_nodes.toArray();
		} else {		
			List temp = new ArrayList(0);
			Iterator it = m_nodes.iterator();
			Object node = null;
			while(it.hasNext()) {
				node = it.next();
				if(filter.accept(node)) {
					temp.add(node);
				}
			}
			nodes = temp.toArray();
		}
		
		if(null != c) {
			Arrays.sort(nodes, c);
		}
		
		return nodes;
	}
	
	public IEdge[] getEdges(IItemFilter filter, Comparator c) {
		if(filter == null) {
			return (IEdge[])m_edges.toArray(new IEdge[]{});
		}
		
		List temp = new ArrayList(0);
		Iterator it = m_edges.iterator();
		Object edge = null;
		while(it.hasNext()) {
			edge = it.next();
			if(filter.accept(edge)) {
				temp.add(edge);
			}
		}
		IEdge[] edges = (IEdge[])temp.toArray(new IEdge[]{});
		
		if(null != c) {
			Arrays.sort(edges, c);
		}
		
		return edges;
	}
	
	public void addNode(Object node) {
		add(node);
		fireItemAdded(node, DataEvent.NODE_ADDED_EVENT);
	}
	
	public void removeNode(Object node) {
		remove(node);
		fireItemRemoved(node, DataEvent.NODE_REMOVED_EVENT);
	}
	
	public void addNodes(Collection nodes) {
		Iterator it = nodes.iterator();
		Object node = null;
		while(it.hasNext()) {
			node = it.next();
			add(node);
		}
		fireItemAdded(nodes, DataEvent.NODE_COLLECTION_ADDED_EVENT);
	}

	public void removeNodes(Collection nodes) {
		Iterator it = nodes.iterator();
		Object node = null;
		while(it.hasNext()) {
			node = (IEdge)it.next();
			remove(node);
		}
		fireItemRemoved(nodes, DataEvent.NODE_COLLECTION_REMOVED_EVENT);
	}
	
	public IEdge addEdge(Object node1, Object node2) {
		IEdge edge = add(node1, node2);
		fireItemAdded(edge, DataEvent.EDGE_ADDED_EVENT);
		return edge;
	}
	
	public void removeEdge(Object node1, Object node2) {
		IEdge edge = remove(node1, node2);
		if(null != edge) {
			fireItemRemoved(edge, DataEvent.EDGE_REMOVED_EVENT);
		}
	}

	public void addEdge(IEdge edge)throws InvalidateDataException {
		add(edge);
		fireItemAdded(edge, DataEvent.EDGE_ADDED_EVENT);
	}

	public void removeEdge(IEdge edge) {
		if(remove(edge)) {
			fireItemRemoved(edge, DataEvent.EDGE_REMOVED_EVENT);
		}
	}
	
	public void addEdges(Collection edges) throws InvalidateDataException {
		Iterator it = edges.iterator();
		IEdge edge = null;
		while(it.hasNext()) {
			edge = (IEdge)it.next();
			add(edge);
		}
		fireItemAdded(edge, DataEvent.EDGE_COLLECTION_ADDED_EVENT);
	}
	
	public void removeEdges(Collection edges) {
		Iterator it = edges.iterator();
		IEdge edge = null;
		List list = new ArrayList(0);
		while(it.hasNext()) {
			edge = (IEdge)it.next();
			if(remove(edge)) {
				list.add(edge);
			}
		}
		if(!list.isEmpty()) {
			fireItemRemoved(list, DataEvent.EDGE_COLLECTION_REMOVED_EVENT);
		}
	}
	
	public void changeProperty(Object elem, Object key, Object value) {
		PropOperator.getInstance().setProperty(elem, key, value);
		fireItemChanged(elem, key, value, DataEvent.PROP_CHANGED_EVENT);
	}
		
	public ITreeDataEx getSpanningTree(Object root) {
		if(m_spanning == null || m_spanning.getTreeRoot() != root) {
			m_spanning = this.buildSpanningTree(root);
			m_spanning.refresh();
		}
		return m_spanning;
	}
	
	public void clear() {
		boolean flag = false;
		if(!m_edges.isEmpty()) {
			this.m_edges.clear();
			flag = true;
		}
		if(!m_nodes.isEmpty()) {
			this.m_nodes.clear();
			flag = true;
		}
		if(!m_edgesFromNode1.isEmpty()) {
			this.m_edgesFromNode1.clear();
			flag = true;
		}
		if(!m_edgesFromNode2.isEmpty()) {
			this.m_edgesFromNode2.clear();
			flag = true;
		}
		if(flag) {
			this.fireDataCleared();
		}
	}
	
	/////////////////////////////////////////////////////
	// TODO: Background Common Operations
	/////////////////////////////////////////////////////
	protected void add(Object node) {
//		insert(m_nodes, node);
		m_nodes.add(node);
		if(null != m_spanning) {
			m_spanning.clear();
			m_spanning = null;
		}
	}
	
	protected void add(IEdge edge) throws InvalidateDataException {
		Object node1 = edge.getFirstNode();
		Object node2 = edge.getSecondNode();
		
		if(node1 == null || node2 == null) {
			throw new InvalidateDataException("Can't add a dissociated edge into graph");
		}
		
		if(!m_nodes.contains(node1) || !m_nodes.contains(node2)) {
			throw new InvalidateDataException("Invalidated connection");
		}
		
		List edges = (List)m_edgesFromNode1.get(node1);
		if(null != edges) {
			edges.add(edge);
		} else {
			edges = new ArrayList(1);
			edges.add(edge);
			m_edgesFromNode1.put(node1, edges);
		}
		
		edges = (List)m_edgesFromNode2.get(node2);
		if(null != edges) {
			edges.add(edge);
		} else {
			edges = new ArrayList(1);
			edges.add(edge);
			m_edgesFromNode2.put(node2, edges);
		}
		if(m_edges != null) {
			m_edges.add(edge);
		}
		
		if(null != m_spanning) {
			m_spanning.clear();
			m_spanning = null;
		}
	}
	
	protected IEdge add(Object node1, Object node2) {
		try {
			IEdge edge;
			
			edge = (IEdge)edgeType.newInstance();
			edge.setFirstNode(node1);
			edge.setSecondNode(node2);
			
			List edges = null;
			
			if(m_edgesFromNode1.containsKey(node1)) {
				edges = (List)m_edgesFromNode1.get(node1);
//				insert(edges, edge);
				edges.add(edge);
			} else {
				edges = new ArrayList(1);
//				insert(edges, edge);
				edges.add(edge);
				m_edgesFromNode1.put(node1, edges);
			}
			
			if(m_edgesFromNode2.containsKey(node2)) {
				edges = (List)m_edgesFromNode2.get(node2);
//				insert(edges, edge);
				edges.add(edge);
			} else {
				edges = new ArrayList(1);
//				insert(edges, edge);
				edges.add(edge);
				m_edgesFromNode2.put(node2, edges);
			}
			
			m_edges.add(edge);
			
			if(null != m_spanning) {
				m_spanning.clear();
				m_spanning = null;
			}
			return edge;
		} catch (InstantiationException e) {
			e.printStackTrace();
			return null;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	protected void remove(Object node) {
		m_nodes.remove(node);
		List edges1 = (List)m_edgesFromNode1.get(node);
		List edges2 = (List)m_edgesFromNode2.get(node);
		IEdge edge = null;
		Object tn = null;
		List te = null;
		int ecnt = 0;
		
		if(edges1 != null && !edges1.isEmpty()) {
			ecnt = edges1.size();
			for(int i = 0; i < ecnt; ++i) {
				edge = (IEdge)edges1.get(i);
				tn = edge.getSecondNode();
				te = (List)m_edgesFromNode2.get(tn);
				if(null != te && !te.isEmpty()) {
					te.remove(edge);
				}
				m_edges.remove(edge);
			}
			edges1.clear();
		}
		if(edges2 != null && !edges2.isEmpty()) {
			ecnt = edges2.size();
			for(int i = 0; i < ecnt; ++i) {
				edge = (IEdge)edges2.get(i);
				tn = edge.getFirstNode(); 
				te = (List)m_edgesFromNode1.get(tn);
				if(null != te && !te.isEmpty()) {
					te.remove(edge);
				}
				m_edges.remove(edge);
			}
			edges2.clear();
		}
		if(null != m_spanning) {
			m_spanning.clear();
			m_spanning = null;
		}
	}
	
	protected boolean remove(IEdge edge) {
		
		if(!m_edges.remove(edge)) return false;
		
		Object node1 = edge.getFirstNode();
		Object node2 = edge.getSecondNode();
		
		List edges1 = (List)m_edgesFromNode1.get(node1);
		List edges2 = (List)m_edgesFromNode2.get(node2);
		
		int size = 0;
		IEdge e = null;
		size = edges1.size();
		for(int i = 0; i < size; ++i) {
			e = (IEdge)edges1.get(i);
			if(node2.equals(e.getSecondNode())) {
				edges1.remove(e);
				break;
			}
		}
		
		size = edges2.size();
		for(int i = 0; i < size; ++i) {
			e = (IEdge)edges2.get(i);
			if(node1.equals(e.getFirstNode())) {
				edges2.remove(e);
				break;
			}
		}
		if(null != m_spanning) {
			m_spanning.clear();
			m_spanning = null;
		}
		return true;
	}
	
	protected IEdge remove(Object node1, Object node2) {
		List edges1 = (List)m_edgesFromNode1.get(node1);
		List edges2 = (List)m_edgesFromNode2.get(node2);
		
		if(edges1 == null || edges2 == null || 
				edges1.isEmpty() || edges2.isEmpty()) {
			return null;
		}
		
		IEdge edge = null;
		int size = edges2.size();
		for(int i = 0, j = 0; i < size; ++i) {
			edge = (IEdge)edges2.get(j);
			if(edges1.remove(edge)) {
				edges2.remove(edge);
				remove((IEdge)edge);
				break;
			} else {
				j++;
			}
		}
		if(null != m_spanning) {
			m_spanning.clear();
			m_spanning = null;
		}
		return edge;
	}
	
    protected ITreeDataEx buildSpanningTree(Object root) {
//    	try {
	    	EntityTree tree = new EntityTree(root);
	    	tree.setEdgeType(edgeType);
	    	LinkedList q = new LinkedList();
	    	List visit = new ArrayList();
	    	
	    	q.add(root);
	    	visit.add(root);
	    	
	    	Object node1 = null;
	    	Object node2 = null;
	    	
	    	while(!q.isEmpty()) {
	    		    		
	    		Object p = q.removeFirst();
	    		IEdge[] edges = tree.getEdgesWithFirstNode(p);
	    		IEdge[] edges1 = getEdgesWithFirstNode(p);
	    		IEdge[] edges2 = getEdgesWithSecondNode(p);
	    		
	    		if(edges != null) {
		    		for(int i = 0; i < edges.length; ++i) {
		    			Object n = edges[i].getSecondNode();
		    			if(!visit.contains(n)) {
		    				q.add(n);
		    				visit.add(n);
		    				node1 = edges[i].getFirstNode();
		    				node2 = edges[i].getSecondNode();
		    				tree.addChild(node1, node2);
		    			}
		    		}
	    		}
	    		
	    		if(edges1 != null) {
		    		for(int i = 0; i < edges1.length; ++i) {
		    			Object n = edges1[i].getSecondNode();
		    			if(!visit.contains(n)) {
		    				q.add(n);
		    				visit.add(n);
		    				node1 = edges1[i].getFirstNode();
		    				node2 = edges1[i].getSecondNode();
		    				tree.addChild(node1, node2);
		    			}
		    		}
	    		}
	    		
	    		if(edges2 != null) {
		    		for(int i = 0; i < edges2.length; ++i) {
		    			Object n = edges2[i].getFirstNode();
		    			if(!visit.contains(n)) {
		    				q.add(n);
		    				visit.add(n);
		    				node1 = edges2[i].getFirstNode();
		    				node2 = edges2[i].getSecondNode();
		    				tree.addChild(node2, node1);
		    			}
		    		}
	    		}
	    	}
	    	visit.clear();
	    	return tree;
//    	} catch (InvalidateTypeException ex) {
//    		ex.printStackTrace();
//    		return null;
//    	}
    }

	public int getDegrees(Object node) {

		List edges1 = (List)m_edgesFromNode1.get(node);
		List edges2 = (List)m_edgesFromNode2.get(node);
		
		int cnt1 = edges1 == null ? 0 : edges1.size();
		int cnt2 = edges2 == null ? 0 : edges2.size();
		
		return cnt1 + cnt2;
	}
	
	public int getInDegree(Object node) {
		List edges2 = (List)m_edgesFromNode2.get(node);
		return edges2 == null ? 0 : edges2.size();
	}
	
	public int getOutDegree(Object node) {
		List edges1 = (List)m_edgesFromNode1.get(node);
		return edges1 == null ? 0 : edges1.size();		
	}

	public Object[] getNodes(Object[] a, IItemFilter filter, Comparator c) {
		Object[] nodes = null;
		
		if(filter == null) {
			if(a == null) {
				nodes = m_nodes.toArray();
			} else {
				nodes = m_nodes.toArray(a);
			}
		} else {		
			List temp = new ArrayList(0);
			Iterator it = m_nodes.iterator();
			Object node = null;
			while(it.hasNext()) {
				node = it.next();
				if(filter.accept(node)) {
					temp.add(node);
				}
			}
			
			if(a == null) {
				nodes = temp.toArray();
			} else {
				nodes = temp.toArray(a);
			}
		}
		
		if(null != c) {
			Arrays.sort(nodes, c);
		}
		
		return nodes;
	}

	public void addNodes(Object[] nodes) throws InvalidateTypeException {
		for(int i = 0; i < nodes.length; ++i) {
			add(nodes[i]);
		}
		fireItemAdded(nodes, DataEvent.NODE_COLLECTION_ADDED_EVENT);
	}

	public void addEdges(IEdge[] edges) throws InvalidateDataException {
		for(int i = 0; i < edges.length; ++i) {
			add(edges[i]);
		}
		fireItemAdded(edges, DataEvent.EDGE_COLLECTION_ADDED_EVENT);
	}
}
