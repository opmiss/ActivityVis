/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data;

import java.io.Serializable;


public interface IData extends Cloneable, Serializable {
	
	public boolean isEmpty();
	
	public boolean contains(Object elem);
	
	public void addDataListener(IDataListener listener);
	
	public void removeDataListener(IDataListener listener);
	
	public IDataListener[] getDataListeners();
	
	public IDataListener[] removeDataListeners();
	
	public void clear();
	
	public void refresh();
	
}
