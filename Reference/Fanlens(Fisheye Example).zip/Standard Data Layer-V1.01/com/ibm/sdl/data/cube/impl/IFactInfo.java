/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.cube.impl;

/**
 * @author CaoNan (nancao@cn.ibm.com)
 */
public interface IFactInfo {

	public String getFactTable();
	
	public void setFactTable(String name);
	
	public Object[] getDimensionFields();
	
	public Object[] getFactFields();
	
	public void addDimensionField(Object field);
	
	public void addFactField(Object field);

	public boolean containsDimensionField(Object field);

	public boolean containsFactField(Object field);
}
