/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.cube.impl;

import java.util.ArrayList;
import java.util.List;

/**
 * @author CaoNan (nancao@cn.ibm.com)
 */
public class DimensionInfo implements IDimensionInfo {

	private String m_dimensionName;
	private List m_fields;
	private Object m_keyField;
	private int m_level;
	
	public DimensionInfo(String dimensionName){
		m_dimensionName = dimensionName;
		m_fields = new ArrayList();
		m_level = 0;
	}
	
	public void addField(Object field) {
		m_fields.add(field);
		m_level = m_fields.size() - 1;
	}

	public Object getField(int level) {
		return m_fields.get(level);
	}

	public Object getKeyField() {
		return m_keyField;
	}

	public int getLevel() {
		return m_level;
	}

	public String getName() {
		return m_dimensionName;
	}

	public void setKeyField(Object key) {
		m_keyField = key;
	}

	public void setLevel(int level) {
		m_level = level;
	}

	public void setName(String name) {
		m_dimensionName = name;
	}

	public int size() {
		return m_fields.size();
	}

	public void clear(){
		m_dimensionName = "";
		m_fields.clear();
		m_keyField = null;
		m_level = 0;
	}
}
