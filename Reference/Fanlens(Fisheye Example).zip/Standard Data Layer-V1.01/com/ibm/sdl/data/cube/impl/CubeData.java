/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.cube.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.ibm.sdl.data.AbstractData;

/**
 * @author CaoNan (nancao@cn.ibm.com)
 */
public class CubeData extends AbstractData {

	private static final long serialVersionUID = -2958415141232378149L;
	
	protected Map m_elems = null;
	protected Object[][] m_dimensions = null;
	protected int m_size = 0;
	
	public CubeData() {
		m_dimensions = new String[0][0];
		m_elems = new HashMap();
	}

	public void setDimensions(Object[][] dimensions) {
		if(dimensions == null) {
			return;
		}
		m_dimensions = dimensions;
		m_size = 1;
		for(int i = 0; i < dimensions.length; ++i) {
			m_size *= dimensions[i].length;
		}
	}
	
	public Object[][] getDimensions() {
		
		Object[][] dim = new Object[m_dimensions.length][0];
		int length = 0;
		for(int i = 0; i < m_dimensions.length; ++i) {
			length = m_dimensions[i].length;
			dim[i] = new String[length];
			System.arraycopy(m_dimensions[i], 0, dim[i], 0, length);
		}
		return dim;
	}
	
	public int size() {
		return m_size;
	}

	public int getDimensionSize() {
		return m_dimensions.length;
	}
	
	public int getDimensionSize(int dimension) {
		if(dimension > m_dimensions.length) {
			return 0;
		}
		return m_dimensions[dimension].length;
	}

	public Object[] getDimension(int dimension) {
		if(dimension > m_dimensions.length) {
			return null;
		}
		return m_dimensions[dimension];
	}
	
	public Object[] getDimensionVector(Object elem) {
		int[] ivector = getVector(elem);
		if(null == ivector) {
			return null;
		}
		return getDiemensionVector(ivector);
	}
	
	public Object[] getDiemensionVector(int[] ivector) {
		Object[] dvector = new String[ivector.length];
		for(int i = 0; i < ivector.length; ++i) {
			dvector[i] = m_dimensions[i][ivector[i]];
		}
		return dvector;
	}
	
	public int[] getVector(Object elem) {
		
		Iterator it = m_elems.keySet().iterator();
		int idx = -1;
		Object key = null;
		while(it.hasNext()) {
			key = it.next();
			if(elem == m_elems.get(key)) {
				idx = ((Integer)key).intValue();
				break;
			}
		}
		
		return idx < 0 ? null : indexToVector(idx);
	}
	
	public Object getCubicElem(int[] vector) {
		int idx = vectorToIndex(vector);
		return m_elems.get(new Integer(idx));
	}
	
	public Object getCubicElem(int idx) {
		return m_elems.get(new Integer(idx));
	}
	
	public void addCubicElem(int[] vector, Object value) {
		int idx = vectorToIndex(vector);
		m_elems.put(new Integer(idx), value);
	}

	public boolean isEmpty() {
		return m_elems.isEmpty();
	}

	public boolean contains(Object elem) {
		return m_elems.containsValue(elem);
	}
	
	public void clear() {
		m_elems.clear();
		m_dimensions = null;
		System.gc();
		super.clear();
	}
	
	public int vectorToIndex(int[] vector) {
		int idx = 0;
		for(int i = 0; i < m_dimensions.length - 1; ++i) {
			idx = idx + vector[i];
			idx *= (getDimensionSize(i + 1) + 1);
		}
		return idx;
	}
	
	public int[] indexToVector(int idx) {
		int last = m_dimensions.length - 1;
		int div = 1;
		int j = 0; 
		int[] vector = new int[m_dimensions.length];
		for(int i = 0; i < m_dimensions.length; ++i) {
			if(i == last) {
				vector[i] = idx % (getDimensionSize(last) + 1);
			} else {
				j = i + 1;
				div = 1;
				while(j <= last) {
					div *= (getDimensionSize(j) + 1);
					j++;
				}
				vector[i] = (idx / div) % (getDimensionSize(i) + 1);
			}
		}
		return vector;
	}
}
