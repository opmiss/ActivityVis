/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.cube.impl;

/**
 * @author CaoNan (nancao@cn.ibm.com)
 */
public interface IDimensionInfo {
	
	public String getName();
	public void setName(String name);
	
	public Object getKeyField();
	public void setKeyField(Object key);
	
	public int getLevel();
	public void setLevel(int level);
	
	public Object getField(int level);
	public void addField(Object field);
	public int size();
	
	public void clear();
}
