/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.cube.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.io.db.DBFactory;
import com.ibm.sdl.util.io.db.IDatabase;

/**
 * @author CaoNan (nancao@cn.ibm.com)
 */
public class OLAPDatabaseManager {

	private StringBuffer m_sql = null;
	private IFactInfo m_fact = null;
	private IDimensionInfo[] m_dimensions = null;
	private Map[] m_dimensionIndexes = null;
	private IDatabase m_db = null;
	private Class m_type = null;
	
	public OLAPDatabaseManager(String dbfile, String factTable, String[] dimTables) {
		m_sql = new StringBuffer();
		m_db = DBFactory.loadAccess(dbfile);
		m_type = CubeData.class;
		m_dimensionIndexes = new HashMap[dimTables.length];
		for(int i=0; i<m_dimensionIndexes.length; i++)
			m_dimensionIndexes[i] = new HashMap(0);
		try{
			initData(factTable, dimTables);
		}catch(SQLException e){
		}
	}
	
	private void initData(String factTable, String[] dimTables)throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsMetaData = null;
		int columnCount = 0;
		
		m_fact = new FactInfo(factTable);
		
		//1. create dimensionInfo
		m_dimensions = new DimensionInfo[dimTables.length];
//		System.out.println("--------------Create DimensionInfo-------------");
		for(int i=0; i<dimTables.length; i++){
			m_dimensions[i] = new DimensionInfo(dimTables[i]);
			m_sql.delete(0, m_sql.length());
			m_sql.append("select top 1 * from " + dimTables[i]);
			pstmt = m_db.getConnection().prepareStatement(m_sql.toString());
			rs = pstmt.executeQuery();
			rsMetaData = rs.getMetaData();

			columnCount = rsMetaData.getColumnCount();
			m_dimensions[i].setKeyField(rsMetaData.getColumnName(1));
			m_fact.addDimensionField(rsMetaData.getColumnName(1));
//			System.out.println(rsMetaData.getColumnName(1));
			for(int j=1; j<columnCount; j++){
				m_dimensions[i].addField(rsMetaData.getColumnName(j+1));
//				System.out.println(rsMetaData.getColumnName(j+1));
			}
		}

		//2. create factInfo
		m_sql.delete(0, m_sql.length());
		m_sql.append("select top 1 * from " + factTable);
		pstmt = m_db.getConnection().prepareStatement(m_sql.toString());
		rs = pstmt.executeQuery();
		rsMetaData = rs.getMetaData();
		
		columnCount = rsMetaData.getColumnCount();
//		System.out.println("--------------Create FactInfo-------------");
		for(int i=0; i<columnCount; i++){
			if(!m_fact.containsDimensionField(rsMetaData.getColumnName(i+1))){
				m_fact.addFactField(rsMetaData.getColumnName(i+1));
			}
		}
		
//		for(int i = 1; i < m_dimensions.length; ++i) {
//			int size = m_dimensions[i].size();
//			m_dimensions[i].setLevel(m_dimensions[i].getLevel()-1);
//		}
	}
	
	public CubeData loadBaseCube() throws SQLException {
		return getCube(-1, 0, null);
	}
	
	public CubeData rollUp(int dimension) throws SQLException {
		int level = m_dimensions[dimension].getLevel();
		if(level -1 < 0)
			return null;
		return getCube(dimension, --level, null);
	}
	
	public CubeData drillDown(int dimension) throws SQLException {
		int level = m_dimensions[dimension].getLevel();
		if(level + 1 >= m_dimensions[dimension].size())
			return null;
		return getCube(dimension, ++level, null);
	}
	
	public CubeData dice(String[] conditions) throws SQLException {
		return null;
	}
	
	public CubeData slice(int dimension, String value) throws SQLException {
		int level = m_dimensions[dimension].getLevel();
		Object dimensionField = m_dimensions[dimension].getField(level);		
		String condition = dimensionField + " = '" + value + "'";
		return getCube(dimension, level, condition);
	}
		
	protected CubeData getCube(int dimension, int level, String condition) throws SQLException {
		try {
			// 0. clear old data
			for(int i=0; i<m_dimensionIndexes.length; i++){
				m_dimensionIndexes[i].clear();
			}
			
			// 1. init parameters
			if(dimension != -1) {
				m_dimensions[dimension].setLevel(level);
			}
			String factTableName = m_fact.getFactTable();
			Object[] factTableFactFields = m_fact.getFactFields();
			Object[] factTableDimensionFields = m_fact.getDimensionFields();
			boolean flag = false;

			long t1 = System.currentTimeMillis();
			// 2. roll up from the base cube
			m_sql.delete(0, m_sql.length());
			m_sql.append("select ");
			int size = factTableDimensionFields.length;
			int dlevel = 0;
			if(dimension >=0) {
				for(int i = 0; i < size; ++i) {
					dlevel = m_dimensions[i].getLevel();
					if(m_dimensions[i].size() == dlevel + 1) {
						m_sql.append(factTableDimensionFields[i]);
					} else {
						m_sql.append(m_dimensions[i].getField(dlevel));
					}
					m_sql.append(", ");
				}
				size = factTableFactFields.length;
				for(int i = 0; i < size; ++i) {				
					m_sql.append("sum(FACT.");
					m_sql.append(factTableFactFields[i]);
					m_sql.append(") as ");
					m_sql.append(factTableFactFields[i]);
					if(i < size - 1) {
						m_sql.append(", ");
					}
				}
			} else {
				m_sql.append("*");
			}
			m_sql.append(" from ");
			
			if(dimension >=0) {
				m_sql.append("(select * from ");
				m_sql.append(factTableName);
				m_sql.append(" as FACT ");
				size = m_dimensions.length;
				for(int i = 0; i < size; ++i) {
					dlevel = m_dimensions[i].getLevel();
					if(dlevel == m_dimensions[i].size() - 1) {
						continue;
					}
					m_sql.append(", ");
					m_sql.append(m_dimensions[i].getName());
					flag = true;
				}
				if(flag) {
					m_sql.append(" where ");
					boolean first = true;
					for(int i = 0; i < size; ++i) {
						dlevel = m_dimensions[i].getLevel();
						if(dlevel == m_dimensions[i].size() - 1) {
							continue;
						}
						if(!first) {
							m_sql.append(" and ");
						}
						m_sql.append("FACT.");
						m_sql.append(factTableDimensionFields[i]);
						m_sql.append(" = ");
						m_sql.append(m_dimensions[i].getName());
						m_sql.append(".");
						m_sql.append(m_dimensions[i].getKeyField());
						first = false;
					}
				}
				m_sql.append(")");
			} else {
				m_sql.append(factTableName);
			}
			
			if(null != condition && !"".equals(condition)) {
				m_sql.append(" where ");
				m_sql.append(condition);
			}
			
			if(flag) {
				m_sql.append(" group by ");
				size = factTableDimensionFields.length;
				for(int i = 0; i < size; ++i) {
					dlevel = m_dimensions[i].getLevel();
					if(dlevel == m_dimensions[i].size() - 1) {
						m_sql.append(factTableDimensionFields[i]);
					} else {
						m_sql.append(m_dimensions[i].getField(dlevel));
					}
					if(i < size - 1) {
						m_sql.append(", ");
					}
				}
			}
			
			System.err.println("sql : " + m_sql.toString());
			PreparedStatement pstmt = m_db.getConnection().prepareStatement(m_sql.toString());
			ResultSet rs = pstmt.executeQuery();

			long t2 = System.currentTimeMillis();
			System.out.println("SQL Time Cost = " + (t2-t1));
			
			// 3. create new cube
			// 3.1 set cubics of the new cube according to the roll up result
			size = factTableDimensionFields.length;
			int[] vector = new int[size];
			Object cubic = null;
			
			// 3.1.1 init cube
			CubeData cube = new CubeData();

			t1 = System.currentTimeMillis();
			// 3.1.2 set dimensions
			String[][] dimensions = new String[m_dimensions.length][0];
			for(int i = 0; i < dimensions.length; ++i) {
				dimensions[i] = getDimensionValues(i, m_dimensions[i].getLevel());
			}
			cube.setDimensions(dimensions);

			t2 = System.currentTimeMillis();
			System.out.println("GetDimensionValues Time Cost = " + (t2-t1));

			t1 = System.currentTimeMillis();
			// 3.1.3 set data
			while(rs.next()) {
				size = factTableDimensionFields.length;
				Object obj = null;
				for(int i = 0; i < size; ++i) {
					obj = rs.getObject(i+1);
					vector[i] = getDimensionIndex(i, obj);
//					System.out.println("dimensionValue = " + obj);
//					System.out.println("dimensionIndex = " + vector[i]);
				}
				
				cubic = m_type.newInstance();
				size = factTableFactFields.length;
				for(int i = 0; i < size; ++i) {
					PropOperator.getInstance().setProperty(
							cubic, 
							factTableFactFields[i], 
							new Double(rs.getDouble(factTableFactFields[i].toString())));
				}
				cube.addCubicElem(vector, cubic);
			}

			t2 = System.currentTimeMillis();
			System.out.println("GetDimensionIndex Time Cost = " + (t2-t1));
			
			return cube;
		} catch (InstantiationException e) {
			e.printStackTrace();
			return null;
		} catch (IllegalAccessException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public String[] getDimensionValues(int dimension, int level) throws SQLException {
		
		String dimensionTableName = m_dimensions[dimension].getName();
		Object dimensionField = m_dimensions[dimension].getField(level);

		m_sql.delete(0, m_sql.length());
		m_sql.append("select ");
		m_sql.append(dimensionField);
		m_sql.append(" from ");
		m_sql.append(dimensionTableName);
		m_sql.append(" group by ");
		m_sql.append(dimensionField);
		
		PreparedStatement pstmt = m_db.getConnection().prepareStatement(m_sql.toString());
		ResultSet rs = pstmt.executeQuery();
		
		List dimensions = new ArrayList();
		for(int i = 0; rs.next(); ++i) {
			dimensions.add(rs.getString(1));
		}
		
		return (String[])dimensions.toArray(new String[]{});
	}
	
	public int getDimensionIndex(int dimension, Object dimensionValue) throws SQLException {
		String dimensionTableName = m_dimensions[dimension].getName();
		Object dimensionField = null;
		int dlevel = m_dimensions[dimension].getLevel();
		if(m_dimensions[dimension].size() == dlevel + 1) {
			dimensionField = m_fact.getDimensionFields()[dimension];
		} else {
			dimensionField = m_dimensions[dimension].getField(dlevel);
		}
		
//		System.out.println("dimensionTableName = " + dimensionTableName);
//		System.out.println("dimensionField = " + dimensionField);
//		System.out.println("dimension = " + dimension);
		
		if(m_dimensionIndexes[dimension].isEmpty()){
			long t1 = System.currentTimeMillis();
			m_sql.delete(0, m_sql.length());
			m_sql.append("select ");
			m_sql.append(dimensionField);
			m_sql.append(" from ");
			m_sql.append(dimensionTableName);
			m_sql.append(" group by ");
			m_sql.append(dimensionField);
			
			PreparedStatement pstmt = m_db.getConnection().prepareStatement(m_sql.toString());
			ResultSet rs = pstmt.executeQuery();
			String obj = null;
//			System.out.println("-------------------------------" + dimensionField);
			for(int i = 0; rs.next(); ++i) {
				obj = rs.getString(1);
//				System.out.println("dimension = " + obj);
				m_dimensionIndexes[dimension].put(obj, i+1);
			}
			long t2 = System.currentTimeMillis();
			System.out.println("getDimensionIndex SQL Time Cost = " + (t2-t1));
//			System.out.println("-------------------------------");
		}
		
		return Integer.parseInt(m_dimensionIndexes[dimension].get(dimensionValue.toString()).toString());
	}
}
