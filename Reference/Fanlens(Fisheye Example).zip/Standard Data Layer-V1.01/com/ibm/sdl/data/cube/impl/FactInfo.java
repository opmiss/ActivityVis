/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.sdl.data.cube.impl;

import java.util.ArrayList;
import java.util.List;

/**
 * @author CaoNan (nancao@cn.ibm.com)
 */

public class FactInfo implements IFactInfo {

	private String m_factTable;
	
	private List m_factFields;
	private List m_dimensionFields;
	
	public FactInfo(String factTable){
		m_factTable = factTable;
		m_factFields = new ArrayList();
		m_dimensionFields = new ArrayList();
	}
	
	public void addDimensionField(Object field) {
		m_dimensionFields.add(field);
	}

	public void addFactField(Object field) {
		m_factFields.add(field);
	}

	public Object[] getDimensionFields() {
		return m_dimensionFields.toArray();
	}

	public Object[] getFactFields() {
		return m_factFields.toArray();
	}

	public String getFactTable() {
		return m_factTable;
	}

	public void setFactTable(String name) {
		m_factTable = name;
	}

	public boolean containsDimensionField(Object field){
		return m_dimensionFields.contains(field);
	}
	public boolean containsFactField(Object field){
		return m_factFields.contains(field);
	}
}
