package com.ibm.research.visualization.peony.component.fanlens.util;

import java.io.Serializable;
import java.util.ArrayList;

import com.ibm.research.visualization.peony.component.fanlens.FanLensLayer;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.util.PropOperator;

public class InspectParam implements Serializable {

	private int m_depth = -1;

	private ArrayList m_relatedElem = new ArrayList();

	public InspectParam(Object t, Object elem) {
		m_depth = -1;
		m_relatedElem.clear();
		
		ITreeDataEx tree = (ITreeDataEx) t;

		if (!tree.contains(elem))
			return;

		m_depth = tree.getDepth(elem);
		
//		m_depth = PropOperator.getInstance().getInteger(EntityTree.PROP_TREENODE_DEPTH, elem);	
		
//		for (Object node = elem; node != null ; ){
//			m_relatedElem.add(0, ((VisualNode)node).getProperty(IName.PROP_NAME));
//			node = tree.getParent(node);
//		}
		m_relatedElem = (ArrayList) PropOperator.getInstance().getProperty(FanLensLayer.PROP_ANCESTORS, elem);
	}
	
	public int getDepth(){
		return m_depth;
	}
	
	public ArrayList getRelatedElement(){
		return m_relatedElem;
	}
}