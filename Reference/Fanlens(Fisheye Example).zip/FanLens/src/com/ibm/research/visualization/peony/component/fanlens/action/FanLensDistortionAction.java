package com.ibm.research.visualization.peony.component.fanlens.action;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import com.ibm.peony.action.ActionAdapter;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayout;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.api.ITreeDataEx;

public class FanLensDistortionAction extends ActionAdapter {

	public static final double FISHEYE_D = 2.0;

	public static final double FISHEYE_P = 0.1;

	public static final double FISHEYE_HALF_RANGE = 0.05;

	protected List nodesInLevel = new ArrayList(0);

	protected int focusLevel = -1;

	public FanLensDistortionAction() {
		this.m_bGeneralAction = true;
		this.m_mask = MouseEvent.SHIFT_DOWN_MASK;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();

		if (e.getKeyCode() == KeyEvent.VK_SHIFT) {
			if (nodesInLevel.size() > 0) {
				focusLevel = -1;
				clearPreviousDistortion(nodesInLevel);
				vislayer.update();
				LayerUtil.runUpdate(vislayer);
			}
		}
		super.keyReleased(e);
	}

	public void mouseMoved(MouseEvent e) {

		if ((e.getModifiersEx() & m_mask) != m_mask) {
			super.mouseMoved(e);
			return;
		}

		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) (vislayer.getLayout());
		FanLensData data = (FanLensData) layout.getFanLensData();
		ITreeDataEx tree = (ITreeDataEx) (vislayer.getData());

		double cx = layout.getCenter().getX();
		double cy = layout.getCenter().getY();
		double px = e.getPoint().getX();
		double py = e.getPoint().getY();

		// compute angle
		double angle = FanLensUtil.computeNormalizedAngle(cx, cy, px, py);

		// compute level
		double d = Math.sqrt(Math.pow(cx - px, 2) + Math.pow(cy - py, 2))
				/ layout.getSquareSize();
		int level = data.getLevelByDistance(d);

		// clear previous distortion
		clearPreviousDistortion(nodesInLevel);

		// get nodes in level
		if (level != focusLevel) {

			// set new level
			focusLevel = level;

			// get all nodes in the level
			nodesInLevel.clear();
			FanLensUtil.getAllNodesAtLevel(tree, tree.getTreeRoot(),
					focusLevel, 0, nodesInLevel);

		}

		// construct the full array
		List nodesInDistortion = new ArrayList(0);
		for (int i = 0; i < nodesInLevel.size(); i++) {
			IVisualNode node = (IVisualNode) nodesInLevel.get(i);

			double start = FanLensUtil.parseDoubleFromProperty(node,
					FanLensData.RROP_START, 0.1);
			double end = start
					+ FanLensUtil.parseDoubleFromProperty(node,
							FanLensData.RROP_EXTENT, 0.1);
			if (start > angle + FISHEYE_HALF_RANGE
					|| end < angle - FISHEYE_HALF_RANGE)
				continue;

			nodesInDistortion.add(node);
		}

		double[] x = new double[nodesInDistortion.size() * 2];
		for (int i = 0; i < nodesInDistortion.size(); i++) {
			IVisualNode node = (IVisualNode) nodesInDistortion.get(i);

			double start = FanLensUtil.parseDoubleFromProperty(node,
					FanLensData.RROP_START, 0.1);
			double end = start
					+ FanLensUtil.parseDoubleFromProperty(node,
							FanLensData.RROP_EXTENT, 0.1);
			x[2 * i] = start;
			x[2 * i + 1] = end;
		}

		// System.out.println("----------");

		// perform the distortion
		double[] f = FanLensUtil.fisheyeTransformation(x, angle
				+ FISHEYE_HALF_RANGE, angle - FISHEYE_HALF_RANGE, FISHEYE_D,
				FISHEYE_P);

		// restore to the origin
		for (int i = 0; i < nodesInDistortion.size(); i++) {
			double start = detransform(f[2 * i], angle);
			double end = detransform(f[2 * i + 1], angle);
			double extent = end - start;
			extent = (extent < 0) ? (extent + 1.0) : extent;
			extent = (extent > 1.0) ? (extent - 1.0) : extent;

			IVisualNode node = (IVisualNode) nodesInDistortion.get(i);
			node.setX(start);
			node.setWidth(extent);

			// System.out.println(nodesInLevel.get(index) + " " + start + " " +
			// end);

			// update the node
			layout.updateRawShape(vislayer, node);
			// vislayer.update(node);
		}

		// LayerUtil.repaint(vislayer);
		vislayer.update();
		LayerUtil.runUpdate(vislayer);

		super.mouseMoved(e);
	}

	public double transform(double x, double angle) {
		double r;
		if (angle < 0.5)
			r = (x <= angle + 0.5) ? x : (x - 1.0);
		else
			r = (x <= angle - 0.5) ? (x + 1.0) : x;

		return r;
	}

	public double detransform(double x, double angle) {
		double r;

		if (angle < 0.5)
			r = (x < 0) ? (x + 1.0) : x;
		else
			r = (x < 1.0) ? x : (x - 1.0);

		return r;
	}

	public void clearPreviousDistortion(Object list) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) (vislayer.getLayout());
		List nodesToUpdate = (List) list;

		// restore previous focused level
		for (int i = 0; i < nodesToUpdate.size(); i++) {
			IVisualNode node = (IVisualNode) nodesToUpdate.get(i);
			node.setX(FanLensUtil.parseDoubleFromProperty(nodesToUpdate.get(i),
					FanLensData.RROP_START, 0.0));
			node.setWidth(FanLensUtil.parseDoubleFromProperty(nodesToUpdate
					.get(i), FanLensData.RROP_EXTENT, 0.0));

			// update it
			layout.updateRawShape(vislayer, node);
		}
	}

	// @Override
	// public void mouseMoved(MouseEvent e) {
	//
	// if ((e.getModifiersEx() & m_mask) != m_mask) {
	// super.mouseMoved(e);
	// return;
	// }
	//
	// VisualLayer vislayer = (VisualLayer) this.getOwner();
	// FanLensLayout layout = (FanLensLayout) (vislayer.getLayout());
	// FanLensData data = (FanLensData) layout.getFanLensData();
	// ITreeDataEx tree = (ITreeDataEx) (vislayer.getData());
	//
	// double cx = layout.getCenter().getX();
	// double cy = layout.getCenter().getY();
	// double px = e.getPoint().getX();
	// double py = e.getPoint().getY();
	//
	// // compute angle
	// double angle = FanLensUtil.computeNormalizedAngle(cx, cy, px, py);
	//
	// // compute level
	// double d = Math.sqrt(Math.pow(cx - px, 2) + Math.pow(cy - py, 2))
	// / layout.getSquareSize();
	// int level = data.getLevelByDistance(d);
	//
	// // get nodes in level
	// if (level != focusLevel) {
	// // clear previous distortion
	// clearPreviousDistortion();
	//
	// // set new level
	// focusLevel = level;
	//
	// // get all nodes in the level
	// nodesInLevel.clear();
	// FanLensUtil.getAllNodesAtLevel(tree, tree.getTreeRoot(),
	// focusLevel, 0, nodesInLevel);
	//
	// }
	//
	// // construct the full array
	// double[] x = new double[2 * nodesInLevel.size()];
	// for (int i = 0; i < x.length; i += 2) {
	// int index = i / 2;
	// double start = FanLensUtil.parseDoubleFromProperty(nodesInLevel
	// .get(index), FanLensData.RROP_START, 0.1);
	// double end = start
	// + FanLensUtil.parseDoubleFromProperty(nodesInLevel
	// .get(index), FanLensData.RROP_EXTENT, 0.1);
	// x[i] = transform(start, angle);
	// x[i + 1] = transform(end, angle);
	//
	// // System.out.println(nodesInLevel.get(index) + " " + start + " " +
	// // end);
	// }
	//
	// // System.out.println("----------");
	//
	// // perform the distortion
	// double[] f = FanLensUtil.fisheyeTransformation(x, angle + 0.5,
	// angle - 0.5, FISHEYE_D);
	//
	// // restore to the origin
	// for (int i = 0; i < f.length; i += 2) {
	// int index = i / 2;
	// double start = detransform(f[i], angle);
	// double end = detransform(f[i + 1], angle);
	// double extent = end - start;
	// extent = (extent < 0) ? (extent + 1.0) : extent;
	// extent = (extent > 1.0) ? (extent - 1.0) : extent;
	//
	// IVisualNode node = (IVisualNode) nodesInLevel.get(index);
	// node.setX(start);
	// node.setWidth(extent);
	//
	// // System.out.println(nodesInLevel.get(index) + " " + start + " " +
	// // end);
	//
	// // update the node
	// layout.updateRawShape(vislayer, node);
	// // vislayer.update(node);
	// }
	//
	// // LayerUtil.repaint(vislayer);
	// vislayer.update();
	// LayerUtil.runUpdate(vislayer);
	//
	// super.mouseMoved(e);
	// }

	// public double transform(double x, double angle) {
	// double r;
	// if (angle < 0.5)
	// r = (x <= angle + 0.5) ? x : (x - 1.0);
	// else
	// r = (x <= angle - 0.5) ? (x + 1.0) : x;
	//
	// return r;
	// }
	//
	// public double detransform(double x, double angle) {
	// double r;
	//
	// if (angle < 0.5)
	// r = (x < 0) ? (x + 1.0) : x;
	// else
	// r = (x < 1.0) ? x : (x - 1.0);
	//
	// return r;
	// }

	// public void clearPreviousDistortion() {
	// VisualLayer vislayer = (VisualLayer) this.getOwner();
	// FanLensLayout layout = (FanLensLayout) (vislayer.getLayout());
	//
	// focusLevel = -1;
	//
	// // restore previous focused level
	// for (int i = 0; i < nodesInLevel.size(); i++) {
	// IVisualNode node = (IVisualNode) nodesInLevel.get(i);
	// node.setX(FanLensUtil.parseDoubleFromProperty(nodesInLevel.get(i),
	// FanLensData.RROP_START, 0.0));
	// node.setWidth(FanLensUtil.parseDoubleFromProperty(nodesInLevel
	// .get(i), FanLensData.RROP_EXTENT, 0.0));
	//
	// // update it
	// layout.updateRawShape(vislayer, node);
	// }
	// }
}
