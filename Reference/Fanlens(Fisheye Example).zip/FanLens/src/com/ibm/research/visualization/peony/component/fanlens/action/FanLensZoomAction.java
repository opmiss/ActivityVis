package com.ibm.research.visualization.peony.component.fanlens.action;

import java.awt.event.MouseEvent;

import com.ibm.peony.action.ActionAdapter;
import com.ibm.peony.display.ILayer;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayout;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.api.ITreeDataEx;

public class FanLensZoomAction extends ActionAdapter {
	protected double start = 0.0;

	protected double width = 0.0;

	protected double maxFactor = 0.0;

	protected double zoomingFactor = 1.0;

	IVisualNode parent = null;

	public FanLensZoomAction() {
		this.m_bGeneralAction = true;
		this.m_mask = MouseEvent.BUTTON1_DOWN_MASK | MouseEvent.CTRL_DOWN_MASK;
	}

	@Override
	public void elemPressed(Object element, MouseEvent e) {
		if (e.getModifiersEx() == m_mask) {
			ILayer layer = this.getOwner();
			ITreeDataEx tree = (ITreeDataEx) ((VisualLayer) layer).getData();

			start = e.getPoint().getX();
			parent = (IVisualNode) tree.getParent(element);
			width = 2 * (layer.getWidth() - start);
			maxFactor = 1.0 / parent.getWidth();
		}

		super.elemPressed(element, e);
	}

	@Override
	public void elemDragged(Object element, MouseEvent e) {
		if (e.getModifiersEx() == m_mask) {
			ILayer layer = this.getOwner();
			FanLensLayout layout = (FanLensLayout) layer.getLayout();
			FanLensData data = (FanLensData) layout.getFanLensData();

			double offset = e.getPoint().getX() - start;
			start = e.getPoint().getX();

			zoomingFactor += offset / width * maxFactor;
			zoomingFactor = Math.max(zoomingFactor, 1.0);
			zoomingFactor = Math.min(zoomingFactor, maxFactor);

			data.setZoomingFactor(parent, zoomingFactor);

			LayerUtil.repaint(layer);
		}
		super.elemDragged(element, e);
	}
}
