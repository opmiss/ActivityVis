package com.ibm.research.visualization.peony.component.fanlens;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.ArrayList;

import com.ibm.peony.display.BaseLayer;
import com.ibm.peony.display.Display;
import com.ibm.peony.display.FIFOLayerRender;
import com.ibm.peony.display.IVisualLayer;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.ITheme;

public class FanlenslayerRender extends FIFOLayerRender {
	public void render(Graphics2D g, BaseLayer layer) {
		
		Display owner = layer.getOwner();
		
		if (owner == null) {
			return;
		}
				
		if(!(layer instanceof IVisualLayer)) {
			return;
		}

		final VisualLayer vislayer = (VisualLayer)layer;
		
		if (vislayer.isHighQuality()) {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		} else {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_OFF);
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		}
		
		
		Object[] elems = vislayer.getElements(
				vislayer.getClipFilter(), 
				vislayer.getPaintComparator());
		ArrayList highList= new ArrayList();
		if(null == elems || elems.length == 0) {
			return;
		}
		
		IVisualElement e = null;
		IRender r = null;
		ITheme t = null;
		for (int i = 0; i < elems.length; ++i) {
			e = (IVisualElement) elems[i];
			
			if (null == e || !e.isVisible()) {
				continue;
			}
			
			r = vislayer.getRender(e);
			if (null == r) {
				continue;
			}
			
			t = vislayer.getTheme(e);
			if(null == t) {
				continue;
			}
			boolean highLight = e.isHighlight() || e.isFocused();
			if (highLight){
				highList.add(e);
			}else{
				r.render(g, e, t, false);
			}
		}
		
		for (int i=0;i<highList.size();i++){
			e = (IVisualElement)highList.get(i);
			r = vislayer.getRender(e);
			t = vislayer.getTheme(e);
			r.render(g, e, t, true);
		}
	}
}
