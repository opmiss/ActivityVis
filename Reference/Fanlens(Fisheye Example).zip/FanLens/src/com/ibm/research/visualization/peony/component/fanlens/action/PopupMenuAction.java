package com.ibm.research.visualization.peony.component.fanlens.action;

import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.util.List;

import com.ibm.peony.action.ActionAdapter;
import com.ibm.peony.display.VisualLayer;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayer;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayout;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;


public class PopupMenuAction extends ActionAdapter implements ActionListener {

	protected boolean initialized = false;

	protected PopupMenu menu = new PopupMenu();
	
	protected MenuItem miUndo = new MenuItem("undo");
	
	protected MenuItem miRedo = new MenuItem("Redo");
	
	protected MenuItem miSave = new MenuItem("Save State");
	
	protected MenuItem miLoad = new MenuItem("Load State");

	protected MenuItem miReset = new MenuItem("Reset");

	protected MenuItem miRefresh = new MenuItem("Refresh");
	
	protected MenuItem miIncrBaseLevel = new MenuItem("Base Level ++");
	
	protected MenuItem miDecrBaseLevel = new MenuItem("Base Level --");

	protected Menu menuMapColorTo = new Menu("Map Color To");

	protected MenuItem miMapColorToNone = new MenuItem("NONE");

	protected Menu menuMapAngleTo = new Menu("Map Angle To");

	protected MenuItem miMapWeightToNone = new MenuItem("NONE");

	public PopupMenuAction() {
		m_mask = MouseEvent.BUTTON3_DOWN_MASK;
		m_bGeneralAction = true;
	}

	/**
	 * Right mouse popup menu: -> Group/ungroup select node(s) Move axis to ->
	 * Before (axis 0) Between (axis 0) and (axis 1) ...
	 * 
	 */
	protected void initMenu() {
		VisualLayer vislayer = (VisualLayer) getOwner();
		FanLensLayout layout = (FanLensLayout) getOwner().getLayout();

		menu = new PopupMenu();
		
		miUndo.addActionListener(this);
		miUndo.setEnabled(false);
		menu.add(miUndo);
		
		miRedo.addActionListener(this);
		miRedo.setEnabled(false);
		menu.add(miRedo);
		
		miSave.addActionListener(this);
		miSave.setEnabled(false);
		menu.add(miSave);
		
		miLoad.addActionListener(this);
		miLoad.setEnabled(false);
		menu.add(miLoad);
		
		menu.add(new MenuItem("-"));

		// refresh item
		miRefresh.addActionListener(this);
		menu.add(miRefresh);

		// reset item
		miReset.addActionListener(this);
		menu.add(miReset);

		// seperator
		menu.add(new MenuItem("-"));
		
		// increase base level
		miIncrBaseLevel.addActionListener(this);
		menu.add(miIncrBaseLevel);
		
		// decrease base level
		miDecrBaseLevel.addActionListener(this);
		menu.add(miDecrBaseLevel);
		
		// seperator
		menu.add(new MenuItem("-"));
		
		// set weight key item
		menu.add(menuMapAngleTo);
		miMapWeightToNone.addActionListener(this);

		// set color key item
		menu.add(menuMapColorTo);
		miMapColorToNone.addActionListener(this);

		// add popup menu
		vislayer.getOwner().add(menu);
	}

	public void updateMenu(MouseEvent e) {
		VisualLayer vislayer = (VisualLayer) getOwner();
		FanLensLayout layout = (FanLensLayout) getOwner().getLayout();
		FanLensData data = (FanLensData) layout.getFanLensData();

		List keys = (List) data.getKeyCollection();

		// update "Set Color Key" menu & "Set Weight Key" menu
		menuMapColorTo.removeAll();
		menuMapColorTo.add(miMapColorToNone);
		menuMapColorTo.add(new MenuItem("-"));

		menuMapAngleTo.removeAll();
		menuMapAngleTo.add(miMapWeightToNone);
		menuMapAngleTo.add(new MenuItem("-"));

		for (int i = 0; i < keys.size(); i++) {
			MenuItem mi = new MenuItem(keys.get(i).toString());
			mi.addActionListener(this);
			menuMapColorTo.add(mi);

			mi = new MenuItem(keys.get(i).toString());
			mi.addActionListener(this);
			menuMapAngleTo.add(mi);
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getModifiersEx() == m_mask) {

			if (!initialized) {
				initMenu();
				initialized = true;
			}
			updateMenu(e);
			menu.show(e.getComponent(), e.getX(), e.getY());
		}
		super.mousePressed(e);
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		VisualLayer vislayer = (VisualLayer) getOwner();
		FanLensLayout layout = (FanLensLayout) getOwner().getLayout();
		FanLensData data = (FanLensData) layout.getFanLensData();

		if (miUndo.equals(source)){
			m_owner.getActionRecroder().undo(1);
			LayerUtil.repaint(vislayer);
		}
		else if(miRedo.equals(source)){
			m_owner.getActionRecroder().redo(1);
			LayerUtil.repaint(vislayer);			
		}
		else if(miSave.equals(source)){
			((FanLensLayer)getOwner()).saveState();
//			LayerUtil.repaint(vislayer);	
		}
		else if(miLoad.equals(source)){
			((FanLensLayer)getOwner()).loadState();
//			LayerUtil.repaint(vislayer);			
		}
		// refresh
		else if (miRefresh.equals(source)) {
			LayerUtil.runUpdate(vislayer);
		}
		// reset
		else if (miReset.equals(source)) {
			data.reset();
			LayerUtil.repaint(vislayer);
		}
		// set color key to NONE
		else if (miMapColorToNone.equals(source)) {
			data.setColorKey("");
			layout.setInitialized(false);
			LayerUtil.repaint(vislayer);
		}
		// set color key
		else if (isSettingColorKey(e)) {
			data.setColorKey(e.getActionCommand());
			layout.setInitialized(false);
			LayerUtil.repaint(vislayer);
		}
		// set weight key to NONE
		else if (miMapWeightToNone.equals(source)) {
			data.setAngleKey("");
			layout.setInitialized(false);
			LayerUtil.repaint(vislayer);
		}
		// set weight key
		else if (isSettingWeightKey(e)) {
			data.setAngleKey(e.getActionCommand());
			layout.setInitialized(false);
			LayerUtil.repaint(vislayer);
		}
		// increase base level
		else if (miIncrBaseLevel.equals(source)) {
			try {
				data.setBaseLevel(vislayer.getData(), data.getBaseLevel() + 1);
				((FanLensLayer)vislayer).clearPickQueue();
				LayerUtil.repaint(vislayer);
				LayerUtil.updatePickQueue(vislayer);
			} catch (InvalidateTypeException e1) {
				e1.printStackTrace();
			}
		}
		// decrease base level
		else if (miDecrBaseLevel.equals(source)) {
			try {
				data.setBaseLevel(vislayer.getData(), data.getBaseLevel() - 1);
				((FanLensLayer)vislayer).clearPickQueue();
				LayerUtil.repaint(vislayer);
				LayerUtil.updatePickQueue(vislayer);
			} catch (InvalidateTypeException e1) {
				e1.printStackTrace();
			}
		}
	}

	public boolean isSettingColorKey(ActionEvent e) {
		Object source = e.getSource();

		for (int i = 0; i < menuMapColorTo.getItemCount(); i++) {
			if (!source.equals(miMapColorToNone)
					&& source.equals(menuMapColorTo.getItem(i)))
				return true;
		}

		return false;
	}

	public boolean isSettingWeightKey(ActionEvent e) {
		Object source = e.getSource();

		for (int i = 0; i < menuMapAngleTo.getItemCount(); i++) {
			if (!source.equals(miMapWeightToNone)
					&& source.equals(menuMapAngleTo.getItem(i)))
				return true;
		}

		return false;
	}
}