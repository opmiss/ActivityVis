/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens.action;

import com.ibm.peony.display.IVisualLayer;
import com.ibm.peony.util.activity.Activity;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayout;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.InvalidateTypeException;

public class FanLensBrowseAnimator extends Activity {

	private IVisualLayer layer = null;

	public FanLensBrowseAnimator() {
		super();
	}

	public FanLensBrowseAnimator(long duration) {
		super(duration);
	}

	public FanLensBrowseAnimator(long duration, long rate) {
		super(duration, rate);
	}

	public FanLensBrowseAnimator(long duration, long rate, long start) {
		super(duration, rate, start);
	}

	public void perform(double frac) {

		if (null == layer)
			layer = (IVisualLayer) this.getLayer();

		if (null == layer)
			return;

		FanLensLayout layout = (FanLensLayout) layer.getLayout();
		FanLensData data = (FanLensData) layout.getFanLensData();

		if (null == layout || null == data)
			return;

		data.setAnimationFrac(frac);
		LayerUtil.repaint(m_layer);
	}

	public boolean start() {
		m_layer.setQuality(false);
		return true;
	}

	public void finish() {
		if (null == layer)
			layer = (IVisualLayer) this.getLayer();

		if (null == layer)
			return;

		FanLensLayout layout = (FanLensLayout) layer.getLayout();
		FanLensData data = (FanLensData) layout.getFanLensData();

		if (null == layout || null == data)
			return;

		try {
			if (null != data.getCollapseTo())
				FanLensUtil.removeChildren(layer.getData(), data
						.getCollapseTo());
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
		}

		data.setAnimationFrac(1.0);		
		data.clearCollapseTo();
		data.clearExpandFrom();

		m_layer.setQuality(true);
		LayerUtil.repaint(m_layer);
	}
}
