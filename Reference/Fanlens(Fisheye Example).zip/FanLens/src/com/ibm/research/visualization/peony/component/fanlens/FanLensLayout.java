/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens;

import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.Comparator;

import com.ibm.peony.display.IVisualLayer;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.layout.ILayout;
import com.ibm.research.visualization.peony.component.fanlens.theme.FanLensNodeTheme;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.ITreeDataEx;

public class FanLensLayout implements ILayout {
		
	public static final int LAYOUT_ROOT = 0;
	public static final int NOT_LAYOUT_ROOT = 1;
	public static int layout_method = LAYOUT_ROOT;
	
	private static final long serialVersionUID = 3680681961879443183L;

	public static final String PROP_FAN = "#PROP_FAN#";

	public static final int DEFAULT_SPACE = 4;

	private Shape m_rawShape = new Arc2D.Double();

	private Shape innerShape = new Arc2D.Double();

	protected boolean initialized = false;

	protected boolean setDefaultBaseLevel = false;

	protected FanLensData data = new FanLensData();

	protected Comparator comp = null;

	protected Point2D center = new Point2D.Double();

	protected Rectangle2D bounds = new Rectangle2D.Double();

	protected double squareSize = 0.0;
	
	
	public FanLensLayout(){
		layout_method = this.LAYOUT_ROOT;
	}
	
	public FanLensLayout(int layout){
		layout_method = layout;
	}

	public String getName() {
		return "FanLens Layout";
	}

	public String getDescription() {
		return "FanLens Layout";
	}

	/**
	 * execute layout here
	 * 
	 * @param context
	 * @return
	 */
	public void layout(Object context) {

		if (null == context || !(context instanceof IVisualLayer))
			return;

		// local variables
		VisualLayer vislayer = (VisualLayer) context;
		ITreeDataEx tree = (ITreeDataEx) vislayer.getData();

		if (null == tree || null == vislayer)
			return;

		IVisualNode root = (IVisualNode) tree.getTreeRoot();
		FanLensNodeTheme theme = (FanLensNodeTheme) vislayer.getTheme(root);

		// initialize
		if (!initialized) {
			initialized = true;

			// disable listeners
			// IDataListener[] listeners = tree.removeDataListeners();
			tree.removeDataListeners();

			try {
				// set the full tree
				data.setFullTree(tree);

				// create the full tree
				data.initialize();

				// get theme and update color map
				int colorBy = data.getColorKey().equals("") ? FanLensNodeTheme.COLOR_BY_INDEX
						: FanLensNodeTheme.COLOR_BY_VALUE;
				theme.updateColorMap(tree, data, colorBy);

				if (!setDefaultBaseLevel) {

					// set default base level
					data.setBaseLevel(tree, FanLensData.DEFAULT_BASE_LEVEL);

					// update picking queue
					LayerUtil.updatePickQueue(vislayer);

					setDefaultBaseLevel = true;
				}

			} catch (InvalidateTypeException e) {
				e.printStackTrace();
			}

			// enable listeners
			// for (int i=0; i<listeners.length; i++)
			// tree.addDataListener(listeners[i]);
		}

		// layout
		radiaLayout(context, tree, tree.getTreeRoot());
		radiiLayout(context, tree);

		// update raw shape
		updateRawShape(context, tree, tree.getTreeRoot());

		// enable listeners
		// for (int i = 0; i < listeners.length; i++)
		// tree.addDataListener(listeners[i]);
	}
	
	public void updateRawShape(Object l, Object n) {
		VisualLayer vislayer = (VisualLayer) l;
		FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
		IVisualNode node = (IVisualNode) n;

		// variables
		double squareSize = layout.getSquareSize();

		// compute the radii
		double innerRadii = node.getY() * squareSize;
		double outterRadii = (node.getY() + node.getHeight()) * squareSize
				- DEFAULT_SPACE;
		// compute the angle
		double start = node.getX() * 360;
		double extent = node.getWidth() * 360;

		// create arc
		int closure =  Arc2D.PIE;
		if (layout_method == LAYOUT_ROOT){
			closure = innerRadii == 0 ? Arc2D.OPEN : Arc2D.PIE;
		}
		
		
		((Arc2D) m_rawShape).setArcByCenter(layout.getCenter().getX(), layout
				.getCenter().getY(), outterRadii, start, extent, closure);
		((Arc2D) innerShape)
				.setArcByCenter(layout.getCenter().getX(), layout.getCenter()
						.getY(), innerRadii, start - 2, extent + 4, closure);

		Area fan = new Area(m_rawShape);

		Area innerPart = new Area(innerShape);

		fan.subtract(innerPart);

		node.removeProperty(PROP_FAN);
		node.addProperty(PROP_FAN, fan);
	}

	public void updateRawShape(Object l, Object t, Object n) {
		VisualLayer vislayer = (VisualLayer) l;
		ITreeDataEx tree = (ITreeDataEx) t;
		
		updateRawShape(l, n);

		// browse to it's children
		Object[] children = tree.getChildren(n, null);
		if (null != children)
			for (int i = 0; i < children.length; i++)
				updateRawShape(vislayer, tree, children[i]);
	}

	/**
	 * radial space filling layout algorithm
	 * 
	 * @param t
	 * @param n
	 */
	public void radiaLayout(Object l, Object t, Object n) {
		ITreeDataEx tree = (ITreeDataEx) t;
		IVisualNode node = (IVisualNode) n;

		if (tree.getTreeRoot().equals(n)) {
			((IVisualNode) tree.getTreeRoot()).setX(0.0);
			((IVisualNode) tree.getTreeRoot()).setWidth(1.0);
		}

		Object[] children = tree.getChildren(n, comp);
		double start = node.getX();
		double width = node.getWidth();
		double extent = FanLensUtil.parseDoubleFromProperty(node,
				FanLensData.RROP_EXTENT, 0.0);

		double zoomingFactor = data.getZoomingFactor(node);
		start -= (zoomingFactor - 1.0) * width / 2;
		width *= zoomingFactor;

		if (null != children)
			for (int i = 0; i < children.length; i++) {
				IVisualNode child = (IVisualNode) children[i];
				
				child.setX(start);
				child.addProperty(FanLensData.RROP_START, start);
				
				child.setWidth(FanLensUtil.parseDoubleFromProperty(child,
						FanLensData.RROP_EXTENT, 0.0)
						/ extent * width);
				
				start += child.getWidth();

				radiaLayout(l, tree, child);
			}
	}

	/**
	 * layout and compute the radii of slices
	 * 
	 * @param t
	 */
	public void radiiLayout(Object l, Object t) {
		// local variables
		VisualLayer vislayer = (VisualLayer) l;
		ITreeDataEx tree = (ITreeDataEx) t;
		int panelWidth = vislayer.getWidth();
		int panelHeight = vislayer.getHeight();

		// get bounds
		bounds = (Rectangle2D) data.computeBaseLevelBounds();
		data.computeExpandedBounds(tree, tree.getTreeRoot(), bounds);

		/*
		 * normalize
		 */
		double zoomFactor = Math.max(bounds.getWidth(), bounds.getHeight());
		double xOffset = Math.max(0, (zoomFactor - bounds.getWidth()) / 2.0);
		double yOffset = Math.max(0, (zoomFactor - bounds.getHeight()) / 2.0);

		// update the square size
		squareSize = data.updateSquareSize(vislayer.getWidth(), vislayer
				.getHeight(), bounds);

		// update center
		data.updateCenter(bounds, center, zoomFactor, xOffset, yOffset);
		double xCenter = center.getX() * squareSize + (panelWidth - squareSize)
				/ 2;
		double yCenter = center.getY() * squareSize
				+ (panelHeight - squareSize) / 2;
		center.setLocation(xCenter, yCenter);

		// update radii
		data.updateRadii(tree, tree.getTreeRoot(), zoomFactor);
	}

	/**
	 * get center
	 * 
	 * @return
	 */
	public Point2D getCenter() {
		return center;
	}

	/**
	 * reset
	 * 
	 * @return
	 */
	public void reset() {
		initialized = false;
	}

	/**
	 * get fanlens data object
	 * 
	 * @return
	 */
	public Object getFanLensData() {
		return data;
	}

	/**
	 * get bounds
	 * 
	 * @return
	 */
	public Object getBounds() {
		return bounds;
	}

	/**
	 * get square size
	 * 
	 * @return
	 */
	public double getSquareSize() {
		return squareSize;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}
}
