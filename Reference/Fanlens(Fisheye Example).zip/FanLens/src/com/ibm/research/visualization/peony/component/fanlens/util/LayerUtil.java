package com.ibm.research.visualization.peony.component.fanlens.util;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.util.activity.Activity;

public class LayerUtil {
	public static void repaint(ILayer layer) {
		layer.doLayout();
		layer.update();
		layer.getOwner().repaint();
	}
	
	public static void runAnimation(ILayer layer, Activity animator) {
		animator.setStartTime(System.currentTimeMillis());
		animator.setLayer(layer);
		layer.getOwner().getActivityManager().addActivity(animator);
	}
	
	public static void runUpdate(ILayer layer) {
		layer.getOwner().repaint();
	}
	
	/**
	 * update the picking queue
	 * 
	 * @param layer
	 */
	public static void updatePickQueue(ILayer layer) {
		((VisualLayer) layer).setPickComparator(null);
	}
}