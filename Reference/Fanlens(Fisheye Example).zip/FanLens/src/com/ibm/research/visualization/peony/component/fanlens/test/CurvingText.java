package com.ibm.research.visualization.peony.component.fanlens.test;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.font.FontRenderContext;
import java.awt.geom.AffineTransform;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
 
public class CurvingText extends JPanel implements ActionListener {
    GeneralPath path;
    CubicCurve2D cubic;
    QuadCurve2D quad;
    Ellipse2D circle;
    String text = "HelloWorld";
    double[] tokenWidths;
    Point2D.Double[] points;
    int offset = 0;
 
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
        Font font = g2.getFont().deriveFont(36f);
        g2.setFont(font);
        FontRenderContext frc = g2.getFontRenderContext();
        if(path == null)
            initGeometry(font, frc);
        g2.draw(path);
        // layout text beginning at offset along curve
        String[] tokens = text.split("(?<=[\\w\\s])");
        for(int j = 0; j < points.length-1; j++) {
            double theta = getAngle(j);
            AffineTransform at =
                AffineTransform.getTranslateInstance(points[j].x, points[j].y);
            at.rotate(theta);
            g2.setFont(font.deriveFont(at));
            g2.drawString(tokens[j], 0, 0);
        }
    }
 
    private double getAngle(int index) {
        double dy = points[index+1].y - points[index].y;
        double dx = points[index+1].x - points[index].x;
        return Math.atan2(dy, dx);
    }
 
    private void initGeometry(Font font, FontRenderContext frc) {
        int w = getWidth();
        int h = getHeight();
        // cubic curve
        double x1 = w/4.0;
        double y1 = h/16.0;
        double ctrlx1 = w/2.0;
        double ctrly1 = h*2/5.0;
        double ctrlx2 = w*13/16.0;
        double ctrly2 = h/3.0;
        double x2 = w*7/8.0;
        double y2 = h*7/8.0;
        cubic = new CubicCurve2D.Double(x1, y1, ctrlx1, ctrly1,
                                        ctrlx2, ctrly2, x2, y2);
        // quad curve
        x1 = w/7.0;
        y1 = h*15/16.0;
        double ctrlx = w/3.0;
        double ctrly = h/10.0;
        x2 = w*11/12.0;
        y2 = h*19/24.0;
        quad = new QuadCurve2D.Double(x1, y1, ctrlx, ctrly, x2, y2);
        // circle
        x1 = w/4.0;
        y1 = h/8.0;
        double r = Math.min(w,h)/3.0;
        circle = new Ellipse2D.Double(x1, y1, 2*r, 2*r);
        // collect token widths
        tokenWidths = getTokenWidths(font, frc);
        assignPath(quad);
    }
 
    private void assignPath(Shape s) {
        path = new GeneralPath(s);
        // collect path points
        Point2D.Double[] points = getPathPoints();
        collectLayoutPoints(points);
    }
 
    private Point2D.Double[] getPathPoints() {
        double flatness = 0.01;
        PathIterator pit = path.getPathIterator(null, flatness);
        int count = 0;
        while(!pit.isDone()) {
            count++;
            pit.next();
        }
        Point2D.Double[] points = new Point2D.Double[count];
        pit = path.getPathIterator(null, flatness);
        double[] coords = new double[6];
        count = 0;
        while(!pit.isDone()) {
            int type = pit.currentSegment(coords);
            switch(type) {
                case PathIterator.SEG_MOVETO:
                case PathIterator.SEG_LINETO:
                    points[count++] = new Point2D.Double(coords[0], coords[1]);
                    break;
                case PathIterator.SEG_CLOSE:
                    break;
                default:
                    System.out.println("unexpected type: " + type);
            }
            pit.next();
        }
        return points;
    }
 
    private double[] getTokenWidths(Font font, FontRenderContext frc) {
        String[] tokens = text.split("(?<=[\\w\\s])");
        double[] widths = new double[tokens.length];
        for(int j = 0; j < tokens.length; j++) {
            float width = (float)font.getStringBounds(tokens[j], frc).getWidth();
            widths[j] = width;
        }
        return widths;
    }
 
    private void collectLayoutPoints(Point2D.Double[] p) {
        int index = 0;
        int n = tokenWidths.length;
        double distance = offset;
        points = new Point2D.Double[n+1];
        for(int j = 0; j < tokenWidths.length; j++) {
            index = getNextPointIndex(p, index, distance);
            points[j] = p[index];
            distance = tokenWidths[j];
        }
        index = getNextPointIndex(p, index, tokenWidths[n-1]);
        points[points.length-1] = p[index];
    }
 
    private int getNextPointIndex(Point2D.Double[] p,
                                  int start, double targetDist) {
        for(int j = start; j < p.length; j++) {
            double distance = p[j].distance(p[start]);
            if(distance > targetDist) {
               return j;
            }
        }
        return start;
    }
 
    public static void main(String[] args) {
        CurvingText ct = new CurvingText();
        JFrame f = new JFrame();
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().add(ct);
        f.getContentPane().add(ct.getControls(), "Last");
        f.setSize(400,400);
        f.setLocation(200,200);
        f.setVisible(true);
    }
 
    public void actionPerformed(ActionEvent e) {
        String ac = e.getActionCommand();
        Shape s = null;
        if(ac.equals("cubic"))
            s = cubic;
        else if(ac.equals("quad"))
            s = quad;
        else if(ac.equals("circle"))
            s = circle;
        assignPath(s);
        repaint();
    }
 
    private JPanel getControls() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createLoweredBevelBorder());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2,2,2,2);
        gbc.weightx = 1.0;
        String[] ids = { "cubic", "quad", "circle" };
        ButtonGroup group = new ButtonGroup();
        for(int j = 0; j < ids.length; j++) {
            JRadioButton rb = new JRadioButton(ids[j], j==1);
            rb.setActionCommand(ids[j]);
            rb.addActionListener(this);
            group.add(rb);
            panel.add(rb, gbc);
        }
        return panel;
    }
}
