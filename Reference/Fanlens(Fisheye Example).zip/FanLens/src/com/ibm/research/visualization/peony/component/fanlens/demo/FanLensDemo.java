/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com), Wei Hong Qian(qianwh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.FileInputStream;

import javax.swing.JFrame;

import com.ibm.peony.geometry.VisualEdge;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.research.visualization.peony.component.fanlens.FanLensDisplay;
import com.ibm.research.visualization.peony.component.fanlens.util.FanTableReader;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.table.impl.EntityTable;
import com.ibm.sdl.util.io.IDataReader;
import com.ibm.sdl.util.io.TMLReader;

public class FanLensDemo extends JFrame {
	private static final long serialVersionUID = -5838812273931009398L;

	private Object m_data;

	public FanLensDemo() {
		try {
			readCSVData();
//			readXMLData();
			initComponent();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void readCSVData() throws Exception {
		FanTableReader reader = new FanTableReader();
		reader.read(new FileInputStream("data/pc_demo_body_fat.csv"));		
//		FanTableReader reader = new FanTableReader(true);
//		reader.read(new FileInputStream("data/FanLens_Sample_NBA_order.csv"));
		m_data = reader.getData();
	}

	private void readXMLData() throws Exception {
		IDataReader reader = new TMLReader(VisualNode.class, VisualEdge.class);
		reader.read(new FileInputStream("data/fanlens_demo_college.xml"));
		m_data = reader.getData();
	}

	private void initComponent() throws Exception {
		FanLensDisplay display = new FanLensDisplay();
//		display.setData(fakeData());
		display.setData(m_data);
		display.setBackground(Color.white);
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(display, BorderLayout.CENTER);
		this.setTitle("FanLens Demo");
		this.setSize(800, 800);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private EntityTable fakeData() {
		try {
			String[] columns = new String[]{"column1", "column2", "column3", "column4", "column5"};
			Class[] scheme = new Class[]{String.class, String.class, String.class, String.class, String.class};
			EntityTable table;
			table = new EntityTable(columns, scheme);
			
			VisualNode category = null;
			for(int i = 0; i < 100; ++i) {
				category = new VisualNode();
				for(int j = 0; j < columns.length; ++j) {
					int value = i % (j+5);
					System.out.println(value);
					category.addProperty(columns[j], columns[j]+": "+((Integer)value).toString());
				}
				table.addRow(category);
			}
			return table;
		} catch (InvalidateDataException e) {
			e.printStackTrace();
		} catch (InvalidateTypeException e) {
			e.printStackTrace();
		}
		
		return null;
	}

	public static void main(String[] args) {
		FanLensDemo demo = new FanLensDemo();
		demo.setVisible(true);
	}
}
