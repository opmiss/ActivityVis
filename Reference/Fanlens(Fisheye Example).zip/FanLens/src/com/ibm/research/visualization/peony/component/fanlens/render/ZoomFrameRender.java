package com.ibm.research.visualization.peony.component.fanlens.render;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;

import com.ibm.peony.display.BaseLayer;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.layer.AbstractLayerRender;
import com.ibm.sdl.data.api.ITreeDataEx;

public class ZoomFrameRender extends AbstractLayerRender {

	public void render(Graphics2D g, BaseLayer layer) {
		if(!(layer instanceof VisualLayer)) {
			return;
		}
		
		VisualLayer vislayer = (VisualLayer)layer;
	}
}
