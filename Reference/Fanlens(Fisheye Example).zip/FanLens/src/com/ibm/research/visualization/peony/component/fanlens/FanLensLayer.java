package com.ibm.research.visualization.peony.component.fanlens;

import java.util.ArrayList;

import com.ibm.peony.action.IAction;
import com.ibm.peony.display.Display;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.VisualEdge;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.peony.state.ActionRecord;
import com.ibm.peony.state.IViewState;
import com.ibm.peony.state.ViewState;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.ITableData;
import com.ibm.sdl.data.api.ITableDataEx;
import com.ibm.sdl.data.table.impl.EntityTable;
import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.IType;
import com.ibm.sdl.util.prop.Property;

public class FanLensLayer extends VisualLayer {

	private static final long serialVersionUID = 3138059331333641101L;

	public static final String PROP_ANCESTORS = "#ANCESTORS#";
	// bookmark
	private ViewState m_state = new ViewState();


	public FanLensLayer() {
		super();
	}

	public FanLensLayer(Display display) {
		super(display);
	}

	public void clearPickQueue() {
		m_pickqueue = null;
	}

	public void setData(Object data) throws InvalidateDataException {
		if (data instanceof ITableData || data instanceof ITableDataEx)
			try {
				super.setData(TableToTree(data));
			} catch (InvalidateTypeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else{
			ComputeAncestors((EntityTree) data);
			super.setData(data);
		}
	}

	private EntityTree TableToTree(Object data) throws InvalidateTypeException {
		EntityTable table = (EntityTable) data;
		EntityTree mvTree = new EntityTree();
		mvTree.setEdgeType(VisualEdge.class);
		VisualNode root = new VisualNode();
		root.addProperty(IName.PROP_NAME, "root");
		root.addProperty(IType.PROP_TYPE, "root");
		mvTree.addNode(root);
		mvTree.setTreeRoot(root);

		String[] columns = table.getColumnNames();

		for (int i = 0; i < table.getRowCount(); i++) {
			VisualNode row = (VisualNode) table.getRow(i);
			addToTree(mvTree, columns, row);
		}
		ComputeAncestors(mvTree);
		return mvTree;
	}

	private void addToTree(EntityTree tree, String[] columns, Property row) {
		VisualNode parent = (VisualNode) tree.getTreeRoot();
		for (int i = 0; i < columns.length; i++) {
			if (0 == columns[i].compareToIgnoreCase(ITableDataEx.PROP_ROWNAME))
				continue;
			String name = (String) row.getProperty(columns[i]);
			String type = columns[i];
			parent = getNode(tree, parent, name, type);
		}
	}

	private VisualNode getNode(EntityTree tree, VisualNode parent, String name,
			String type) {
		for (int i = 0; i < tree.getChildCount(parent); i++) {
			VisualNode node = (VisualNode) tree.getChild(parent, i);
			if (node.getProperty(IName.PROP_NAME).equals(name)) {
				return node;
			}
		}
		VisualNode n = new VisualNode();
		n.addProperty(IName.PROP_NAME, name);
		n.addProperty(IType.PROP_TYPE, type);

		tree.addChild(parent, n);
		return n;
	}

	private void ComputeAncestors(EntityTree tree) {
		tree.refreshDepth();
		Object[] nodes = tree.getNodes(null, null);
		for (int i = 0; i < nodes.length; i++) {
			ArrayList acestors = new ArrayList(1);
			for (Object node = nodes[i]; node != null;) {
				acestors.add(0, ((VisualNode) node)
						.getProperty(IName.PROP_NAME));
				node = tree.getParent(node);
			}
			((VisualNode)nodes[i]).addProperty(PROP_ANCESTORS, acestors);
//			for(int j = 0 ; j < acestors.size(); j++)
//				System.out.println(acestors.get(j));
		}
	}

//	public void setState(IViewState state) throws InvalidateDataException {
//
//		// restore the data state
//		// this.setData(state.getDataState());
//		this.doLayout();
//
//		// restore the view state
//		ActionRecord[] records = state.getActionTrail();
//		IAction[] actions = getActions();
//		System.out.println("records.length" + records.length);
//		for (int i = 0; i < records.length; ++i) {
//			for (int j = 0; j < actions.length; ++j) {
//				actions[j].execute(records[i].actiontype, records[i].event,
//						records[i].param);
//			}
//		}
//
//		this.update();
//		this.m_owner.repaint();
//	}

	public void saveState() {
		m_state.setDataState(this.m_data);
		m_state.setViewState(m_recorder.getActionRecords());
	}

	public void loadState() {
		try {
			this.setState(this.getState());
			this.doLayout();
			this.update();
			this.m_owner.repaint();
		} catch (InvalidateDataException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
