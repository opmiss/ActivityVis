/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens.render;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Area;

import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.DefaultRender;
import com.ibm.peony.render.ITheme;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayout;
import com.ibm.research.visualization.peony.component.fanlens.theme.FanLensNodeTheme;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.util.prop.IName;

public class FanLensNodeRender extends DefaultRender {
	public static final int DEFAULT_SPACE = 4;

	public static final double RENDER_LABEL_THRESHOLD = 5e-3;

	public FanLensNodeRender() {
	}

	public Shape getRawShape(IVisualElement e) {
		IVisualNode node = (IVisualNode) e;
		Area fan = (Area) node.getProperty(FanLensLayout.PROP_FAN);

		return fan;
	}

	public void render(Graphics2D g, IVisualElement element, ITheme theme,
			boolean highlight) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
		IVisualNode node = (IVisualNode) element;
		if (!node.isVisible())
			return;

		Area fan = (Area)getRawShape(element);
		FanLensNodeTheme nodeTheme = (FanLensNodeTheme) theme;

		// render the fan
		g.setColor(nodeTheme.getFillColor(element, false));
		g.fill(fan);

		// border
		g.setStroke(nodeTheme.getBorderStroke(highlight));
		g.setColor(nodeTheme.getBorderColor(highlight));
		g.draw(fan);

		// get square size
		double squareSize = layout.getSquareSize();
		// compute the angle
		double angleCenter = -(node.getX() + node.getWidth() / 2) * 2 * Math.PI;

		// compute the radii
		double innerRadii = node.getY() * squareSize;
		double outterRadii = (node.getY() + node.getHeight()) * squareSize
				- DEFAULT_SPACE;

		if (node.getWidth() > RENDER_LABEL_THRESHOLD)
			renderLabel(g, element, angleCenter, innerRadii, outterRadii);

		renderExpandableMark(g, element, angleCenter, outterRadii);
	}

	public void renderExpandableMark(Graphics2D g, IVisualElement element,
			double angleCenter, double outterRadii) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
		FanLensData fanlensData = (FanLensData) ((FanLensLayout) vislayer
				.getLayout()).getFanLensData();

		// outter ring
		// Arc2D outterRing = (Arc2D) m_rawShape;

		// is root?
		boolean isRoot = ((ITreeDataEx) vislayer.getData()).getTreeRoot()
				.equals(element);

		// compute the center
		outterRadii -= DEFAULT_SPACE;
		double xCenter = layout.getCenter().getX() + outterRadii * Math.cos(angleCenter);
		double yCenter = layout.getCenter().getY() + outterRadii * Math.sin(angleCenter);

		g.setColor(Color.blue);
		if (fanlensData.isExpandable(element) && !isRoot) {
			g.translate(xCenter, yCenter);
			g.rotate(angleCenter);
			g.fill(fanlensData.getExpandableMark());
			g.rotate(-angleCenter);
			g.translate(-xCenter, -yCenter);
		}
	}

	public void renderLabel(Graphics2D g, IVisualElement element,
			double angleCenter, double innerRadii, double outterRadii) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
		IVisualNode node = (IVisualNode) element;
		Font f = g.getFont();
		FontMetrics fm = g.getFontMetrics();

		// compute the angle
		double cosAngle = Math.cos(angleCenter);
		double sinAngle = Math.sin(angleCenter);

		// compute the center
		double xCenter = layout.getCenter().getX();
		double yCenter = layout.getCenter().getY();

		// is root?
		boolean isRoot = ((ITreeDataEx) vislayer.getData()).getTreeRoot()
				.equals(node);

		// draw text
		g.setColor(Color.black);
		double centerRadii = (outterRadii + innerRadii) / 2;
		// position
		double xText = centerRadii * cosAngle + xCenter;
		double yText = centerRadii * sinAngle + yCenter;
		double textSpaceWidth = isRoot ? outterRadii * 2
				: (outterRadii - innerRadii);
		double maxChar = Math.max(textSpaceWidth / fm.stringWidth("A"), 3);

		String name = node.getProperty(IName.PROP_NAME).toString();

		String label = name.length() <= maxChar ? name : name.substring(0,
				(int) maxChar - 3)
				+ "...";
		int textWidth = fm.stringWidth(label);
		int textHeight = f.getSize();

		if (label.length() > 0) {
			int textOffset = 0;
			double textAngle = angleCenter;
			if (isRoot) {
				xText = xCenter - textWidth / 2;
				yText = yCenter + textHeight / 2;
				textAngle = 0;
			} else {
				if (xText <= xCenter) {
					xText = xText
							- (int) ((textOffset - textWidth / 2) * cosAngle)
							+ (int) (textHeight / 2 * sinAngle);
					yText = yText
							- (int) ((textOffset - textWidth / 2) * sinAngle)
							- (int) (textHeight / 2 * cosAngle);
					textAngle = angleCenter - Math.PI;
				} else {
					xText = xText
							- (int) ((textOffset + textWidth / 2) * cosAngle)
							- (int) (textHeight / 2 * sinAngle);
					yText = yText
							- (int) ((textOffset + textWidth / 2) * sinAngle)
							+ (int) (textHeight / 2 * cosAngle);
				}
			}

			// draw rotated string
			FanLensUtil.drawRotatedString(g, (int) xText, (int) yText,
					textAngle, label);
		}
	}
}