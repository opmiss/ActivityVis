/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens;

import java.awt.Shape;
import java.awt.geom.Arc2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.research.visualization.peony.component.fanlens.util.InspectParam;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.util.prop.IName;

public class FanLensData {

	// constants
	public static final int DEFAULT_BASE_LEVEL = 1;

	public static final String RROP_EXTENT = "#RROP_EXTENT#";

	public static final String RROP_START = "#RROP_START#";

	// variables
	protected double radiiIncrFactor = 1.6181229773462783171521035598706;

	protected List radiiList = new ArrayList(0);

	protected int baseLevel = DEFAULT_BASE_LEVEL;

	protected int maxBaseLevel = DEFAULT_BASE_LEVEL;

	protected int deepestLevel = 0;

	protected ITreeDataEx fullTree = null;

	protected String angleKey = "";

	protected String colorKey = "";

	protected double animationFrac = 1.0;

	protected Object expandFrom = null;

	protected Object collapseTo = null;

	protected GeneralPath expandableMark = new GeneralPath();

	protected Map zoomingFactor = new HashMap(0);

	protected List keyCollection = new ArrayList(0);

	protected Map radiiMap = new HashMap(0);

	public FanLensData() {
		// initialize the expandable mark
		expandableMark.moveTo(0, -5);
		expandableMark.lineTo(0, 5);
		expandableMark.lineTo(5, 0);
		expandableMark.lineTo(0, -5);
	}

	public void setFullTree(Object t) throws InvalidateTypeException {
		// set full tree
		if (null == fullTree) {
			fullTree = (ITreeDataEx) FanLensUtil.cloneTree(t);
			getDeepestLevel(fullTree, fullTree.getTreeRoot(), 0);
			maxBaseLevel = deepestLevel;
		}
	}

	/**
	 * initialize
	 * 
	 * @param t
	 * @throws InvalidateTypeException
	 */
	public void initialize() {

		// initialize geometry
		intializeGeometry();

		// clear variables
		zoomingFactor.clear();
	}

	public Object getFullTree() {
		return fullTree;
	}

	/**
	 * initialize the geometry information of the full tree
	 * 
	 * @return
	 */
	public void intializeGeometry() {
		if (null == fullTree)
			return;

		// initialize weight
		initializeAngle(fullTree, fullTree.getTreeRoot(), getTotalWeight());
	}

	/**
	 * initialize the weight properties
	 * 
	 * @param t
	 * @param n
	 * @return
	 */
	public double initializeAngle(Object t, Object n, double totalWeight) {
		ITreeDataEx tree = (ITreeDataEx) t;

		double weight = 0.0;
		if (tree.isLeaf(n)) {
			weight = FanLensUtil.parseDoubleFromProperty(n, angleKey, 1.0);
		} else {
			Object[] children = tree.getChildren(n, null);
			if (null != children)
				for (int i = 0; i < children.length; i++)
					weight += initializeAngle(tree, children[i], totalWeight);
		}
		((IVisualNode) n).addProperty(RROP_EXTENT, weight / totalWeight);

		return weight;
	}

	public double getTotalWeight() {
		// add the weight of all nodes
		Object[] nodes = fullTree.getNodes(null, null);
		double totalWeight = 0.0;
		for (int i = 0; i < nodes.length; i++) {
			IVisualNode node = (IVisualNode) nodes[i];

			if (fullTree.isLeaf(node))
				totalWeight += FanLensUtil.parseDoubleFromProperty(node,
						angleKey, 1.0);
		}

		return totalWeight;
	}

	public Object getKeyCollection() {
		if (0 == keyCollection.size()) {
			// get one leaf
			Object[] objs = fullTree.getNodes(null, null);
			for (int i = 0; i < objs.length; i++) {
				IVisualNode node = (IVisualNode) objs[i];
				if (!fullTree.isLeaf(node))
					continue;

				Collections.addAll(keyCollection, node.getKeyCollection());
				break;
			}
		}

		return keyCollection;
	}

	/**
	 * set weight key
	 * 
	 * @param key
	 */
	public void setAngleKey(String key) {
		angleKey = key;
	}

	/**
	 * get weight key
	 * 
	 * @return
	 */
	public String getAngleKey() {
		return angleKey;
	}

	/**
	 * get color key
	 * 
	 * @return
	 */
	public String getColorKey() {
		return colorKey;
	}

	/**
	 * set color key
	 * 
	 * @param key
	 */
	public void setColorKey(String key) {
		colorKey = key;
	}

	/**
	 * change the base level
	 * 
	 * @param baseLevel
	 */
	public void setBaseLevel(Object t, int baseLevel)
			throws InvalidateTypeException {
		if (baseLevel < DEFAULT_BASE_LEVEL || baseLevel > maxBaseLevel)
			return;

		ITreeDataEx partialTree = (ITreeDataEx) t;

		this.baseLevel = baseLevel;

		updateBaseLevel(partialTree, partialTree.getTreeRoot(), 0);

		updateDeepestLevel(t);

		reset();
	}

	/**
	 * get the base level
	 * 
	 * @return
	 */
	public int getBaseLevel() {
		return baseLevel;
	}

	/**
	 * update radii list according to current expanding situation
	 * 
	 */
	public void updateRadiiList() {
		radiiList.clear();

		int totalExpandedLevel = deepestLevel + 1;

		double d = (1 - radiiIncrFactor)
				/ (1 - Math.pow(radiiIncrFactor, totalExpandedLevel));
		double radii = 0.0;

		int i = 0;

		if (FanLensLayout.layout_method == FanLensLayout.NOT_LAYOUT_ROOT) {
			i++;
			radiiList.add(0);
		}

		for (; i < totalExpandedLevel; i++) {
			radii += d * Math.pow(radiiIncrFactor, i);
			radiiList.add(radii);
		}
	}

	/**
	 * get the radii at certain level
	 * 
	 * @param level
	 * @return
	 */
	public double getRadii(int level) {
		Object o = radiiList.get(level);
		return Double.parseDouble(o.toString());
	}

	/**
	 * check if one node is in the base level
	 * 
	 */
	public boolean isInsideBaseLevel(Object t, Object n) {
		int level = FanLensUtil.getNodeLevel(t, n);
		return level < baseLevel;
	}

	/**
	 * update the base level for partial tree
	 * 
	 * @param t
	 * @param p
	 * @param level
	 * @return
	 */
	public void updateBaseLevel(Object t, Object p, int level)
			throws InvalidateTypeException {
		ITreeDataEx partialTree = (ITreeDataEx) t;
		Object[] children = fullTree.getChildren(p, null);

		if (null != children)
			for (int i = 0; i < children.length; i++) {
				Object child = children[i];

				if (level < baseLevel) {
					if (null == partialTree.getEdge(p, child))
						partialTree.addChild(p, child);
					updateBaseLevel(t, child, level + 1);
				} else {
					FanLensUtil.removeBranch(partialTree, child);
				}
			}
	}

	/**
	 * update the partial tree structure, handle the expanding/collapse events
	 * 
	 * @param t
	 * @param n
	 * @throws InvalidateTypeException
	 */
	public boolean updatePartialTree(Object t, Object n)
			throws InvalidateTypeException {
		ITreeDataEx partialTree = (ITreeDataEx) t;

		if (!partialTree.contains(n))
			return false;
		if (isInsideBaseLevel(partialTree, n))
			return false;

		// if leaf, expanding
		if (partialTree.isLeaf(n)) {
			Object[] children = fullTree.getChildren(n, null);
			if (null == children)
				return false;

			expandFrom = n;
			for (int i = 0; i < children.length; i++)
				partialTree.addChild(n, children[i]);
		}
		// no leaf, collapse
		else {
			collapseTo = n;
			// Object[] children = partialTree.getChildren(n, null);
			// for (int i = 0; i < children.length; i++)
			// FanLensUtil.removeBranch(partialTree, children[i]);
		}

		updateDeepestLevel(partialTree);

		return true;
	}

	public boolean updatePartialTreeByState(Object t, Object p)
			throws InvalidateTypeException {
		ITreeDataEx partialTree = (ITreeDataEx) t;
		
		InspectParam param = (InspectParam)p;
		
		int depth = param.getDepth();
		
		ArrayList list = param.getRelatedElement();
		
		Object node = partialTree.getTreeRoot();
//		System.out.println("depth: "+depth);
		if(((VisualNode)node).getProperty(IName.PROP_NAME).toString().compareTo(list.get(0).toString()) == 0)
			for( int i = 1 ; i <= depth; i++)
			{
				Object[] next= partialTree.getChildren(node, null);
				for( int j = 0 ; j < next.length; j++)
					if(((VisualNode)next[j]).getProperty(IName.PROP_NAME).toString().compareTo(list.get(i).toString()) == 0)
						{
						node = next[j];
						continue;
						}
			}
//		if (!partialTree.contains(n))
//			return false;
		if (isInsideBaseLevel(partialTree, node))
			return false;

		// if leaf, expanding
		if (partialTree.isLeaf(node)) {
			Object[] children = fullTree.getChildren(node, null);
			if (null == children)
				return false;

			expandFrom = node;
			for (int i = 0; i < children.length; i++)
				partialTree.addChild(node, children[i]);
		}
		// no leaf, collapse
		else {
			collapseTo = node;
			// Object[] children = partialTree.getChildren(n, null);
			// for (int i = 0; i < children.length; i++)
			// FanLensUtil.removeBranch(partialTree, children[i]);
		}

		updateDeepestLevel(partialTree);

		return true;
	}

	/**
	 * update deepest level of the partial tree
	 * 
	 * @param t
	 * @param n
	 * @param level
	 * @return
	 */
	public void updateDeepestLevel(Object t) {
		ITreeDataEx partialTree = (ITreeDataEx) t;
		getDeepestLevel(partialTree, partialTree.getTreeRoot(), 0);
		updateRadiiList();
	}

	/**
	 * get the deepest level
	 * 
	 * @param t
	 * @param n
	 * @param level
	 */
	public void getDeepestLevel(Object t, Object n, int level) {
		ITreeDataEx partialTree = (ITreeDataEx) t;

		if (partialTree.isLeaf(n))
			deepestLevel = Math.max(level, deepestLevel);

		Object[] children = partialTree.getChildren(n, null);
		if (null != children)
			for (int i = 0; i < children.length; i++)
				getDeepestLevel(t, children[i], level + 1);
	}

	/**
	 * compute the base level bounds, assuming that the central point is (0, 0)
	 * 
	 * @param t
	 */
	public Object computeBaseLevelBounds() {
		Rectangle2D bounds = new Rectangle2D.Double();
		double dBaseLevel = getRadii(baseLevel);
		bounds.setFrame(-dBaseLevel, -dBaseLevel, 2 * dBaseLevel,
				2 * dBaseLevel);

		return bounds;
	}

	/**
	 * compute expanded bounds
	 * 
	 * @param t
	 * @param n
	 * @param b
	 */
	public void computeExpandedBounds(Object t, Object n, Object b) {
		ITreeDataEx tree = (ITreeDataEx) t;
		IVisualNode node = (IVisualNode) n;
		Rectangle2D bounds = (Rectangle2D) b;

		Arc2D fan = new Arc2D.Double();
		int level = FanLensUtil.getNodeLevel(t, n);

		if (level >= baseLevel && !tree.isLeaf(n)) {
			double radii = getRadii(level + 1);
			if (n.equals(expandFrom))
				radii = radii * animationFrac + getRadii(level)
						* (1 - animationFrac);
			else if (n.equals(collapseTo) || isCollapsing(tree, node)) {
				radii = getRadii(FanLensUtil.getNodeLevel(tree, collapseTo))
						* animationFrac + radii * (1 - animationFrac);
			}

			double start = node.getX();
			double width = node.getWidth();
			double zoomingFactor = getZoomingFactor(node);
			start -= (zoomingFactor - 1.0) * width / 2;
			width *= zoomingFactor;

			fan
					.setArcByCenter(0, 0, radii, 360 * start, 360 * width,
							Arc2D.PIE);
			Rectangle2D.union(bounds, fan.getBounds2D(), bounds);
		}

		Object[] children = tree.getChildren(n, null);
		if (null != children)
			for (int i = 0; i < children.length; i++)
				computeExpandedBounds(t, children[i], bounds);
	}

	/**
	 * update the center position (normalized)
	 * 
	 * @param b
	 * @param c
	 */
	public void updateCenter(Object b, Object c, double zoomFactor,
			double xOffset, double yOffset) {
		Rectangle2D bounds = (Rectangle2D) b;
		Point2D center = (Point2D) c;
		center.setLocation((-bounds.getX() + xOffset) / zoomFactor, (-bounds
				.getY() + yOffset)
				/ zoomFactor);
	}

	/**
	 * update the radii (normalized)
	 * 
	 * @param t
	 * @param n
	 * @param zoomFactor
	 */
	public void updateRadii(Object t, Object n, double zoomFactor) {
		ITreeDataEx tree = (ITreeDataEx) t;
		IVisualNode node = (IVisualNode) n;

		// root?
		if (n.equals(tree.getTreeRoot()) && 1.0 == animationFrac)
			radiiMap.clear();

		// set the radii
		int level = FanLensUtil.getNodeLevel(tree, node);
		node.setY((level == 0 ? 0 : getRadii(level - 1)) / zoomFactor);
		double radii = getRadii(level) / zoomFactor - node.getY();
		if (isExpanding(tree, node))
			radii *= animationFrac;
		else if (isCollapsing(tree, node)) {
			IVisualNode parent = (IVisualNode) tree.getParent(node);
			node.setY(parent.getY() + parent.getHeight());
			radii *= (1 - animationFrac);
		}
		node.setHeight(radii);

		// store the radii
		if (1.0 == animationFrac) {
			if (!radiiMap.containsKey(level))
				radiiMap.put(level, node.getY() + node.getHeight());
		}

		// browse to its children
		Object[] children = tree.getChildren(node, null);
		if (null != children)
			for (int i = 0; i < children.length; i++)
				updateRadii(tree, children[i], zoomFactor);
	}

	/**
	 * update the size of the square that contains the fanlens
	 * 
	 * @param panelWidth
	 * @param panelHeight
	 * @param b
	 * @return
	 */
	public double updateSquareSize(int panelWidth, int panelHeight, Object b) {
		Rectangle2D bounds = (Rectangle2D) b;
		double fPanel = panelWidth / (double) panelHeight;
		double fBounds = bounds.getWidth() / bounds.getHeight();

		double squareSize;
		if (fPanel > fBounds)
			squareSize = Math.max(panelHeight, panelHeight * fBounds);
		else
			squareSize = Math.max(panelWidth, panelWidth / fBounds);

		return squareSize;
	}

	/**
	 * if this node is expanding ?
	 * 
	 * @param t
	 * @param n
	 * @return
	 */
	public boolean isExpanding(Object t, Object n) {
		if (null == expandFrom)
			return false;

		ITreeDataEx tree = (ITreeDataEx) t;
		Object parent = tree.getParent(n);
		if (null == parent)
			return false;

		return parent.equals(expandFrom);
	}

	/**
	 * is collapsing node
	 * 
	 * @param t
	 * @param n
	 * @return
	 */
	public boolean isCollapsing(Object t, Object n) {
		if (null == collapseTo)
			return false;

		ITreeDataEx tree = (ITreeDataEx) t;
		Object parent = tree.getParent(n);
		while (parent != null && parent != tree.getTreeRoot()) {
			if (parent.equals(collapseTo))
				return true;

			parent = tree.getParent(parent);
		}

		return false;
	}

	/**
	 * set the animation fraction
	 * 
	 * @param frac
	 */
	public void setAnimationFrac(double frac) {
		this.animationFrac = frac;
	}

	/**
	 * is expandable ?
	 * 
	 * @param t
	 * @param n
	 * @return
	 */
	public boolean isExpandable(Object n) {
		return !fullTree.isLeaf(n);
	}

	/**
	 * get expandable mark
	 * 
	 * @return
	 */
	public Shape getExpandableMark() {
		return expandableMark;
	}

	/**
	 * get collapsing node
	 * 
	 * @return
	 */
	public Object getCollapseTo() {
		return collapseTo;
	}

	/**
	 * clear expandFrom node
	 * 
	 * @return
	 */
	public void clearExpandFrom() {
		expandFrom = null;
	}

	/**
	 * clear collapseTo node
	 * 
	 * @return
	 */
	public void clearCollapseTo() {
		collapseTo = null;
	}

	/**
	 * set zooming factor
	 * 
	 * @param n
	 * @param f
	 */
	public void setZoomingFactor(Object n, double f) {
		if (zoomingFactor.containsKey(n))
			zoomingFactor.remove(n);

		zoomingFactor.put(n, f);
	}

	/**
	 * get zooming factor
	 * 
	 * @param n
	 * @return
	 */
	public double getZoomingFactor(Object n) {
		Object value = zoomingFactor.get(n);

		return (value == null) ? 1.0 : Double.parseDouble(value.toString());
	}

	public int getLevelByDistance(double d) {
		double r0 = 0.0;
		for (int i = 0; i <= radiiMap.size(); i++) {
			Object obj = radiiMap.get(i);
			if (null == obj)
				return -1;

			double r = Double.parseDouble(obj.toString());
			if (d >= r0 && d < r)
				return i;

			r0 = r;
		}

		return -1;
	}

	public void reset() {
		zoomingFactor.clear();
	}
}