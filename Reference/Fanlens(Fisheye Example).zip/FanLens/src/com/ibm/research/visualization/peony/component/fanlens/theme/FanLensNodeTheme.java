package com.ibm.research.visualization.peony.component.fanlens.theme;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Stroke;
import java.util.HashMap;
import java.util.Map;

import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.DefaultNodeTheme;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.util.ColorUtil;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.sdl.data.api.ITreeDataEx;

public class FanLensNodeTheme extends DefaultNodeTheme {

	public static final String PROP_COLOR = "#PROP_COLOR#";

	public static final float DEFAULT_HUE = 0.5f;

	public static final float DEFAULT_SATURATION = 0.5f;

	public static final Color[] DEFAULT_COLOR = { new Color(233, 206, 223),
			new Color(251, 201, 200), new Color(181, 238, 255),
			new Color(202, 232, 168), new Color(185, 182, 203),
			new Color(192, 205, 222), new Color(255, 229, 82) };

	public static final Color borderColor = Color.gray;

	public static final Color borderColorHighlight = Color.blue;

	public static final Stroke borderStroke = new BasicStroke(1.0f);

	public static final Stroke borderStrokeHighlight = new BasicStroke(3.0f);

	public static final int COLOR_BY_INDEX = 0;

	public static final int COLOR_BY_VALUE = 1;

	protected Map colorMap = new HashMap(0);

	public FanLensNodeTheme() {
		super();
	}

	public void updateColorMap(Object t, Object d, int colorBy) {
		FanLensData data = (FanLensData) d;
		ITreeDataEx fullTree = (ITreeDataEx) data.getFullTree();

		colorMap.clear();
		switch (colorBy) {
		case COLOR_BY_INDEX:
			for (int i = 0; i < DEFAULT_COLOR.length; i++)
				colorMap.put(i, DEFAULT_COLOR[i]);
			break;
		case COLOR_BY_VALUE:

			// update properties
			FanLensUtil.averageProperty(fullTree, fullTree.getTreeRoot(), data
					.getColorKey());

			Object[] objs = fullTree.getNodes(null, null);
			double maxValue = Double.MIN_VALUE;
			double minValue = Double.MAX_VALUE;
			for (int i = 0; i < objs.length; i++) {
				IVisualNode node = (IVisualNode) objs[i];
				double value = FanLensUtil.parseDoubleFromProperty(node,
						(String) data.getColorKey(), 1.0);
				maxValue = Math.max(value, maxValue);
				minValue = Math.min(value, minValue);
			}

			for (int i = 0; i < objs.length; i++) {
				IVisualNode node = (IVisualNode) objs[i];
				double value = FanLensUtil.parseDoubleFromProperty(node, data
						.getColorKey(), 1.0);
				if (!colorMap.containsKey(value)) {
					float b = 1.0f - 0.75f * (float) ((value - minValue) / (maxValue - minValue));
					Color color = ColorUtil.getHSBColor(DEFAULT_HUE,
							DEFAULT_SATURATION, b);
					colorMap.put(value, color);
				}
			}

			break;
		default:
			break;
		}

		// update the color
		updateColor(fullTree, fullTree.getTreeRoot(), data, colorBy);
	}

	public void updateColor(Object t, Object n, Object d, int colorBy) {
		ITreeDataEx tree = (ITreeDataEx) t;
		IVisualNode node = (IVisualNode) n;
		FanLensData data = (FanLensData) d;

		Object[] children = tree.getChildren(node, null);
		if (null != children)
			switch (colorBy) {
			case COLOR_BY_INDEX:
				if (n.equals(tree.getTreeRoot()))
					((IVisualNode) tree.getTreeRoot()).addProperty(PROP_COLOR,
							DEFAULT_COLOR.length - 1);

				for (int i = 0; i < children.length; i++) {
					((IVisualNode) children[i]).addProperty(PROP_COLOR, i
							% DEFAULT_COLOR.length);
					updateColor(tree, children[i], d, colorBy);
				}
				break;
			case COLOR_BY_VALUE:
				if (n.equals(tree.getTreeRoot())) {
					double value = FanLensUtil.parseDoubleFromProperty(node,
							data.getColorKey(), 1.0);
					((IVisualNode) tree.getTreeRoot()).addProperty(PROP_COLOR,
							value);
				}

				for (int i = 0; i < children.length; i++) {
					double value = FanLensUtil.parseDoubleFromProperty(
							children[i], (String) data.getColorKey(), 1.0);
					((IVisualNode) children[i]).addProperty(PROP_COLOR, value);
					updateColor(tree, children[i], d, colorBy);
				}
				break;
			}
	}

	@Override
	public Color getFillColor(Object e, boolean highlight) {
		IVisualNode node = (IVisualNode) e;
		Color fillColor = (Color) colorMap.get(node.getProperty(PROP_COLOR));

		return highlight ? fillColor.brighter() : fillColor;
	}

	public Stroke getBorderStroke(boolean highlight) {
		return highlight ? borderStrokeHighlight : borderStroke;
	}

	public Color getBorderColor(boolean highlight) {
		return highlight ? borderColorHighlight : borderColor;
	}
}
