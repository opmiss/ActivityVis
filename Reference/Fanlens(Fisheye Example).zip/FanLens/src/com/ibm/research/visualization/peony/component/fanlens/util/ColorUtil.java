package com.ibm.research.visualization.peony.component.fanlens.util;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;

public class ColorUtil extends JFrame {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4767848983047584791L;
	
	public static final Color getHSBColor(float h, float s, float b) {
		return getHSBColor(h, s, b, 1.0f);
	}
	
	public static final Color getHSBColor(float h, float s, float b, float alpha) {
		Color temp = new Color(Color.HSBtoRGB(h, s, b));
		return new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), (int)(alpha * 255));
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		
//		for (int i=0; i<8; i++) {
//			float h = 1.0f;
//			for (int j=0; j<8; j++) {
//				float s = j / 7.0f;
//				for (int k=0; k<8; k++) {
//					float b = k / 7.0f;
//					g.setColor(new Color(Color.HSBtoRGB(h, s, b)));
//					g.fillRect((i*8*8+j*8+k)*2, 0, 2, 100);
//				}
//			}
//		}
//		
		// variation in hue
		for (int i=0; i<1200; i++) {
			float h = i / 1199.0f;
			float s = 0.9f;
			float b = 0.9f;
			g.setColor(getHSBColor(h, s, b));
			g.fillRect(i, 100, 1, 100);
		}
		
		// variation in santuration
		for (int i=0; i<1200; i++) {
			float h = 0.0f;
			float s = i / 1199.0f;
			float b = 0.5f;
			g.setColor(getHSBColor(h, s, b));
			g.fillRect(i, 200, 1, 100);
		}
		
		// variation in brightness
		for (int i=0; i<1200; i++) {
			float h = 0.5f;
			float s = 1.0f;
			float b = i / 1199.0f;
			g.setColor(getHSBColor(h, s, b));
			g.fillRect(i, 300, 1, 100);
		}
		
		// variation in hue & santuration
//		float b = 0.8f;
//		for (int i=0; i<50; i++) {
//			float h = i / 49.0f;
//			for (int j=0; j<50; j++) {
//				float s = j / 49.0f;
//				g.setColor(new Color(Color.HSBtoRGB(h, s, b)));
//				g.fillRect(i*20, j*20, 20, 20	);
//			}
//		}
		
		// variation in santuration & brightness
//		float h = 0.25f;
//		for (int i=0; i<50; i++) {
//			float s = i / 49.0f;
//			for (int j=0; j<50; j++) {
//				float b = j / 49.0f;
//				g.setColor(new Color(Color.HSBtoRGB(h, s, b)));
//				g.fillRect(i*20, j*20, 20, 20	);
//			}
//		}		
	}
	
	public static void main(String[] arg) {
		ColorUtil t = new ColorUtil();
		t.setVisible(true);
		t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		t.setExtendedState(JFrame.MAXIMIZED_BOTH);
		t.setTitle("Color Demo");
	}
}
