package com.ibm.research.visualization.peony.component.fanlens.render;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import com.ibm.peony.display.BaseLayer;
import com.ibm.peony.display.ILayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.layer.AbstractLayerRender;

public class TooltipRender extends AbstractLayerRender {

	private IVisualElement elem = null;

	private Point mousePos = null;

	private Shape rawShape = null;

	private ArrayList tooltip = null;

	private ILayer layer = null;

	public TooltipRender(ILayer layer) {
		rawShape = new Rectangle2D.Double();
		this.layer = layer;
		tooltip = new ArrayList(0);
		tooltip.add("tooltip ...");
	}

	public void setElement(IVisualElement elem) {
		this.elem = elem;
	}

	public void setMousePosition(Point point) {
		if (null == mousePos)
			mousePos = new Point();

		mousePos.setLocation(point);
	}

	public void setTooltip(ArrayList tooltip) {
		this.tooltip = tooltip;
	}

	public Shape estimateRawShape() {
		if (!(elem instanceof IVisualNode))
			return null;

		Graphics2D g = (Graphics2D) layer.getOwner().getGraphics();
		g.setFont(tooltipFont);
		FontMetrics fm = g.getFontMetrics();

		double width = 0;
		double fontHeight = g.getFont().getSize();
		double height = fontHeight * tooltip.size();

		for (int i = 0; i < tooltip.size(); i++) {
			String tp = tooltip.get(i).toString();

			double sw = fm.stringWidth(tp);
			width = Math.max(width, sw);
		}

		((Rectangle2D.Double) rawShape).setFrame(mousePos.x - 4,
				mousePos.y - 4, width + 4, height + 4);
		return rawShape;
	}

	public Shape getRawShape() {
		return rawShape;
	}

	private Font tooltipFont = new Font("Arial", Font.PLAIN, 16);

	private Color fillColor = new Color(166, 247, 251, 225);

	private Color borderColor = new Color(60, 169, 146, 225);

	private Color textColor = Color.black;

	public void render(Graphics2D g, BaseLayer layer) {

		if (!(elem instanceof IVisualNode))
			return;
		
		estimateRawShape();

		Font f = g.getFont();
		g.setFont(tooltipFont);
		double fontHeight = tooltipFont.getSize();

		Rectangle2D.Double rect = (Rectangle2D.Double) rawShape;
		g.setColor(fillColor);
		g.fillRect((int) rect.x, (int) rect.y, (int) rect.width,
				(int) rect.height);
		g.setColor(borderColor);
		g.drawRect((int) rect.x, (int) rect.y, (int) rect.width - 1,
				(int) rect.height - 1);

		int x = (int) rect.x;
		g.setColor(textColor);
		for (int i = 0; i < tooltip.size(); i++) {
			String tp = tooltip.get(i).toString();
			int y = (int) (rect.y + fontHeight * (i + 1));
			g.drawString(tp, x, y);
		}

		g.setFont(f);
	}
}
