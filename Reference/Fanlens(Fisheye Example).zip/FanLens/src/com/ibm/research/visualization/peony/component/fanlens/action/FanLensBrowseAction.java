package com.ibm.research.visualization.peony.component.fanlens.action;

import java.awt.event.MouseEvent;

import com.ibm.peony.action.ActionAdapter;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.peony.state.IActionRecorder;
import com.ibm.research.visualization.peony.component.fanlens.FanLensData;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayer;
import com.ibm.research.visualization.peony.component.fanlens.FanLensLayout;
import com.ibm.research.visualization.peony.component.fanlens.util.FanLensUtil;
import com.ibm.research.visualization.peony.component.fanlens.util.InspectParam;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.InvalidateTypeException;

public class FanLensBrowseAction extends ActionAdapter {

	public static final int INSPECT_ACTION = 0x0000;
	
	private InspectParam m_param = null;
	
	protected FanLensBrowseAnimator expandingAnimation = new FanLensBrowseAnimator(
			800, 10);

	public FanLensBrowseAction() {
		this(MouseEvent.BUTTON1_DOWN_MASK);
	}
	
	public FanLensBrowseAction(int mask) {
		super.m_bGeneralAction = false;
		super.m_mask = mask;
	}


	/**
	 * handle the element click event
	 * 
	 * @param element
	 * @param e
	 */
	public void elemPressed(Object element, MouseEvent e) {
		if (e.getModifiersEx() == m_mask) {
			// local variables
			VisualLayer vislayer = (VisualLayer) this.getOwner();
			FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
			FanLensData fanlensData = (FanLensData) layout.getFanLensData();

			// change the partial tree
			boolean needUpdate = false;
			InspectParam param = new InspectParam(vislayer.getData(), element);
			m_param = param;
			try {
				// update partial tree
				needUpdate = fanlensData.updatePartialTree(vislayer.getData(),
						element);
				
			} catch (InvalidateTypeException exception) {
				exception.printStackTrace();
			}

			VisualNode node = (VisualNode)element;
			if (needUpdate) {
				((FanLensLayer)vislayer).clearPickQueue();
				// update picking queue
				LayerUtil.updatePickQueue(vislayer);
				
				IActionRecorder recorder = m_owner.getActionRecroder();
//				recorder.record(INSPECT_ACTION, e.getModifiersEx(), param);

				// // run animation
				LayerUtil.runAnimation(vislayer, expandingAnimation);
			}
		}
		super.elemPressed(element, e);
	}
	
	// overwrite following methods
	public void execute(int type, int event, Object param) {
		if( type != INSPECT_ACTION)
			return;
		
		// local variables
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
		FanLensData fanlensData = (FanLensData) layout.getFanLensData();

		// change the partial tree
		boolean needUpdate = false;
		try {
			// update partial tree
			needUpdate = fanlensData.updatePartialTreeByState(vislayer.getData(),
					param);
			
		} catch (InvalidateTypeException exception) {
			exception.printStackTrace();
		}
		
		if (needUpdate) {
			((FanLensLayer)vislayer).clearPickQueue();
			// update picking queue
			LayerUtil.updatePickQueue(vislayer);
			
			try {
				if (null != fanlensData.getCollapseTo())
					FanLensUtil.removeChildren(vislayer.getData(), fanlensData.getCollapseTo());
			} catch (InvalidateTypeException e) {
				e.printStackTrace();
			}

			fanlensData.clearCollapseTo();
			fanlensData.clearExpandFrom();

		}
	}

	public void unexecute(int type, int event, Object param) {
		if( type != INSPECT_ACTION)
			return;
		
		// local variables
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		FanLensLayout layout = (FanLensLayout) vislayer.getLayout();
		FanLensData fanlensData = (FanLensData) layout.getFanLensData();

		// change the partial tree
		boolean needUpdate = false;
		try {
			// update partial tree
			needUpdate = fanlensData.updatePartialTreeByState(vislayer.getData(),
					param);
			
		} catch (InvalidateTypeException exception) {
			exception.printStackTrace();
		}
		
		if (needUpdate) {
			((FanLensLayer)vislayer).clearPickQueue();
			// update picking queue
			LayerUtil.updatePickQueue(vislayer);
			
			try {
				if (null != fanlensData.getCollapseTo())
					FanLensUtil.removeChildren(vislayer.getData(), fanlensData.getCollapseTo());
			} catch (InvalidateTypeException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			fanlensData.clearCollapseTo();
			fanlensData.clearExpandFrom();
		}
	}

	public int getType() {
		return INSPECT_ACTION;
	}
	
	public InspectParam getParam(){
		return m_param;
	}
}
