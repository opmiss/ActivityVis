package com.ibm.research.visualization.peony.component.fanlens.action;

import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import com.ibm.peony.action.ActionAdapter;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.research.visualization.peony.component.fanlens.util.LayerUtil;
import com.ibm.sdl.data.api.ITreeDataEx;

public class HighlightToRootAction extends ActionAdapter {
	protected List highlightPath = new ArrayList(0);

	@Override
	public void elemEntered(Object element, MouseEvent e) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		ITreeDataEx tree = (ITreeDataEx) ((VisualLayer) this.getOwner())
				.getData();
		IVisualNode parent = (IVisualNode) element;
		do {
			parent.setHighlight(true);
			highlightPath.add(parent);
			vislayer.update(parent);

			parent = (IVisualNode) tree.getParent(parent);
		} while (parent != null);

		LayerUtil.runUpdate(vislayer);

		super.elemEntered(element, e);
	}

	@Override
	public void elemExited(Object element, MouseEvent e) {
		VisualLayer vislayer = (VisualLayer) this.getOwner();
		// clear previous highlight
		for (int i = 0; i < highlightPath.size(); i++) {
			IVisualNode node = (IVisualNode) highlightPath.get(i);
			node.setHighlight(false);
			vislayer.update(node);
		}

		super.elemExited(element, e);
	}
}
