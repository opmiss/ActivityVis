package com.ibm.research.visualization.peony.component.fanlens.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.StringTokenizer;

import com.ibm.peony.geometry.VisualEdge;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.IType;

public class FanTableReader {
	
	private EntityTree mvTree; 
	private String[] mvNames;
	private int[] mvOrders;
	
	private boolean mvHasOrder = false;
	
	public FanTableReader(){
		mvHasOrder = false;
	}
	
	public FanTableReader(boolean hasOrder){
		mvHasOrder = hasOrder;
	}
	
	protected String[] parseLine(String line) {
		StringTokenizer tok = new StringTokenizer(line, ",");
		ArrayList list = new ArrayList();
		while (tok.hasMoreTokens())
			list.add(tok.nextToken());

		return (String[])list.toArray(new String[list.size()]);
	}
	
	private boolean setOrder(Object[] order){
		mvOrders = new int[order.length];
		for (int i=0;i<mvOrders.length;i++){
			mvOrders[i]=i;
		}
		
		if (!mvHasOrder){
			return false;
		}
		
		int[] tmpOrder = new int[order.length];
		
		for (int i=0;i<order.length;i++){
			try{
				tmpOrder[i]= Integer.parseInt((String)order[i]);
			}catch(Exception exp){
				return false;
			}
		}
		
		int index = 0;
		
		for (int i=0;i<tmpOrder.length;i++){
			int k = -1;
			int min = Integer.MAX_VALUE;
			for (int j=0;j<tmpOrder.length;j++){
				if (tmpOrder[j] < min){
					min = tmpOrder[j];
					k = j;
				}
			}			
			mvOrders[index++]=k;
			tmpOrder[k]= Integer.MAX_VALUE;
		}
		
		return true;
	}
	
	private void addToTree(String[] line) throws InvalidateTypeException,InvalidateDataException{		
		VisualNode parent = (VisualNode)mvTree.getTreeRoot();
		for (int i=0;i<mvOrders.length;i++){
			int index = mvOrders[i];
			String name = line[index];
			String type = mvNames[index];
			parent = getNode(parent,name,type);
		}		
	}
	
	private VisualNode getNode(VisualNode parent,String name,String type)throws InvalidateTypeException, InvalidateDataException{
		for (int i=0;i<mvTree.getChildCount(parent);i++){
			VisualNode node = (VisualNode)mvTree.getChild(parent, i);
			if (node.getProperty(IName.PROP_NAME).equals(name)){
				return node;
			}
		}
		VisualNode n = new VisualNode();
		n.addProperty(IName.PROP_NAME, name);
		n.addProperty(IType.PROP_TYPE, type);
		
		mvTree.addChild(parent, n);
		return n;
	}

	
	public boolean read(InputStream instream) {
		FileInputStream fis = (FileInputStream) instream;
		if (null == fis)
			return false;
		BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
		
		mvTree = new EntityTree();
		mvTree.setEdgeType(VisualEdge.class);
		VisualNode root = new VisualNode();
		root.addProperty(IName.PROP_NAME, "root");
		root.addProperty(IType.PROP_TYPE, "root");
		try{
			mvTree.addNode(root);
		}catch(Exception exp){
			exp.printStackTrace();
			return false;
		}
		mvTree.setTreeRoot(root);
		
		
		String line = null;
		try {
			// get orders
			line = reader.readLine();
			if (null == line)
				return false;
			Object[] orders = parseLine(line);
			if (!setOrder(orders)){
				mvNames = (String[])orders;
			}else{
				// get names
				line = reader.readLine();
				if (null == line)
					return false;
				
				Object[] names = parseLine(line);
				mvNames = (String[])names;
			}
			
			
			// repeatedly read values
			do {
				line = reader.readLine();
				if (null == line)
					continue;
				// add data
				String[] parts = parseLine(line);
				if (parts.length < orders.length) {
					System.out.println("Invalid data at: " + line);
					return false;
				}
				addToTree(parts);
				
			} while (null != line);
		}catch (IOException e) {
			e.printStackTrace();
			return false;
		}catch(Exception ex){
			ex.printStackTrace();
			return false;
		}
		return true;
	}
	
	public EntityTree getData(){
		return mvTree;
	}
	
	public static void main(String[] args) {
		FanTableReader reader = new FanTableReader();
		try{
			reader.read(new FileInputStream("data/FanLens_Sample_NBA.csv"));
		}catch(Exception exp){
			exp.printStackTrace();
		}
	}
}
