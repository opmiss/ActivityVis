package com.ibm.research.visualization.peony.component.fanlens.action;

import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import com.ibm.peony.action.ActionAdapter;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.IRender;
import com.ibm.research.visualization.peony.component.fanlens.render.TooltipRender;
import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.IWeight;

public class ShowTooltipAction extends ActionAdapter {

	private TooltipRender render = null;
	
	private ArrayList keyList = null;
	private ArrayList nameList = null;
	private ArrayList tooltip = null;

	public ShowTooltipAction() {
		keyList = new ArrayList(0);
		keyList.add(IName.PROP_NAME);
		
		nameList = new ArrayList(0);
		nameList.add("Name");

		tooltip = new ArrayList(0);
		tooltip.add("tooltip ...");
	}
	
	public void addContent(String key, String name) {
		keyList.add(key);
		nameList.add(name);
	}

	public void elemEntered(Object element, MouseEvent e) {
		if (element instanceof IVisualNode) {
			if (null == render)
				render = new TooltipRender(this.getOwner());
			getOwner().addInteractionRender(render);
			
			tooltip.clear();
			for (int i=0; i<keyList.size(); i++) {				
				Object key = keyList.get(i);
				String value = "N/A";
				if (key.toString() == IWeight.PROP_WEIGHT) {
					 value = "" + (int)((IVisualNode)element).getWeight();
				}
				else {
					Object obj = ((IVisualNode)element).getProperty(key);
					if (null != obj)
						value = obj.toString();
				}
	
				String name = nameList.get(i).toString();
				tooltip.add(name + " : " + value);
			}
			
			render.setTooltip(tooltip);
			render.setEnable(true);
			render.setElement((IVisualElement) element);
			render.setMousePosition(e.getPoint());

			Rectangle2D rect = (Rectangle2D) render.estimateRawShape();

			VisualLayer vislayer = (VisualLayer) this.getOwner();
			IVisualNode node = (IVisualNode) element;
			IRender nodeRender = vislayer
					.getRender(node);
			Rectangle2D.union(nodeRender.getRawShape(node).getBounds2D(), rect,
					rect);

			m_owner.update(rect);
			m_owner.getOwner().repaint();
		}

		super.elemEntered(element, e);
	}

	public void elemExited(Object element, MouseEvent e) {
		if (element instanceof IVisualNode) {
			getOwner().removeInteractionRender(render);
			render.setEnable(false);

			Rectangle2D rect = (Rectangle2D) render.getRawShape();

			m_owner.update(rect);
			m_owner.getOwner().repaint();
		}

		super.elemEntered(element, e);
	}
}