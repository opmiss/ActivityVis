/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens.util;

import java.awt.Graphics2D;
import java.util.List;

import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.geometry.VisualEdge;
import com.ibm.sdl.data.InvalidateTypeException;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.data.tree.impl.EntityTree;

public class FanLensUtil {
	/**
	 * parse weight value from property
	 * 
	 * @param n
	 * @param key
	 * @return
	 */
	public static double parseDoubleFromProperty(Object n, String key,
			double defaultValue) {
		IVisualNode node = (IVisualNode) n;
		double value = 0.0;
		try {
			value = Double.parseDouble(node.getProperty(key).toString());
		} catch (Exception e) {
			value = defaultValue;
		}

		return value;
	}

	/**
	 * get the value within range [minValue, maxValue]
	 * 
	 * @param n
	 * @param key
	 * @param defaultValue
	 * @param minValue
	 * @param maxValue
	 * @return
	 */
	public static double parseDoubleFromProperty(Object n, String key,
			double defaultValue, double minValue, double maxValue) {
		double value = parseDoubleFromProperty(n, key, defaultValue);
		value = Math.min(maxValue, value);
		value = Math.max(minValue, value);

		return value;
	}

	/**
	 * clone the entire tree
	 * 
	 * @param src
	 * @return
	 * @throws InvalidateTypeException
	 */
	public static Object cloneTree(Object src) throws InvalidateTypeException {
		ITreeDataEx dest = new EntityTree();
		((EntityTree) dest).setEdgeType(VisualEdge.class);

		IVisualNode root = (IVisualNode) ((ITreeDataEx) src).getTreeRoot();
		dest.setTreeRoot(root);

		copyTree(src, dest, root, root);

		return dest;
	}

	/**
	 * copy branch from tree 'src' to a tree 'dest'
	 * 
	 * @param src
	 * @param dest
	 * @param fromNode
	 * @param toNode
	 * @throws InvalidateTypeException
	 */
	public static void copyTree(Object src, Object dest, Object fromNode,
			Object toNode) throws InvalidateTypeException {
		ITreeDataEx srcTree = (ITreeDataEx) src;
		ITreeDataEx destTree = (ITreeDataEx) dest;

		Object[] children = srcTree.getChildren(fromNode, null);
		if (null != children)
			for (int i = 0; i < children.length; i++) {
				destTree.addChild(toNode, children[i]);
				if (!srcTree.isLeaf(children[i]))
					copyTree(src, dest, children[i], children[i]);
			}
	}

	/**
	 * print tree from the root
	 * 
	 * @param t
	 */
	public static void printTree(Object t) {
		ITreeDataEx tree = (ITreeDataEx) t;
		printTree(tree, tree.getTreeRoot(), 0);
	}

	/**
	 * print out the tree in text format
	 * 
	 * @param t
	 * @param n
	 * @param level
	 */
	public static void printTree(Object t, Object n, int level) {
		if (null == n)
			return;
		ITreeDataEx tree = (ITreeDataEx) t;
		for (int i = 0; i < level; i++)
			System.out.print(".");
		System.out.println(n);

		for (int i = 0; i < tree.getChildCount(n); i++)
			printTree(t, tree.getChild(n, i), level + 1);
	}

	/**
	 * remove the children of node n
	 * 
	 * @param t
	 * @param n
	 */
	public static void removeChildren(Object t, Object n)
			throws InvalidateTypeException {
		ITreeDataEx tree = (ITreeDataEx) t;
		if (null == n)
			return;

		Object[] children = tree.getChildren(n, null);
		if (null != children)
			for (int i = 0; i < children.length; i++)
				removeBranch(tree, children[i]);
	}

	/**
	 * remove branch
	 * 
	 * @param t
	 * @param n
	 * @throws InvalidateTypeException
	 */
	public static void removeBranch(Object t, Object n)
			throws InvalidateTypeException {
		ITreeDataEx tree = (ITreeDataEx) t;
		if (null == n)
			return;

		Object[] children = tree.getChildren(n, null);
		if (null != children)
			for (int i = 0; i < children.length; i++)
				removeBranch(tree, children[i]);

		tree.removeNode(n);
	}

	/**
	 * draw rotated string
	 * 
	 * @param g2d
	 * @param x
	 * @param y
	 * @param angle
	 * @param label
	 */
	public static void drawRotatedString(Graphics2D g2d, int x, int y,
			double angle, String label) {
		g2d.translate(x, y);
		g2d.rotate(angle);
		g2d.drawString(label, 0, 0);
		g2d.rotate(-angle);
		g2d.translate(-x, -y);
	}

	/**
	 * compute normalized angle (0 -- 1.0)
	 * 
	 * @param cx
	 * @param cy
	 * @param px
	 * @param py
	 * @return
	 */
	public static double computeNormalizedAngle(double cx, double cy,
			double px, double py) {
		double a = px - cx;
		double b = py - cy;
		double angle = -(((a == 0) ? Math.PI / 2 : Math.atan(b / a)) / Math.PI / 2);
		if (a < 0)
			angle = 0.5 + angle;
		else if (b > 0)
			angle = 1.0 + angle;

		return angle;
	}

	/**
	 * get the level of the node
	 * 
	 * @param t
	 * @param n
	 * @return
	 */
	public static int getNodeLevel(Object t, Object n) {
		ITreeDataEx tree = (ITreeDataEx) t;

		int level = 0;
		Object parent = n;

		while (!tree.getTreeRoot().equals(parent)) {
			parent = tree.getParent(parent);
			level++;
		}

		return level;
	}

	public static void getAllNodesAtLevel(Object t, Object n, int targetLevel,
			int curLevel, Object l) {
		ITreeDataEx tree = (ITreeDataEx) t;
		IVisualNode node = (IVisualNode) n;
		List list = (List) l;

		if (targetLevel == curLevel)
			list.add(node);
		else if (targetLevel > curLevel) {
			Object[] children = tree.getChildren(node, null);
			if (null != children)
				for (int i = 0; i < children.length; i++)
					getAllNodesAtLevel(tree, children[i], targetLevel,
							curLevel + 1, list);
		}
	}

	public static void averageProperty(Object t, Object n, String key) {
		ITreeDataEx tree = (ITreeDataEx) t;
		IVisualNode node = (IVisualNode) n;

		double totalValue = 0.0;
		Object[] children = tree.getChildren(node, null);
		if (null != children)
			for (int i = 0; i < children.length; i++) {
				IVisualNode child = (IVisualNode) children[i];
				if (!tree.isLeaf(child))
					averageProperty(tree, child, key);

				double value = FanLensUtil.parseDoubleFromProperty(child, key,
						1.0);

				totalValue += value;
			}

		node.addProperty(key, totalValue / children.length);
	}

	public static double[] fisheyeTransformation(double x[], double max,
			double min, double d, double p) {
		int length = x.length;

		double mid = (max + min) / 2;
		double range = max - min;

		// run the transformation
		double[] f = new double[x.length];
		for (int i = 0; i < length; i++) {
			double v = (x[i] - mid) / (range / 2);
			if (v < 1.0 && v > -1.0)
				f[i] = fisheye(v, d, p);
			else
				f[i] = v;
			f[i] = f[i] * range / 2 + mid;

		}

		return f;
	}

	public static double fisheye(double v, double d, double p) {
		double r;
		if (v <= 0)
			r = (p + d) * v / (p - d * v);
		else
			r = (p + d) * v / (p + d * v);

		return r;
	}

	public static void main(String[] args) {
		double[] x = new double[1000];
		for (int i = 0; i < 1000; i++)
			x[i] = i / 500.0 - 1.0;
		double[] f = fisheyeTransformation(x, 1.0, -1.0, 4.0, 1.0);
		for (int i = 0; i < 1000; i++) {
			System.out.println(x[i] + ", " + f[i]);
		}
	}
}
