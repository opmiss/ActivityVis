/**
 * FanLens, a radial space-filling visualization technology
 * @author Xinghua Lou (louxh@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.research.visualization.peony.component.fanlens;

import java.util.List;

import com.ibm.peony.display.Display;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.state.IViewState;
import com.ibm.research.visualization.peony.component.fanlens.action.FanLensBrowseAction;
import com.ibm.research.visualization.peony.component.fanlens.action.FanLensDistortionAction;
import com.ibm.research.visualization.peony.component.fanlens.action.FanLensZoomAction;
import com.ibm.research.visualization.peony.component.fanlens.action.HighlightToRootAction;
import com.ibm.research.visualization.peony.component.fanlens.action.PopupMenuAction;
import com.ibm.research.visualization.peony.component.fanlens.action.ShowTooltipAction;
import com.ibm.research.visualization.peony.component.fanlens.render.FanLensNodeRender;
import com.ibm.research.visualization.peony.component.fanlens.theme.FanLensNodeTheme;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.api.ITreeDataEx;
import com.ibm.sdl.util.prop.IWeight;

public class FanLensDisplay extends Display {

	private static final long serialVersionUID = -1438762186710771367L;

	private VisualLayer m_layer = null;

	public FanLensDisplay() {
		super();
		m_layer = new FanLensLayer(this);
		m_layer.registerLayout(new FanLensLayout());
		m_layer.registerNodeRender(new FanLensNodeRender());
		m_layer.registerNodeTheme(new FanLensNodeTheme());
		m_layer.addAction(new HighlightToRootAction());
		m_layer.addAction(new FanLensZoomAction());
		m_layer.addAction(new FanLensDistortionAction());
		m_layer.addAction(new FanLensBrowseAction());
		m_layer.addAction(new PopupMenuAction());
		ShowTooltipAction stAction = new ShowTooltipAction();
		m_layer.addAction(stAction);

		m_layer.setFocus(true);
		m_layer.setVisible(true);
		m_layer.setLayerRender(new FanlenslayerRender());

		this.setLayer(m_layer);
		this.setName("FanLens Display");
	}

	public void setData(Object data) throws InvalidateDataException {
		m_layer.setData(data);
		if (data instanceof ITreeDataEx){
			ITreeDataEx tree = (ITreeDataEx)data;
			FanLensLayout layout = ((FanLensLayout)m_layer.getLayout());
			FanLensData dd = (FanLensData)layout.getFanLensData();
			try{
				dd.setFullTree(tree);
				List keys = (List) dd.getKeyCollection();
				for (int i = 0; i < keys.size(); i++) {
					String name = keys.get(i).toString();
					if (name.equals(IWeight.PROP_WEIGHT)){
						dd.setAngleKey(name);
						break;
					}
				}
			}catch(Exception exp){
				exp.printStackTrace();
			}
		}
	}

	public Object getFanLensData() {
		return ((FanLensLayout) m_layer.getLayout()).getFanLensData();
	}
	
//	public void setState(IViewState state) throws InvalidateDataException {
//		if(m_layer != null) {
//			m_layer.setState(state);
//		}
//	}
	
//	public Object getState() {
//		return m_layer.getState();
//	} 
	
}
