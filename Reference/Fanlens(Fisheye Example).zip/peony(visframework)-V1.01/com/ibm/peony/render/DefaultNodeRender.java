/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;

import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.profile.DefaultNodeProfile;
import com.ibm.peony.render.profile.IRenderProfile;
import com.ibm.peony.util.math.Translation;
import com.ibm.sdl.util.PropOperator;

public class DefaultNodeRender extends DefaultRender {
	
	private Ellipse2D m_ellipse = null;
	
	public DefaultNodeRender() {
		m_profile = new DefaultNodeProfile();
		m_ellipse = new Ellipse2D.Double();
	}
	
	public DefaultNodeRender(IRenderProfile f) {
		m_profile = f;
	}
	
	public void setProfileType(int type) {
		
	}

	public void render(Graphics2D g, IVisualElement element, ITheme theme, boolean highlight) {
		
		if (isVisible((IVisualNode) element)) {

			INodeTheme nt = (INodeTheme) theme;
			
			m_layer.getOwner().getCamera();
			
			IVisualNode node = (IVisualNode)element;
			double cx = node.getX();
			double cy = node.getY();
			
			m_ellipse.setFrameFromCenter(cx, cy, cx - 5, cy - 5);
			
//			Shape shape = getRawShape(element);
//			if(null == shape) {
//				return;
//			}

//			shape = m_layer.transform(shape);
			Color color = nt.getFillColor(element, highlight);
			g.setColor(color);
			g.fill(m_ellipse);
			g.setColor(nt.getOutlineColor(element, highlight));
			g.draw(m_ellipse);
			
//			String name = PropOperator.getInstance().getName(element);
//			
//			if(null != name && !"".equals(name)) {			
//				Rectangle r = m_ellipse.getBounds();
//				
//				int x = (int)r.getCenterX();
//				int y = (int)r.getCenterY();
//				
//				g.setFont(nt.getLabelFont(element, highlight));
//				FontMetrics fm = g.getFontMetrics();
//				int sh = Translation.atoi(y + (fm.getLeading() + fm.getAscent()) / 2.0);
//				int sw = Translation.atoi(x - fm.stringWidth(name) / 2.0);
//				
//				g.setColor(nt.getLabelColor(element, highlight));
//				g.drawString(name, sw, sh);
//			}
		}
	}

	private boolean isVisible(IVisualNode node) {
		return true;
	}

	public boolean locatePoint(double x, double y, IVisualElement e) {
		if (isVisible((IVisualNode) e)) {
			Shape s = getRawShape(e);
			if(s == null) {
				return false;
			}
			s = m_layer.transform(s);
			return null == s ? false : s.contains(x, y);
		}
		return false;
	}
}
