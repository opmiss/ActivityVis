/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Ellipse2D;

import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;

public class DefaultLayerHandleRenderer extends DefaultRender {

	private Shape m_rawShape = null;
	
	public DefaultLayerHandleRenderer() {
		m_rawShape = new Ellipse2D.Double();
	}

	public Shape getRawShape(IVisualElement e) {
		
		IVisualNode n = (IVisualNode)e;
		double w = n.getWidth();
		double h = n.getHeight();
		double x = n.getX() - w / 2.0;
		double y = n.getY() - h / 2.0;
		
		((Ellipse2D.Double)m_rawShape).x = x;
		((Ellipse2D.Double)m_rawShape).y = y;
		((Ellipse2D.Double)m_rawShape).width = w;
		((Ellipse2D.Double)m_rawShape).height= h;
		
		return m_rawShape;
	}

	public void render(Graphics2D g, IVisualElement e, ITheme theme, boolean highlight) {
		INodeTheme t = (INodeTheme)theme;
		
		Shape sp = getRawShape(e);
		g.setColor(t.getFillColor(e, highlight));
		g.fill(sp);
		g.setColor(t.getOutlineColor(e, highlight));
		Stroke s = g.getStroke();
		g.setStroke(t.getOutlineThinck(e, highlight));
		g.draw(sp);
		g.setStroke(s);
	}
}