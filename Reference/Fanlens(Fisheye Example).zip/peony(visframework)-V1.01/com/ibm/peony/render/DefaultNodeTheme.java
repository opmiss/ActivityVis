/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Stroke;
import java.util.HashMap;
import java.util.Map;

import com.ibm.peony.display.ICamera;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;

public class DefaultNodeTheme extends DefaultTheme implements INodeTheme {

	protected float m_thick = 1f;
	
	protected Map m_strokes = null;
	
	public DefaultNodeTheme() {
		super();
		m_strokes = new HashMap();
		m_colors.put(THEME_TEXT_COLOR, Color.black);
		m_colors.put(THEME_TEXT_COLOR_HIGHLIGHT, Color.black);
		Font f = new Font("Verdana", Font.PLAIN, 10);
		m_colors.put(THEME_TEXT_FONT, f);
		m_colors.put(THEME_TEXT_FONT_HIGHLIGHT, f);
	}
	
	public Color getTextColor(IVisualNode n, boolean highlight) {
		return highlight ? (Color)this.m_colors.get(THEME_TEXT_COLOR_HIGHLIGHT) : (Color)this.m_colors.get(THEME_TEXT_COLOR);
	}

	public Font getTextFont(IVisualNode n, boolean highlight) {
		return highlight ? (Font)this.m_fonts.get(THEME_TEXT_FONT_HIGHLIGHT) : (Font)this.m_fonts.get(THEME_TEXT_FONT);
	}
	
	public Stroke getOutlineThinck(IVisualElement e, boolean highlight) {
		ICamera c = m_owner.getOwner().getCamera();
		return getStroke((float)c.getScale());
	}
	
	protected Stroke getStroke(float scale) {
		Stroke s = (Stroke)m_strokes.get(new Float(scale));
		if(s == null) {
			s = new BasicStroke((float)(m_thick / scale), BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER);
			m_strokes.put(new Float(scale), s);
		}
		return s;
	}

	public void setOutlineThinck(float thick) {
		m_thick = thick;
		m_strokes.clear();
	}
}
