/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Stroke;

import com.ibm.peony.geometry.IVisualElement;

public interface IEdgeTheme extends ITheme {
	
	/**
	 * Get the thickness of the specified edge according
	 * to the highlight flag
	 * 
	 * @param e the specified edge
	 * @param highlight the highlight flag
	 * @return the thickness stork
	 */
	public Stroke getThickness(IVisualElement e, boolean highlight);

}
