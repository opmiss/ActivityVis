/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.layer;

import java.awt.Graphics2D;

import com.ibm.peony.display.BaseLayer;

public interface ILayerRender {
		
	/**
	 * Rendering the visual elements related to this layer
	 * @param g the grphics of the diplsy
	 */
	public void render(Graphics2D g, BaseLayer layer);
	
	public boolean isEnable();
	
	public void setEnable(boolean enable);
		
}
