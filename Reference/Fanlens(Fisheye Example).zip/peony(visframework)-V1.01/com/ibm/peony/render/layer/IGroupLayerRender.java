/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.layer;

import java.util.Comparator;

import com.ibm.peony.display.ILayer;


public interface IGroupLayerRender extends ILayerRender {

	public void addRender(ILayerRender render);
	
	public ILayerRender[] getLayerRenders();
	
	public void removeRender(ILayerRender render);
	
	public ILayerRender removeRender(int idx);
	
	public ILayerRender getLayerRender(int idx);
	
	public void setEnable(int idx, boolean enable);
	
	public boolean isEnable(int idx);
	
	public void setComparator(Comparator c);
	
	public Comparator getComparator();
	
	public void clear();
	
	public boolean contains(ILayer Layer);
	
}
