/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.layer;

public abstract class AbstractLayerRender implements ILayerRender {

	protected boolean m_enable = true;
	
	public AbstractLayerRender() {
		m_enable = true;
	}

	public synchronized boolean isEnable() {
		return m_enable;
	}

	public synchronized void setEnable(boolean enable) {
		m_enable = enable;
	}
}
