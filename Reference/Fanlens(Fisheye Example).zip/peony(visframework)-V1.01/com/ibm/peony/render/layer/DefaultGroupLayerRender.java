/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.layer;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import com.ibm.peony.display.BaseLayer;
import com.ibm.peony.display.ILayer;

public class DefaultGroupLayerRender extends AbstractLayerRender implements IGroupLayerRender {

	protected ArrayList m_renders = null;
	protected Comparator m_compartor = null;
	
	public DefaultGroupLayerRender() {
		m_renders = new ArrayList(0);
	}
	
	public synchronized void render(Graphics2D g, BaseLayer layer) {
		int size = m_renders.size();
		ILayerRender r = null;
		for(int i = 0; i < size; i++) {
			r = (ILayerRender)m_renders.get(i);
			if(r.isEnable()) {
				r.render(g, layer);
			}
		}
	}

	public synchronized void addRender(ILayerRender render) {
		
		if(!m_renders.contains(render)) {
			m_renders.add(render);
			if(null != m_compartor) {
				Collections.sort(m_renders, m_compartor);
			}
		}
	}

	public synchronized void removeRender(ILayerRender render) {
		m_renders.remove(render);
	}

	public synchronized ILayerRender removeRender(int idx) {
		return (ILayerRender)m_renders.remove(idx);
	}

	public synchronized ILayerRender getLayerRender(int idx) {
		return (ILayerRender)m_renders.get(idx);
	}

	public void setEnable(int idx, boolean enable) {
		getLayerRender(idx).setEnable(enable);
	}

	public boolean isEnable(int idx) {
		return getLayerRender(idx).isEnable();
	}

	public void setComparator(Comparator c) {
		m_compartor = c;
	}

	public Comparator getComparator() {
		return m_compartor;
	}

	public synchronized ILayerRender[] getLayerRenders() {
		return (ILayerRender[])m_renders.toArray(new ILayerRender[]{});
	}
	
	public synchronized void clear() {
		m_renders.clear();
	}
	
	public boolean contains(ILayer layer) {
		return m_renders.contains(layer);
	}
}
