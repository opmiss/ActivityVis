/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Color;
import java.awt.Font;
import java.util.HashMap;
import java.util.Map;

import com.ibm.peony.display.ILayer;

public class DefaultTheme implements ITheme, Cloneable {

	protected Map m_colors = new HashMap(0);
	protected Map m_fonts = new HashMap(0);
	protected Map m_brushes = new HashMap(0);
	
	protected ILayer m_owner = null;
	
	public DefaultTheme() {
		m_colors.put(THEME_OUTLINE_COLOR, DEFAULT_OUTLINE_COLOR);
		m_colors.put(THEME_OUTLINE_COLOR_HIGHLIGHT, DEFAULT_OUTLINE_COLOR_HIGHLIGHT);
		
		m_colors.put(THEME_FILL_COLOR, DEFAULT_FILL_COLOR);
		m_colors.put(THEME_FILL_COLOR_HIGHLIGHT, DEFAULT_FILL_COLOR_HIGHLIGHT);
		
		m_colors.put(THEME_LABEL_COLOR, Color.darkGray);
		m_colors.put(THEME_LABEL_COLOR_HIGHLIGHT, Color.blue);
		
		Font f = new Font("Verdana", Font.PLAIN, 9);
		m_fonts.put(THEME_LABEL_FONT, f);
		m_fonts.put(THEME_LABEL_FONT_HIGHLIGHT, f);
	}
	
	public Color getOutlineColor(Object e, boolean highlight) {
		return highlight ? (Color)this.m_colors.get(THEME_OUTLINE_COLOR_HIGHLIGHT) : (Color)this.m_colors.get(THEME_OUTLINE_COLOR);
	}

	public Color getFillColor(Object e, boolean highlight) {
		return highlight ? (Color)this.m_colors.get(THEME_FILL_COLOR_HIGHLIGHT) : (Color)this.m_colors.get(THEME_FILL_COLOR);
	}

	public Color getLabelColor(Object e, boolean highlight) {
		return highlight ? (Color)this.m_colors.get(THEME_LABEL_COLOR_HIGHLIGHT) : (Color)this.m_colors.get(THEME_LABEL_COLOR);
	}

	public Font getLabelFont(Object e, boolean highlight) {
		return highlight ? (Font)this.m_fonts.get(THEME_LABEL_FONT_HIGHLIGHT) : (Font)this.m_fonts.get(THEME_LABEL_FONT);
	}

	public Color getColor(String key) {
		return (Color)m_colors.get(key);
	}

	public void setColor(String key, Color color) {
		m_colors.put(key, color);
	}

	public Font getFont(String key) {
		return (Font)m_fonts.get(key);
	}

	public void setFont(String key, Font font) {
		m_fonts.put(key, font);
	}
	
	protected String getKey(int item, int state) {
		return "#" + (item & state) + "#";
	}

	public void setOwner(ILayer owner) {
		m_owner = owner;
	}

	public ILayer getOwner() {
		return m_owner;
	}

	public void setOutlineColor(Object e, Color color, boolean highlight) {
		m_colors.put(highlight ? THEME_OUTLINE_COLOR_HIGHLIGHT : THEME_OUTLINE_COLOR, color);
	}

	public void setFillColor(Object e, Color color, boolean highlight) {
		m_colors.put(highlight ? THEME_FILL_COLOR_HIGHLIGHT : THEME_FILL_COLOR, color);
	}

	public Color setLabelColor(Object e, Color c, boolean highlight) {
		m_colors.put(highlight ? THEME_LABEL_COLOR_HIGHLIGHT : THEME_LABEL_COLOR, c);
		return null;
	}

	public void setLabelFont(Object e, Font f, boolean highlight) {
		m_fonts.put(highlight ? THEME_LABEL_FONT_HIGHLIGHT : THEME_LABEL_FONT, f);
	}
	
	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}
	
}
