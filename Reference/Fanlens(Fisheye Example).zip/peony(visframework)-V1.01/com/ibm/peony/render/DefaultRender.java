/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Shape;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.profile.IRenderProfile;

public abstract class DefaultRender implements IRender {
	
	/**
	 * The view that the render is registered in. 
	 */
	protected ILayer m_layer;
	
//	/**
//	 * The raw shape of the element, used for locating 
//	 * element, holding the size of element, and 
//	 * checking the point in or not in the element
//	 * 
//	 */
//	protected Shape m_rawShape = null;
	
	/**
	 * progress of the animation
	 */
	protected double m_frac = 1;
	
	protected IRenderProfile m_profile = null;
	
	public DefaultRender() {
	}
	
	public void setOwner(ILayer layer) {
		m_layer = layer;
	}
	
	public ILayer getOwner() {
		return m_layer;
	}
		
	public boolean locatePoint(double x, double y, IVisualElement e) {
		Shape s = getRawShape(e);
		if(null == s) {
			return false;
		}
		return s.intersects(x, y, 1, 1);
	}
	
	public void setFrac(double frac) {
		this.m_frac = frac;
	}
	
	public void setRawShapeProfile(IRenderProfile f) {
		m_profile = f;
		m_profile.setContext(m_layer);
	}
	
	public IRenderProfile getRawShapeProfile() {
		return m_profile;
	}
	
	/**
	 * Get the raw shape of the specified visual element 
	 * 
	 * @param e the specified visual element
	 * @return the rew shape of the specified visual element
	 */
	public Shape getRawShape(IVisualElement e) {
		if(null != m_profile) {
			return m_profile.getRawShape(e);
		}
		return null;
	}
}
