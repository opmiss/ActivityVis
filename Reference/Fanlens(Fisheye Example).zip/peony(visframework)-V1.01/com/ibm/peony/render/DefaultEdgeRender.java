/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.Line2D;

import com.ibm.peony.geometry.IVisualEdge;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.sdl.data.api.IEdge;


public class DefaultEdgeRender extends DefaultRender {
	
	private Line2D m_line = new Line2D.Double();

	public DefaultEdgeRender() {
	}

	public Shape getRawShape(IVisualElement elem) {
		
		IEdge e = (IEdge) elem;
		
		IVisualNode parent = (IVisualNode) e.getFirstNode();
		IVisualNode node = (IVisualNode) e.getSecondNode();

		if (null == parent) {
			return null;
		}

		double x1 = node.getX();
		double y1 = node.getY();
		double x2 = parent.getX();
		double y2 = parent.getY();
		
		m_line.setLine(x1, y1, x2, y2);
		
		return m_line;
	}

	public void render(Graphics2D g, IVisualElement element, ITheme theme, boolean highlight) {

		IVisualEdge e = (IVisualEdge) element;

		if(null == e) return;
		
		IEdgeTheme et = (IEdgeTheme) theme;
		g.setColor(et.getOutlineColor(e, highlight));
		Stroke s = g.getStroke();
		g.setStroke(et.getThickness(e, highlight));
		Shape shape = getRawShape(e);
		g.draw(m_layer.transform(shape));
		g.setStroke(s);
	}
}
