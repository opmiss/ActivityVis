/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.profile;

import java.awt.Shape;

import com.ibm.peony.display.ILayer;

public interface IRenderProfile {
	
	public static final int RECTANGLE = 0;
	public static final int ROUND_RECTANGLE = 1;
	public static final int ELLIPSE = 2;

	public Shape getRawShape(Object elem);
	
	public void setContext(ILayer layer);
	
	public ILayer getContext();
	
	public void setType(int type);
	
	public int getType();
	
}
