/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.profile;

import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;

import com.ibm.peony.geometry.IVisualNode;

public class DefaultNodeProfile extends DefaultProfile {
	
	protected Shape m_shape = null;
	
	protected int m_type = 1;
	
	public DefaultNodeProfile() {
		this(ROUND_RECTANGLE);
	}
	
	public DefaultNodeProfile(int type) {
		m_type = type;
		switch(m_type) {
		case RECTANGLE:
			m_shape = new Rectangle2D.Double();
			break;
		case ROUND_RECTANGLE:
			m_shape = new RoundRectangle2D.Double();
			break;
		case ELLIPSE:
			m_shape = new Ellipse2D.Double();
			break;
		}
	}
	
	public int getType() {
		return m_type;
	}
	
	public void setType(int type) {
		m_type = type;
		switch(m_type) {
		case RECTANGLE:
			m_shape = new Rectangle2D.Double();
			break;
		case ROUND_RECTANGLE:
			m_shape = new RoundRectangle2D.Double();
			break;
		case ELLIPSE:
			m_shape = new Ellipse2D.Double();
			break;
		}
	}
	
	public Shape getRawShape(Object elem) {
		
		if(!(elem instanceof IVisualNode)) {
			return null;
		}
		
		IVisualNode node = (IVisualNode)elem;
		
		double point_x = node.getX();
		double point_y = node.getY();
		double ww = node.getWidth();
		double hh = node.getHeight();
		double x0 = point_x - ww / 2;
		double y0 = point_y - hh / 2;
		
		switch(m_type) {
		case RECTANGLE:
			((Rectangle2D.Double)m_shape).setFrame(x0, y0, ww, hh);
			break;
		case ROUND_RECTANGLE:
			((RoundRectangle2D.Double)m_shape).setRoundRect(x0, y0, ww, hh, 8, 8);
			break;
		case ELLIPSE:
			((Ellipse2D.Double)m_shape).setFrame(x0, y0, ww, hh);
			break;
		}
		
		return m_shape;
	}
}
