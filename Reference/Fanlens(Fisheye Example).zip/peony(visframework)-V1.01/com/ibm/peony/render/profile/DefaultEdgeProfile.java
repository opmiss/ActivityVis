/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.profile;

import java.awt.Shape;

public class DefaultEdgeProfile extends DefaultProfile {

	public static final int STRAIGHT_LINE = 0;
	public static final int BEZIER = 1;
	
	public Shape getRawShape(Object elem) {
		return null;
	}

}
