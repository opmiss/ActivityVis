/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.profile;

import com.ibm.peony.display.ILayer;

public abstract class DefaultProfile implements IRenderProfile {
	
	protected ILayer m_context = null;

	protected int m_type = 0;

	public void setContext(ILayer layer) {
		m_context = layer;
	}

	public ILayer getContext() {
		return m_context;
	}

	public void setType(int type) {
		m_type = type;
	}

	public int getType() {
		return m_type;
	}
}
