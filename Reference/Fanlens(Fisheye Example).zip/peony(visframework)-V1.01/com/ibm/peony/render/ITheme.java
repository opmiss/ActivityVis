/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Color;
import java.awt.Font;

import com.ibm.peony.display.ILayer;

public interface ITheme extends Cloneable {
	
//	public static final int THEME_STATE_NORMAL = 0x0000;
//	public static final int THEME_STATE_HIGHLIGHT = 0x0001;
//	public static final int THEME_STATE_DRAGGED = 0x0002;
//	public static final int THEME_STATE_PRESSED = 0x0003;
//	
//	public static final int THEME_OUTLINE_COLOR = 0x0100;
//	public static final int THEME_FILL_COLOR = 0x0200;
//	public static final int THEME_LABEL_COLOR = 0x0300;
//	public static final int THEME_LABEL_FONT = 0x0400;
	
	public static final String THEME_OUTLINE_COLOR = "#THEME_OUTLINE_COLOR#";
	public static final String THEME_OUTLINE_COLOR_HIGHLIGHT = "#THEME_OUTLINE_COLOR_HIGHLIGHT#";
	
	public static final String THEME_FILL_COLOR = "#THEME_FILL_COLOR#";
	public static final String THEME_FILL_COLOR_HIGHLIGHT = "#THEME_FILL_COLOR_HIGHLIGHT#";
			
	public static final String THEME_LABEL_COLOR = "#THEME_LABEL_TEXT_COLOR#";
	public static final String THEME_LABEL_COLOR_HIGHLIGHT = "#THEME_LABEL_TEXT_COLOR_HIGHLIGHT#";
	
	public static final String THEME_LABEL_FONT = "#THEME_LABEL_FONT#";
	public static final String THEME_LABEL_FONT_HIGHLIGHT = "#THEME_LABEL_FONT_HIGHLIGHT#";
	
	public static final Color  	DEFAULT_FILL_COLOR  = new Color(222,247,251);
	public static final Color 	DEFAULT_FILL_COLOR_HIGHLIGHT = new Color(255,156,3);
	
	public static final Color  	DEFAULT_OUTLINE_COLOR  = new Color(187,187,187);
	public static final Color 	DEFAULT_OUTLINE_COLOR_HIGHLIGHT = new Color(253,247,15);
	
	public static final Color  	DEFAULT_TIP_FILL_COLOR  = new Color(255,255,198);
	public static final Color 	DEFAULT_TIP_OUTLINE_COLOR = new Color(0,0,0);
	
//	public static final Color 	DEFAULT_NODE_FILL_COLOR = new Color()
	/**
	 * Get the outline color of the specified visual 
	 * element according to the highlight flag.
	 * 
	 * @param e specified visual element
	 * @param highlight the highlight flag
	 * @return outline color
	 */
	public Color getOutlineColor(Object e, boolean highlight);
	
	public void setOutlineColor(Object e, Color color, boolean highlight);
	
	/**
	 * Get the fill color of the specified visual 
	 * element according to the highlight flag.
	 * 
	 * @param e specified visual element
	 * @param highlight the highlight flag
	 * @return fill color
	 */
	public Color getFillColor(Object e, boolean highlight);
	
	public void setFillColor(Object e, Color color, boolean highlight);
	
	/**
	 * Get the label background color of the specified visual 
	 * element according to the highlight flag.
	 * 
	 * @param e specified visual element
	 * @param highlight the highlight flag
	 * @return lable background color
	 */
	public Color getLabelColor(Object e, boolean highlight);
	
	public Color setLabelColor(Object e, Color c, boolean highlight);
	
	/**
	 * Get the label text font of the specified visual 
	 * element according to the highlight flag.
	 * 
	 * @param e specified visual element
	 * @param highlight the highlight flag
	 * @return label text font
	 */
	public Font getLabelFont(Object e, boolean highlight);
	
	public void setLabelFont(Object e, Font f, boolean highlight);
	
	/**
	 * Get the user defined color accroding to the specified key 
	 * 
	 * @param key the specified key
	 * @return user defined color
	 */
	public Color getColor(String key);
	
	/**
	 * Set user defined color whith specified key
	 * 
	 * @param key the specified key
	 * @param color user defined color
	 */
	public void setColor(String key, Color color);
	
	/**
	 * Get the user defined font accroding to the specified key
	 * 
	 * @param key the specified key
	 * @return user defined font
	 */
	public Font getFont(String key);
	
	/**
	 * Set user defined font whith specified key
	 * 
	 * @param key the specified key
	 * @param font user defined color
	 */
	public void setFont(String key, Font font);
	
	public void setOwner(ILayer owner);
	
	public ILayer getOwner();
}
