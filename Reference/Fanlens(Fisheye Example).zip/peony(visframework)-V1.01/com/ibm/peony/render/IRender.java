/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Graphics2D;
import java.awt.Shape;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.profile.IRenderProfile;

/**
 * 
 * The Render is used for draw visual elements, each visual 
 * element maps to a render to draw it on the view.
 * 
 * @author CaoNan
 */
public interface IRender {

	public void setOwner(ILayer layer);
	
	public ILayer getOwner();
	
	/**
     * Render visual element onto the view
     * 
     * @param g the Graphics2D context
     * @param item the item to draw
     * @param highlight If true the element should be 
     * rendered in a highlight way
     */
    public void render(Graphics2D g, IVisualElement element, ITheme theme, boolean highlight);
    
    /**
     * Check the visual element contains the point(x, y) or not.
     * 
     * @param x
     * @param y
     * @return If true contains the point(x, y) or not.
     */
//    public boolean locatePoint(double x, double y, AffineTransform transform, IDistortion distortion, IVisualElement e);
    public boolean locatePoint(double x, double y, IVisualElement e);
    
    /**
     * Set the animation progress, which could be used for
     * element size or location computing during the 
     * animation
     * 
     * @param p the progress of the animation belongs to [0, 1]
     */
    public void setFrac(double frac);
    
//    /**
//     * Set the offset of location where render draws the element.
//     * 
//     * @param x the offset of x
//     * @param y the offset of y
//     */
//    public void setOffset(double x, double y);   
    
    
    public Shape getRawShape(IVisualElement e);
    
    public void setRawShapeProfile(IRenderProfile f);
    
    public IRenderProfile getRawShapeProfile();
}
