/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.Color;
import java.awt.Font;
import java.awt.Stroke;

import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;

public interface INodeTheme extends ITheme {
	
	public static final String THEME_TEXT_COLOR = "#THEME_TEXT_COLOR#";
	public static final String THEME_TEXT_COLOR_HIGHLIGHT = "#THEME_TEXT_COLOR_HIGHLIGHT#";
	public static final String THEME_TEXT_FONT = "#THEME_TEXT_FONT#";
	public static final String THEME_TEXT_FONT_HIGHLIGHT = "#THEME_TEXT_FONT_HIGHLIGHT#";
	
	public Color getTextColor(IVisualNode n, boolean highlight);
	public Font getTextFont(IVisualNode n, boolean highlight);
	public void setOutlineThinck(float thick);
	public Stroke getOutlineThinck(IVisualElement e, boolean highlight);
	
}
