/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.interaction;

import java.awt.Paint;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.border.Border;

import com.ibm.peony.render.layer.ILayerRender;

public interface IRangeHighlightRender extends ILayerRender {

	public void enableFill(boolean fill);
	
	public boolean isFill();
	
	public void setElements(Object[] elems);
	
	public void setFillPaint(Paint paint);
	
	public Paint getFillPaint();
	
	public void setBorder(Border border);
	
	public Rectangle2D getBounds();
	
	public void setBounds(Rectangle2D rect);
	
	public void setBounds(double x, double y, double w, double h);
	
	public void setBoundsFromDiagonal(Point2D p1, Point2D p2);
	
}
