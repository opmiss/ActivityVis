/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.interaction;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

import com.ibm.peony.display.BaseLayer;
import com.ibm.peony.display.ICamera;
import com.ibm.peony.display.ILayer;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualEdge;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.layer.AbstractLayerRender;
import com.ibm.peony.util.math.Translation;

public class RangeHighlightRender extends AbstractLayerRender implements IRangeHighlightRender {
	
	protected Rectangle2D.Double m_rect = null;
	
	protected Paint m_fillpaint = null;
	
	protected Border m_border = null;
	
	protected Paint m_highlight = Color.blue;
	
	protected Stroke m_elemborder = null;
	
	protected Object[] m_elems = null;
	
	protected boolean m_bFill = true;
	
	public RangeHighlightRender() {
		super();
		m_rect = new Rectangle2D.Double();
		m_fillpaint = new Color(0f, 0f, 1f, 0.45f);
		m_border = BorderFactory.
		createLineBorder(((Color)m_fillpaint).darker().darker());
		m_elemborder = new BasicStroke(1.5f);
	}
	
	public void setElements(Object[] elems) {
		m_elems = elems;
	}
	
	public void render(Graphics2D g, BaseLayer layer) {
//		highlightElements(g, layer);
		highlightRange(g, layer);
	}
	
	protected void highlightElements(Graphics2D g, ILayer layer) {
		if(!(layer instanceof VisualLayer) || m_elems == null) {
			return;
		}

		VisualLayer vislayer = (VisualLayer)layer;
		
		IVisualElement ve = null;
		IRender r = null;
		Shape s = null;
		for(int i = 0; i < m_elems.length; ++i) {
			ve = (IVisualElement)m_elems[i];
			
			if(ve instanceof IVisualEdge) {
				continue;
			}
			
			r = vislayer.getRender(ve);
			if(r == null) {
				continue;
			}
			s = r.getRawShape(ve);
			if(s == null) {
				continue;
			}
			
			Stroke sb = g.getStroke();
			g.setStroke(m_elemborder);
			g.setPaint(m_highlight);
			g.draw(s);
			g.setStroke(sb);
		}
	}
	
	protected void highlightRange(Graphics2D g, ILayer layer) {
		ICamera c = layer.getOwner().getCamera();

		AffineTransform bt = g.getTransform();
		g.setTransform(c.getTransform());
		
		Shape s = g.getClip();
		Stroke ss = g.getStroke();
		
		g.setStroke(new BasicStroke((float)(1.0 / c.getScale())));
		double p = c.getScale() - 1;

		g.setClip(m_rect);
		g.setPaint(m_fillpaint);
		
		int x = Translation.atoi(m_rect.getX() - p);
		int y = Translation.atoi(m_rect.getY() - p);
		int w = Translation.atoi(m_rect.getWidth() + p + p);
		int h = Translation.atoi(m_rect.getHeight() + p + p);
		
		if(m_bFill) {
			g.fillRect(x, y, w, h);
		}
		
		if(null != m_border) {
			
			x = Translation.atoi(m_rect.getX());
			y = Translation.atoi(m_rect.getY());
			w = Translation.atoi(m_rect.getWidth() + p);
			h = Translation.atoi(m_rect.getHeight() + p);
			m_border.paintBorder(layer.getOwner(), g, 
					x, y, w, h);
		}

		g.setStroke(ss);
		g.setClip(s);
		g.setTransform(bt);
	}
	
	public void setFillPaint(Paint paint) {
		m_fillpaint = paint;
		m_border = BorderFactory.
		createLineBorder(((Color)m_fillpaint).darker().darker());
	}
	
	public Paint getFillPaint() {
		return m_fillpaint;
	}
	
	public void setBorder(Border border) {
		m_border = border;
	}
	
	public Rectangle2D getBounds() {
		return m_rect;
	}
	
	public void setBounds(double x, double y, double w, double h) {
		m_rect.setFrame(x, y, w, h);
	}
	
	public void setBounds(Rectangle2D rect) {
		m_rect.setFrame(rect);
	}
	
	public void setBoundsFromDiagonal(Point2D p1, Point2D p2) {
		m_rect.setFrameFromDiagonal(p1, p2);
	}
	
	public void setX(double x) {
		m_rect.x = x;
	}
	
	public double getX() {
		return m_rect.x;
	}
	
	public void setY(double y) {
		m_rect.y = y;
	}
	
	public double getY() {
		return m_rect.y;
	}
	
	public void setWidth(double w) {
		m_rect.width = w;
	}
	
	public double getWidth() {
		return m_rect.width;
	}
	
	public void setHeight(double h) {
		m_rect.height = h;
	}
	
	public double getHeight() {
		return m_rect.height;
	}

	public void enableFill(boolean fill) {
		m_bFill = fill;
	}
	
	public boolean isFill() {
		return m_bFill;
	}
}
