/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render.interaction;

import java.util.List;

import com.ibm.peony.render.layer.ILayerRender;

public interface IElementHighlightRender extends ILayerRender {

	public void setElements(List elem);
	
	public void addElement(Object elem);
	
	public void removeElement(Object elem);
	
	public boolean contains(Object elem);
	
	public void clear();
	
}
