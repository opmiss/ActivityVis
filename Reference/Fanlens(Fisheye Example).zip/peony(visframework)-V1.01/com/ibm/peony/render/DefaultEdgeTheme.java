/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.render;

import java.awt.BasicStroke;
import java.awt.Stroke;

import com.ibm.peony.geometry.IVisualElement;

public class DefaultEdgeTheme extends DefaultTheme implements IEdgeTheme {

	protected Stroke m_stroke = new BasicStroke(1.0f);
	
	public Stroke getThickness(IVisualElement e, boolean highlight) {
		return m_stroke;
	}
}
