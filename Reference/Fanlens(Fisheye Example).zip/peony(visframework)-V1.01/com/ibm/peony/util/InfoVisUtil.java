/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Stroke;
import java.awt.image.BufferedImage;
import java.util.Random;

public class InfoVisUtil {

	private static Random rand = null;
	static {
		rand = new Random(System.currentTimeMillis());
	}

	public static final Graphics2D DEFAULT_GRAPHICS = 
		(Graphics2D)new BufferedImage(1, 1, BufferedImage.TYPE_INT_ARGB).getGraphics();
	
	public static Color getRandomColor(float alpha) {
		if(alpha > 1f) {
			alpha = 1f;
		}
		
		if(alpha == 1) {
			return new Color(rand.nextInt(255), rand.nextInt(255), rand
					.nextInt(255));
		} else {
			return new Color(
					rand.nextInt(255), rand.nextInt(255), 
					rand.nextInt(255), (int)(255 * alpha));
		}
	}
	
	public static Color[] makeRandomColorArray(int size) {
		Color[] c = new Color[size];
		int h = 0, s = 0, b = 0;
		for(int i = 0; i < size; ++i) {
			h = rand.nextInt(255);
			s = rand.nextInt(255);
			b = rand.nextInt(255);
			c[i] = new Color(Color.HSBtoRGB(h, s, b));
		}
		return c;
	}

	public static Color[] makeColorArray(Color c0, Color c1, int size) {
		Color[] c = new Color[size];
		for (int i = 0; i < size; i++)
			c[i] = new Color(interpolate(c0.getRed(), c1.getRed(), i, size),
					interpolate(c0.getGreen(), c1.getGreen(), i, size),
					interpolate(c0.getBlue(), c1.getBlue(), i, size));
		return c;
	}
	
	public static Color[] makeColorArray(Color c0, Color c1, int size, float alpha) {
		Color[] c = new Color[size];
		for (int i = 0; i < size; i++)
			c[i] = new Color(interpolate(c0.getRed(), c1.getRed(), i, size) / 255f,
					interpolate(c0.getGreen(), c1.getGreen(), i, size) / 255f,
					interpolate(c0.getBlue(), c1.getBlue(), i, size) / 255f, alpha);
		return c;
	}
	
	public static Color[] makeCategoryColorArray(int s, int b, int size, int alpha) {
		Color[] c = new Color[size];
		for(int i = 0; i < size; ++i) {
			c[i] = getHSBColor(interpolate(0, 255, i, size)/255f, s/255f, b/255f, alpha/255);
		}
		return c;
	}
	
	public static Font[] makeFontArray(String name, int style, int size0, int size1, int num) {
		Font[] f = new Font[num];
		for (int i = 0; i < num; ++i) {
			f[i] = new Font(name, style, interpolate(size0, size1, i, num));
		}
		return f;
	}
	
	public static Stroke[] makeStrokeArray(float size0, float size1, int num) {
		int s1 = (int)(size0 * num);
		int s2 = (int)(size1 * num);
		Stroke[] s = new Stroke[num];
		
		for(int i = 0; i < num; ++i) {
			s[i] = new BasicStroke((float)interpolate(s1, s2, i, num) / num);
		}
		return s;
	}
	
	public static final Color getHSBColor(float h, float s, float b) {
		return getHSBColor(h, s, b, 1.0f);
	}
	
	public static final Color getHSBColor(float h, float s, float b, float alpha) {
		Color temp = new Color(Color.HSBtoRGB(h, s, b));
		return new Color(temp.getRed(), temp.getGreen(), temp.getBlue(), (int)(alpha * 255));
	}
	
	private static int interpolate(int a, int b, int i, int n) {
		return (a * (n - 1 - i) + b * i) / (n - 1);
	}
	
}
