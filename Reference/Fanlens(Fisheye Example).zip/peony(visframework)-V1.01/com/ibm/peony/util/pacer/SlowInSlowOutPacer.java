/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.pacer;


public class SlowInSlowOutPacer implements IPacer {

	public SlowInSlowOutPacer() {
	}
	
    public double pace(double f) {
        return ( f == 0.0 || f == 1.0 ? f : sigmoid(f) );
    }
    
    private double sigmoid(double x) {
        x = 12.0*x - 6.0;
        return (1.0 / (1.0 + Math.exp(-1.0 * x)));
    }
}
