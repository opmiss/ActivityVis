package com.ibm.peony.util.activity;

public class ActivityAdapter implements IActivityListener {

	protected IActivity m_activity = null;
	
	public ActivityAdapter() {
	}
	
	public boolean start(Object context) {
		return true;
	}

	public void finish(Object context) {
	}

	public void perform(Object context, double frac) {
	}

	public void setActivity(IActivity act) {
		m_activity = act;
	}
	
	public IActivity getActivity() {
		return m_activity;
	}
	
	
}
