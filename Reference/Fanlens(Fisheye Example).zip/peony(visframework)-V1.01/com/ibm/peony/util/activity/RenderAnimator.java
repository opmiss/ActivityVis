/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.render.IRender;

public class RenderAnimator extends Activity {

	private static final long serialVersionUID = -8995913047692700673L;

	protected IRender[] m_renders = null;
	
	protected boolean m_bincrease = true;
	
	public RenderAnimator() {
		super();
	}
	
	public RenderAnimator(long duration) {
		super(duration);
	}
	
	public RenderAnimator(long duration, long rate) {
		super(duration, rate);
	}
	
	public RenderAnimator(long duration, long rate, long start) {
		super(duration, rate, start);
	}
	
	public void setIncrease(boolean increase) {
		m_bincrease = increase;
	}

	public boolean start() {
		VisualLayer vislayer = (VisualLayer)m_layer;
		m_renders = vislayer.getEdgeRenders(null);
		return true;
	}
	
	public void finish() {
		if(m_bincrease) {
			perform(1);
		} else {
			perform(0);
		}
		super.finish();
	}
	
	public void perform(double frac) {
		
		VisualLayer vislayer = (VisualLayer)m_layer;
		
		if(!m_bincrease) {
			frac = 1 - frac;
		}
		
		if(null == m_renders) {
			return;
		}
		for(int i = 0; i < m_renders.length; ++i) {
			m_renders[i].setFrac(frac);
		}
		vislayer.getOwner().repaint();
	}
}
