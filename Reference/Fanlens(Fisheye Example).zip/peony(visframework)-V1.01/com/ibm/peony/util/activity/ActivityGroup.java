/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ActivityGroup extends Activity {

	private static final long serialVersionUID = 8116905038174627634L;
	protected List m_activities = null; 
	
	public ActivityGroup() {	
		m_activities = new ArrayList(0);
	}
	
	public ActivityGroup(long duration, long rate) {
		super(duration, rate);
		m_activities = new ArrayList(0);
	}
	
	public ActivityGroup(long duration, long rate, long start) {
		super(duration, rate, start);
		m_activities = new ArrayList(0);
	}
	
	public synchronized void add(IActivity act) {
		m_activities.add(act);
	}
	
	public synchronized void remove(IActivity act) {
		m_activities.remove(act);
	}
	
	public synchronized IActivity remove(int idx) {
		return (IActivity)m_activities.remove(idx);
	}
	
	public synchronized void removeAll() {
		m_activities.clear();
	}
	
	public IActivity[] toArray() {
		return (IActivity[])m_activities.toArray(new IActivity[]{});
	}
	
	public int size() {
		return m_activities.size();
	}
	
	public IActivity getActivity(int idx) {
		return (IActivity)m_activities.get(idx);
	}
	
	public synchronized void addActivity(int idx, IActivity act) {
		m_activities.add(idx, act);
	}
	
	public void pause() {
		super.pause();
		synchronized (m_activities) {
			int size = m_activities.size();
			Activity act = null;
			for(int i = 0; i < size; ++i) {
				act = ((Activity)m_activities.get(i));
				act.isPaused = isPaused;
			}
		}
	}

	public void perform(double frac) {
		super.perform(frac);
		synchronized (m_activities) {
			int size = m_activities.size();
			Activity act = null;
			for(int i = 0; i < size; ++i) {
				act = ((Activity)m_activities.get(i));
				act.perform(frac);
			}
		}
	}
	
	public void finish() {
		synchronized (m_activities) {
			int size = m_activities.size();
			Activity act = null;
			for(int i = 0; i < size; ++i) {
				act = ((Activity)m_activities.get(i));
				act.isPerforming = false;
				act.finish();
			}
		}
		super.finish();
	}
	
	public boolean start() {
		if(super.start()) {
			synchronized (m_activities) {
				Collections.sort(m_activities);
				boolean flag = true;
				int size = m_activities.size();
				Activity act = null;
				for(int i = 0; i < size; ++i) {
					act = ((Activity)m_activities.get(i));
					act.isPerforming = true;
					act.setActivityManager(m_manager);
					flag = act.start();
					if(!flag) {
						break;
					}
				}
				return flag;
			}
		}
		return false;
	}
	
	public boolean isEmpty() {
		return m_activities.isEmpty();
	}
}
