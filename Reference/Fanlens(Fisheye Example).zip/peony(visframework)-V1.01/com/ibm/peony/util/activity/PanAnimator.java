/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import java.awt.geom.Point2D;

public class PanAnimator extends Activity {

	private static final long serialVersionUID = -8103427872584468631L;

	private Point2D m_target = new Point2D.Double();
	
	private Point2D m_start = new Point2D.Double();
	
	private double delta_x = 0;
	private double delta_y = 0;
	
	private double dx = 0, lastx = 0;
	private double dy = 0, lasty = 0;
	
	private boolean panAbs = true;
	
	public PanAnimator() {
		super();
	}
	
	public PanAnimator(long aDuration) {
		super(aDuration);
	}
	
	public PanAnimator(long aDuration, long aStepRate) {
		super(aDuration, aStepRate);	
	}
	
	public void setTarget(Point2D target) {
		m_target.setLocation(target);
	}
	
	public void setTarget(double x, double y) {
		m_target.setLocation(x, y);
	}
	
	public void setStart(double x, double y) {
		m_start.setLocation(x, y);
	}
	
	public void setStart(Point2D start) {
		m_start.setLocation(start);
	}
	
	public void enablePanAbs(boolean abs) {
		panAbs = abs;
	}
	
	public boolean start() {
		if(super.start()) {
			delta_x = m_target.getX() - m_start.getX();
			delta_y = m_target.getY() - m_start.getY();
			
			lastx = m_start.getX();
			lasty = m_start.getY();
			return true;
		}
		return false;
	}
	
	public void perform(double frac) {
		double x = m_start.getX() + frac * delta_x;
		double y = m_start.getY() + frac * delta_y;
		
		dx = x - lastx;
		dy = y - lasty;
		
		if(panAbs) {
			m_layer.getOwner().panAbs(dx, dy);
		} else {
			m_layer.getOwner().pan(dx, dy);
		}
		m_layer.getOwner().clearCavas();
		m_layer.getOwner().repaint();
		
		lastx = x;
		lasty = y;
	}
}
