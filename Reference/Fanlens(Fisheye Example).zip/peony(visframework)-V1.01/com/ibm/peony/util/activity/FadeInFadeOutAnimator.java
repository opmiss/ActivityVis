/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Infovis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 */
package com.ibm.peony.util.activity;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.render.interaction.RangeHighlightRender;


public class FadeInFadeOutAnimator extends Activity {
	
	private static final long serialVersionUID = -8990925289732971211L;
	private float red = 0;
	private float green = 0;
	private float blue = 0;
	private float salpha = 0f;
	private float ealpha = 1f;
	private RangeHighlightRender m_render = null;
	
	private Map m_pool = null;
	
	public FadeInFadeOutAnimator() {
		this(1000);
	}
	
	public FadeInFadeOutAnimator(long aDuration) {
		this(aDuration, 40);
	}
	
	public FadeInFadeOutAnimator(long aDuration, long aStepRate) {
		super(aDuration, aStepRate);
		m_render = new RangeHighlightRender();
		m_pool = new HashMap();
	}
	
	public void setColor(float r, float g, float b, float a) {
		red = r;
		green = g;
		blue = b;
	}
	
	public void setColor(Color color) {
		red = color.getRed() / 255.0f;
		green = color.getGreen() / 255.0f;
		blue = color.getBlue() / 255.0f;
		m_render.setFillPaint(getColor(red, green, blue, salpha));
	}
	
	public void setStartAlpha(float a) {
		salpha = a;
	}
	
	public void setEndAlpha(float a) {
		ealpha = a;
	}
	
	public boolean start() {
		ILayer layer = (ILayer)m_layer;
		layer.setQuality(false);
		layer.addInteractionRender(m_render);
		return true;
	}
	
	public void finish() {
		ILayer layer = (ILayer)m_layer;
		layer.removeInteractionRender(m_render);
		layer.setQuality(true);
		layer.update();
		layer.getOwner().repaint();
		super.finish();
	}

	public void perform(double frac) {
		ILayer layer = (ILayer)m_layer;
		Color c = getColor(red, green, blue, (float)(salpha + frac * (ealpha - salpha)));
		
		m_render.setFillPaint(c);
		m_render.setBounds(layer.getBounds());
		layer.update();
		layer.getOwner().repaint();
	}
	
	private Color getColor(float r, float g, float b, float alpha) {
		
		String key = r + ":" + g + ":" + b + ":" + alpha;

		Color color = (Color)m_pool.get(key);
		if(null == color) {
			color = new Color(r, g, b, alpha);
			m_pool.put(key, color);
		}
		return color;
	}
}
