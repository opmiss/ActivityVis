/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import java.awt.Paint;
import java.awt.geom.Rectangle2D;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.interaction.RangeHighlightRender;

public class LayerAnimator extends Activity {

	private static final long serialVersionUID = -3519525093761661166L;
	private Rectangle2D.Double m_origin = null;
	private Rectangle2D.Double m_rect = null;
	private Rectangle2D.Double m_target = null;
	private double deltax = 0.0;
	private double deltay = 0.0;
	private double delta_width = 0.0;
	private double delta_height = 0.0;
	private RangeHighlightRender m_render = null;
	
	public LayerAnimator() {
		this(1000);
	}
	
	public LayerAnimator(long aDuration) {
		this(aDuration, 40);
	}
	
	public LayerAnimator(long aDuration, long aStepRate) {
		super(aDuration, aStepRate);
		m_rect = new Rectangle2D.Double();
		m_origin = new Rectangle2D.Double();
		m_target = new Rectangle2D.Double();
		m_render = new RangeHighlightRender();
	}
	
	public void setInitLoc(int x, int y, int width, int height) {
		m_origin.x = x;
		m_origin.y = y;
		m_origin.width = width;
		m_origin.height = height;
		
		deltax = m_target.x - m_origin.x;
		deltay = m_target.y - m_origin.y;
		delta_width = m_target.width - m_origin.width;
		delta_height = m_target.height - m_origin.height;
	}
	
	public void setInitLoc(IVisualNode node) {
		if(node == null) return;
		
		m_origin.x = node.getX();
		m_origin.y = node.getY();
		m_origin.width = node.getWidth();
		m_origin.height = node.getHeight();
		
		deltax = m_target.x - m_origin.x;
		deltay = m_target.y - m_origin.y;
		delta_width = m_target.width - m_origin.width;
		delta_height = m_target.height - m_origin.height;
	}
	
	public void setInitLoc(Rectangle2D node) {
		if(node == null) return;
		
		m_origin.x = node.getX();
		m_origin.y = node.getY();
		m_origin.width = node.getWidth();
		m_origin.height = node.getHeight();
		
		deltax = m_target.x - m_origin.x;
		deltay = m_target.y - m_origin.y;
		delta_width = m_target.width - m_origin.width;
		delta_height = m_target.height - m_origin.height;
	}
	
	public void setTarget(Rectangle2D rect) {
		m_target.setFrame(rect);
		
		deltax = m_target.x - m_origin.x;
		deltay = m_target.y - m_origin.y;
		delta_width = m_target.width - m_origin.width;
		delta_height = m_target.height - m_origin.height;
	}
	
	public void setTarget(double x, double y, double w, double h) {
		m_target.setFrame(x, y, w, h);
		
		deltax = m_target.x - m_origin.x;
		deltay = m_target.y - m_origin.y;
		delta_width = m_target.width - m_origin.width;
		delta_height = m_target.height - m_origin.height;
	}
	
	public void setLayerColor(Paint paint) {
		m_render.setFillPaint(paint);
	}
	
	public Paint getLayerColor() {
		return m_render.getFillPaint();
	}
	
	public boolean start() {
		ILayer layer = (ILayer)m_layer;
		layer.setQuality(false);
		layer.addInteractionRender(m_render);
		return super.start();
	}
	
	public void finish() {
		ILayer layer = (ILayer)m_layer;
		layer.removeInteractionRender(m_render);
		layer.setQuality(true);
		layer.update();
		layer.getOwner().repaint();
		super.finish();
	}

	public void perform(double frac) {
		ILayer layer = (ILayer)m_layer;
		layer.update(m_rect);
		m_rect.x = m_origin.x + deltax * frac;
		m_rect.y = m_origin.y + deltay * frac;
		m_rect.width = m_origin.width + delta_width * frac;
		m_rect.height = m_origin.height + delta_height * frac;
		m_render.setBounds(m_rect);
		layer.update(m_rect);
		layer.getOwner().repaint();
		super.perform(frac);
	}
}
