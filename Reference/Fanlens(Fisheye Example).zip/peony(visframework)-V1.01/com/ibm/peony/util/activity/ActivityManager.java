/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Timer;

public class ActivityManager {

	private List m_activities = new ArrayList(0);
	private Timer m_timer;
	private List m_processing = new ArrayList(0);
	private final int ACTIVITY_FRAME_DELAY = 0;
	
	public ActivityManager() {
	}
		
	public void addActivity(IActivity activity) {
		addActivity(activity, false);
	}
	
	public boolean isPerforming() {
		return getTimer().isRunning();
	}

	public void addActivity(IActivity activity, boolean processLast) {
		if (m_activities.contains(activity)) {
			return;
		}
		
		if (processLast) {
			m_activities.add(0, activity);
		} else {
			m_activities.add(activity);
		}
		
		activity.setActivityManager(this);
		
		if (!getTimer().isRunning()) {
			start();
		}
	}
		
	public void removeActivity(IActivity activity) {
		if (!m_activities.contains(activity)) return;

		m_activities.remove(activity);
		
		if (m_activities.size() == 0) {
			stopTimer();
		}					
	}

	public void removeAllActivities() {			
		m_activities.clear();
		stopTimer();
	}

	private void processActivities(long current) {
		int size = m_activities.size();
		if (size > 0) {
			m_processing.clear();
			m_processing.addAll(m_activities);
			IActivity activity = null;
			for (int i = size - 1; i >= 0; i--) {
				activity = (IActivity) m_processing.get(i);
				if(!activity.isEnable()) continue;
				activity.process(current);
			}
		}		
	}
		
	private void start() {
		getTimer().start();
	}
	
	private void stopTimer() {
		getTimer().stop();
	}
	
	private Timer getTimer() {
		if (m_timer == null) {
			m_timer = new Timer (ACTIVITY_FRAME_DELAY, new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					processActivities(System.currentTimeMillis());
				}
			});
		}
		return m_timer;
	}
}
