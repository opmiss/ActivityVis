/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import java.io.Serializable;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.util.pacer.IPacer;

public interface IActivity extends Comparable, Serializable {
	
	public void setEnable(boolean enable);
	
	public boolean isEnable();
	
	public void setDuration(long duration);
	
	public long getDuration();
	
	public void setRate(long rate);
	
	public long getRate();
	
	public void setStartTime(long rate);
	
	public long getStartTime();
	
	public void setPacer(IPacer pacer);
	
	public IPacer getPacer();
	
	public boolean isPerforming();
	
	public void setActivityManager(ActivityManager manager);
	
	public void after(IActivity activity);
	
	public void before(IActivity activity);
	
	public void setLayer(ILayer context);
	
	public ILayer getLayer();
	
	public void setParam(Object param);
	
	public Object getParam();
	
	public boolean start();
	
	public void finish();
	
	public void pause();
	
	public boolean isPaused();
	
	public void terminate();
	
	public long process(long current);
	
	public void addListener(IActivityListener d);
	
	public void removeListener(IActivityListener d);
	
	public void clearAllListeners();
	
	public IActivity next();
	
	public boolean hasNext();
	
}
