package com.ibm.peony.util.activity;

public interface IActivityListener {
	
	public boolean start(Object context);
		
	public void finish(Object context);
		
	public void perform(Object context, double frac);
	
	public void setActivity(IActivity act);
	
	public IActivity getActivity();
	
}
