/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.activity;

import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

import com.ibm.peony.display.Display;
import com.ibm.peony.display.ICamera;

public class ZoomPanAnimator extends Activity {

	private static final long serialVersionUID = -6185647301779134612L;

	private Point2D m_zoomPt = null;
	
	private double m_size = 0;
	
	private double m_tsize = 0;
	
	private double m_lastsize = 0;
	
	private Point2D m_temp = null;
	
	private boolean zoomAbs = true;
	
	public ZoomPanAnimator() {
		super();
		m_zoomPt = new Point2D.Double();
		m_temp = new Point2D.Double();
	}
	
	public ZoomPanAnimator(long aDuration) {
		super(aDuration);
		m_zoomPt = new Point2D.Double();
		m_temp = new Point2D.Double();
	}
	
	public ZoomPanAnimator(long aDuration, long aStepRate) {
		super(aDuration, aStepRate);
		m_zoomPt = new Point2D.Double();
		m_temp = new Point2D.Double();
	}
	
	public Point2D getZoomPt() {
		return m_zoomPt;
	}
	
	public void enableZoomAbs(boolean abs) {
		zoomAbs = abs;
	}
	
	public void setZoomRange(Rectangle2D rect) {
		
		double x = rect.getX(), y = rect.getY();
		
		if(rect.getWidth() > rect.getHeight()) {
			m_size = rect.getHeight();
			x = rect.getX() + (rect.getWidth() - m_size) / 2.0;
		} else {
			m_size = rect.getWidth();
			y = rect.getY() + (rect.getHeight() - m_size) / 2.0;
		}
	
		double r = m_size / 2.0;
		
		m_zoomPt.setLocation(x + r, y + r);
	}
	
	public synchronized boolean  start() {
		if(!super.start()) return false;
		Display dis = m_layer.getOwner();
		dis.screenToWorld(m_zoomPt, m_temp);
		if(dis.getWidth() > dis.getHeight()) {
			m_tsize = dis.getHeight();
		} else {
			m_tsize = dis.getWidth();
		}
		m_lastsize = m_size;
		return true;
	}
	
	public synchronized void perform(double frac) {
		
		double s = m_size + frac * (m_tsize - m_size);
		double r = 1.0 + (s - m_lastsize) / m_tsize;
		
		m_layer.getOwner().zoom(m_temp, r, ICamera.DEFAULT_MIN_SCALE, ICamera.DEFAULT_MAX_SCALE, false);
		m_layer.getOwner().clearCavas();
		m_layer.getOwner().repaint();
		
		m_lastsize = s;
	}
}
