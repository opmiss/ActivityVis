/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class PBusyDialog extends JDialog {

	private static final long serialVersionUID = 4888215536673838905L;

	private JProgressBar m_process = null;

	private JLabel m_status = null;

	private boolean bProcessing = false;

	private Frame m_owner = null;

	public PBusyDialog(Frame owner) {
		super(owner);

		this.m_process = new JProgressBar(0, 100);
		this.m_process.setBackground(new Color(0, 0, 51));

		this.m_status = new JLabel("", JLabel.LEFT);
		this.m_status.setText("Data Loading...");
		this.m_status.setFont(new Font("Verdana", Font.PLAIN, 10));
		this.m_status.setForeground(Color.green);

		JPanel pane = new JPanel();
		pane.setLayout(new GridLayout(2, 1));
		pane.setBorder(BorderFactory.createLineBorder(Color.blue));
		pane.setBackground(new Color(0, 0, 51));
		pane.add(m_status);
		pane.add(m_process);

		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(pane, BorderLayout.CENTER);
		this.setUndecorated(true);
		this.setSize(150, 55);
		this.setModal(true);

		m_owner = owner;
	}

	public void setOwner(Frame frame) {
		m_owner = frame;
	}

	/**
	 * Change the status bar into a processbar to depict the proceduel is going
	 * on.
	 * 
	 */
	public void startProcess() {
		int x = 0, y = 0;
		if (null != m_owner) {
			Rectangle r = m_owner.getBounds();
			x = (int) (r.getCenterX() - getWidth() / 2.0);
			y = (int) (r.getCenterY() - getHeight() / 2.0);
		} else {
			Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
			x = (int) (d.width / 2 - getWidth() / 2.0);
			y = (int) (d.height / 2 - getHeight() / 2.0);
		}

		this.setLocation(x, y);

		this.bProcessing = true;
		this.m_process.setIndeterminate(true);
		this.setVisible(true);
	}

	/**
	 * Change back to the processBar
	 * 
	 */
	public void stopProcess() {
		this.bProcessing = false;
		this.m_process.setIndeterminate(false);
		this.setVisible(false);
	}

	public boolean isProcessing() {
		return bProcessing;
	}

	/**
	 * Set status text
	 * 
	 * @param text
	 */
	public void setStateText(String text) {
		this.m_status.setText(text);
	}

}
