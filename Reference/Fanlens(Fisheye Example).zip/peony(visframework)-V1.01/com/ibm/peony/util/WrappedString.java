/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.StringTokenizer;

/**
 * 
 * Object for drawing long pieces of text, wrapping the lines appropriately.
 * 
 */
public class WrappedString {

	private ArrayList lines = new ArrayList(0);

	private int leading;

	private int lineWidth;

	private String m_text = "";

	public WrappedString() {
	}

	/**
	 * 
	 * Create a new LongText object, using the given object's toString() method
	 * to create the text.
	 * 
	 */
	public WrappedString(String str, FontMetrics fm, int lineWidth) {

		this.lineWidth = lineWidth;
		this.leading = fm.getHeight();
		this.m_text = str;
		this.arrange(fm);
	}

	public void setText(String text) {
		this.m_text = text;
	}

	public void setLineWidth(int width) {
		this.lineWidth = width;
	}

	public void setLeading(int leading) {
		this.leading = leading;
	}

	public void arrange(FontMetrics fm) {
		if ("".equals(m_text))
			return;

		String s = m_text.toString();

		StringTokenizer t = new StringTokenizer(s, " \n\r\t\f", true);

		String currentLine = "";

		String newWord = null;

		String word = null;

		int w = 0; // which has zero width

		lines.clear();

		this.leading = fm.getHeight();

		while (t.hasMoreElements()) {

			word = t.nextToken();

			if (" ".equals(word)) {
				continue;
			}

			if ("\n\r\t\f".indexOf(word) != -1) {
				lines.add(currentLine);
				currentLine = "";
				w = 0;
				continue;
			}
			newWord = currentLine.length() == 0 ? word : " " + word;
			int newWordWidth = fm.stringWidth(newWord); // measure word
			w += newWordWidth;
			// if we've gone beyond
			// boundary in first word,
			// best to let it be.
			if (w < lineWidth || w == newWordWidth) {
				currentLine += newWord;
			} else {
				lines.add(currentLine);
				currentLine = word;
				w = fm.stringWidth(word);
			}
		}
		if (currentLine.length() > 0) {
			lines.add(currentLine);
		}
	}

	public Dimension getSize() {
		return new Dimension(lineWidth, leading * lines.size());
	}

	public void render(Graphics g, int x, int y) {
		int n = lines.size();
		for (int i = 0; i < n; i++) {
			y += leading;
			g.drawString((String) lines.get(i), x, y);
		}
	}

}
