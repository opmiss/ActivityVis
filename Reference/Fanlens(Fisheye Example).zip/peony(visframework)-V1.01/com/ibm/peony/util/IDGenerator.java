/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util;

import java.util.HashMap;
import java.util.Map;

public class IDGenerator {
	
	private static long entity_id = 0; 
	private static long struct_id = 0;
	
	private static Map m_id = new HashMap(0);
	
	public static String generateEntityID() {
		
		if(entity_id == Long.MAX_VALUE) {
			entity_id = 0;
		}
		
		return "[ENTITY][#" + (entity_id++) + "#]";
	}
	
	public static String generateID(String path) {
		int id = 0;
		if(m_id.containsKey(path)) {
			id = Integer.parseInt((String)m_id.get(path));
			id++;
		}
		m_id.put(path, "" + id);
		return "" + id;
	}
	
	public static String generateStructrueID() {
		if(struct_id == Long.MAX_VALUE) {
			struct_id = 0;
		}
		
		return "[STRUCTURE][$" + (struct_id++) + "$]";
	}
}
