/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util;

import java.util.ArrayList;

import com.ibm.peony.geometry.VisualEdge;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.data.graph.impl.EntityGraph;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.prop.IName;

public class GraphLib {

    private GraphLib() {
        // prevent instantiation
    }
        
    /**
     * Builds a completely unconnected (edge-free) graph with the given 
     * number of nodes
     * @param n the number of nodes
     * @return a graph with n nodes and no edges
     */
    public static IGraphDataEx getNodes(int n) {
        
    	EntityGraph g = new EntityGraph();
    	g.setEdgeType(VisualEdge.class);
       
        for ( int i=0; i < n; i++ ) {
            VisualNode node = new VisualNode();
            PropOperator.getInstance().setProperty(node, IName.PROP_NAME, "" + i);
            g.addNode(node);
        }
        return g;
    }
    
    /**
     * Builds a "star" graph with one central hub connected to the given
     * number of satellite nodes.
     * @param n the number of points of the star
     * @return a "star" graph with n points, for a total of n+1 nodes
     */
    public static IGraphDataEx getStar(int n) {
        EntityGraph g = new EntityGraph();
        g.setEdgeType(VisualEdge.class);
        
        VisualNode root = new VisualNode();
        PropOperator.getInstance().setProperty(root, IName.PROP_NAME, "0");
        g.addNode(root);
        
        for (int i=1; i <= n; ++i ) {
            VisualNode node = new VisualNode();
            PropOperator.getInstance().setProperty(node, IName.PROP_NAME, String.valueOf(i));
            g.addNode(node);
            g.addEdge(root, node);
        }
        return g;
    }
    
    /**
     * Returns a clique of given size. A clique is a graph in which every node
     * is a neighbor of every other node.
     * @param n the number of nodes in the graph
     * @return a clique of size n
     */
    public static IGraphDataEx getClique(int n) {
        EntityGraph g = new EntityGraph();
        g.setEdgeType(VisualEdge.class);
        
        VisualNode nodes[] = new VisualNode[n];
        for ( int i = 0; i < n; ++i ) {
            nodes[i] = new VisualNode();
            PropOperator.getInstance().setProperty(nodes[i], IName.PROP_NAME, String.valueOf(i));
            g.addNode(nodes[i]);
        }
        for ( int i = 0; i < n; ++i ) {
            for ( int j = i; j < n; ++j )
                if ( i != j )
                    g.addEdge(nodes[i], nodes[j]);
        }
        return g;
    }
    
    /**
     * Returns a graph structured as an m-by-n grid.
     * @param m the number of rows of the grid
     * @param n the number of columns of the grid
     * @return an m-by-n grid structured graph
     */
    public static IGraphDataEx getGrid(int m, int n) {
        EntityGraph g = new EntityGraph();
        g.setEdgeType(VisualEdge.class);
        VisualNode[] nodes = new VisualNode[m*n];
        for ( int i = 0; i < m*n; ++i ) {
            nodes[i] = new VisualNode();
            PropOperator.getInstance().setProperty(nodes[i], IName.PROP_NAME, String.valueOf(i));
            g.addNode(nodes[i]);
            
            if ( i >= n )
                g.addEdge(nodes[i-n], nodes[i]);
            if ( i % n != 0 )
                g.addEdge(nodes[i-1], nodes[i]);
        }
        return g;
    }
    
    public static IGraphDataEx getHoneycomb(int levels) {
        EntityGraph g = new EntityGraph();
        g.setEdgeType(VisualEdge.class);
        ArrayList layer1 = halfcomb(g, levels);
        ArrayList layer2 = halfcomb(g, levels);
        for ( int i=0; i<(levels<<1); ++i ) {
            VisualNode n1 = (VisualNode)layer1.get(i);
            VisualNode n2 = (VisualNode)layer2.get(i);
            g.addEdge(n1, n2);
        }
        return g;
    }
    
    private static ArrayList halfcomb(EntityGraph g, int levels) {
        ArrayList top   = new ArrayList();
        ArrayList layer = new ArrayList();
        
        int label = 0;
        
        for ( int i=0; i<levels; ++i ) {
            VisualNode n = new VisualNode();
            PropOperator.getInstance().setProperty(n, IName.PROP_NAME, String.valueOf(label++));
            g.addNode(n);
            top.add(n);
        }
        for ( int i=0; i<levels; ++i ) {
            VisualNode n = null;
            for ( int j=0; j<top.size(); ++j ) {
                VisualNode p = (VisualNode)top.get(j);
                if ( n == null ) {
                    n = new VisualNode();
                    PropOperator.getInstance().setProperty(n, IName.PROP_NAME, String.valueOf(label++));
                    g.addNode(n);
                    layer.add(n);
                }
                g.addEdge(p, n);
                n = new VisualNode();
                PropOperator.getInstance().setProperty(n, IName.PROP_NAME, String.valueOf(label++));
                g.addNode(n);
                layer.add(n);
                g.addEdge(p, n);
            }
            if ( i == levels-1 ) {
                return layer;
            }
            top.clear();
            for ( int j=0; j<layer.size(); ++j ) {
                VisualNode p = (VisualNode)layer.get(j);
                n = new VisualNode();
                PropOperator.getInstance().setProperty(n, IName.PROP_NAME, String.valueOf(label++));
                g.addNode(n);
                top.add(n);
                g.addEdge(p, n);
            }
            layer.clear();
        }
        // should never happen
        return top;
    }   
}
