/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.math;

public class ExtMath {

	public static double clamp(double low, double value, double high) {
		if (value < low)
			return low;
		if (value > high)
			return high;
		return value;
	}
	
	public static float clamp(float low, float value, float high) {
		if (value < low)
			return low;
		if (value > high)
			return high;
		return value;
	}

	public static double max3(double a, double b, double c) {
		return Math.max(Math.max(a,b),c);
	}
	
	public static double min3(double a, double b, double c) {
		return Math.min(Math.min(a,b),c);
	}
	

	public static double sinh(double x) {
		if (Double.isNaN(x))
			return Double.NaN;
		if (Double.isInfinite(x))
			return x > 0 ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY;
		if (x == 0)
			return x;
		return (Math.pow(Math.E, x) - Math.pow(Math.E, -x)) / 2;
	}

	public static double cosh(double x) {
		if (Double.isNaN(x))
			return Double.NaN;
		if (Double.isInfinite(x))
			return Double.POSITIVE_INFINITY;
		if (x == 0)
			return 1.0;
		return (Math.pow(Math.E, x) + Math.pow(Math.E, -x)) / 2;
	}

	public static double tanh(double x) {
		if (Double.isNaN(x))
			return Double.NaN;
		if (x == 0)
			return x;
		if (Double.isInfinite(x))
			return x > 0 ? +1.0 : -1.0;
		return sinh(x) / cosh(x);
	}
	
	public static int sign(double x) {
		if (x > 0) return 1; else
		if (x < 0) return -1; else
		return 0;
	}
		

}
