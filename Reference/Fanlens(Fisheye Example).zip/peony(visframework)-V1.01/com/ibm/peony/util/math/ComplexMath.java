/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.math;

public class ComplexMath {
	
	public static double[] getComplex(double[] a)	{
		
		double[] p = new double[2];
		p[0] = a[0];
		p[1] = a[1];
		return p;
	}
	
	public static double[] getComplex(double re, double im)	{
		
		double[] p = new double[2];
		p[0] = re;
		p[1] = im;
		return p;
	}
	
	public static double[] add(double[] a, double[] b)	{
		
		double[] sum = new double[2];
		sum[0] = a[0] + b[0];
		sum[1] = a[1] + b[1];
		return sum;
	}
	
	public static double[] subtract(double[] a, double[] b)	{
		
		double[] diff = new double[2];
		diff[0] = a[0] - b[0];
		diff[1] = a[1] - b[1];
		return diff;
	}
	
	public static double[] multiply(double[] a, double[] b)	{
		
		double[] prod = new double[2];
		prod[0] = a[0] * b[0] - a[1] * b[1];
		prod[1] = a[0] * b[1] + a[1] * b[0];
		return prod;
	}
	
	public static double[] divide(double[] a, double[] b)	{
		
		double[] quot = new double[2];
		double bModulusSq = b[0] * b[0] + b[1] * b[1];
		quot[0] = (a[0] * b[0] + a[1] * b[1]) / bModulusSq;
		quot[1] = (a[1] * b[0] - a[0] * b[1]) / bModulusSq;
		return quot;
	}
	
	public static double[] conj(double[] a)	{
		
		double[] conjugate = new double[2];
		conjugate[0] = a[0];
		conjugate[1] = -a[1];
		return conjugate;
	}
	
	public static double moduleSq(double[] a)	{
		
		return a[0] * a[0] + a[1] * a[1];
	}
	
	public static double module(double[] a)		{
		
		return Math.sqrt(a[0] * a[0] + a[1] * a[1]);
	}

}
