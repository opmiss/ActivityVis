package com.ibm.peony.util.math;

public class FisheyeTransformDemo {
	public static void main(String[] arg0) {
		double[] x_normal = {
				0.51851563802011,
				0.5555506175582838,
				0.5925855970964576,
				0.6296205766346314,
				0.6666555561728053,
				0.8148028813214081,
				0.9999851860081848,
				};
		double x_focus = 0.8369598937526921;
		double d = 5;
		double[] x_fisheye = FisheyeTransform.transform(x_normal, 0.5, x_focus, 0.7, d, FisheyeTransform.BORDER_PARTIAL);
		for (int i=0; i<x_fisheye.length; i++)
			System.out.println(x_fisheye[i]);
	}
}
