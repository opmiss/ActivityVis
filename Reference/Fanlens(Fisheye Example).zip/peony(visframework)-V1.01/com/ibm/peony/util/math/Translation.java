/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.math;

import java.awt.Point;
import java.awt.geom.Rectangle2D;

import com.ibm.peony.geometry.IVisualNode;



public class Translation {
	
	public static double mapToScreenX(IVisualNode e, double x, double ratio) {
		return (x - e.getX()) / ratio;
	}
	
	public static double mapToScreenY(IVisualNode e, double y, double ratio) {
		return (y - e.getY()) / ratio;
	}
	
	public static double mapFromScreenX(double x, double ratio, IVisualNode e) {
		if(null == e) return -1.0;
		
		return e.getX() + x * ratio;
	}
	
	public static double mapFromScreenY(double y, double ratio, IVisualNode e) {
		if(null == e) return -1.0;
		
		return e.getY() + y * ratio;
	}
	
	public static double mapToScreenX(IVisualNode e, double x, int width) {
		return (x - e.getX()) * width / e.getWidth();
	}
	
	public static double mapToScreenY(IVisualNode e, double y, int height) {
		return (y - e.getY()) * height / e.getHeight();
	}
	
	public static double mapFromScreenX(double x, int width, IVisualNode e) {
		if(null == e) return -1.0;
		
		return e.getX() + x * e.getWidth() / width;
	}
	
	public static double mapFromScreenY(double y, int height, IVisualNode e) {
		if(null == e) return -1.0;
		
		return e.getY() + y * e.getHeight() / height;
	}
	
	public static int atoi(double x) {
		return (int)(x+1e-12);
	}
	
	public static double e = 1e-8;
	
	public static int compare(double a, double b) {
		if (a > b + e)
			return 1;
		if (b > a + e)
			return -1;
		return 0;
	}
	
    /**
     * Returns a point based on (x, y) but constrained to be within the bounds
     * of the given rectangle.
     * 
     * @param x  the x-coordinate.
     * @param y  the y-coordinate.
     * @param area  the rectangle (<code>null</code> not permitted).
     * 
     * @return A point within the rectangle.
     */
    public static Point getPointInRectangle(int x, int y, Rectangle2D area) {
        x = (int) Math.max(
            Math.ceil(area.getMinX()), Math.min(x, Math.floor(area.getMaxX()))
        );   
        y = (int) Math.max(
            Math.ceil(area.getMinY()), Math.min(y, Math.floor(area.getMaxY()))
        );
        return new Point(x, y);
    }
}
