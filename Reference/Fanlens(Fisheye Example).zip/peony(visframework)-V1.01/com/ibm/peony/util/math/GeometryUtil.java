/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.math;


public class GeometryUtil {

	public static final String PROP_GEOMITEM = "#GEOM_ITEM#";
	
	public static final int EUCLID = 0;
	
	public static final int SPHERE_NORMAL = 1;
	
	public static final int HYPERBOLIC = 2;
	
	public static final double tol = 1e-9;
	
	public static int compare(double a, double b) {
		if (a > b + tol)
			return 1;
		if (b > a + tol)
			return -1;
		return 0;
	}
}
