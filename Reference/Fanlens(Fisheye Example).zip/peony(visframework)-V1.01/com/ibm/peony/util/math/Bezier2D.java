/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.util.math;

import java.awt.geom.GeneralPath;

public class Bezier2D {
	protected GeneralPath path;

	protected double[] pts;

	public Bezier2D() {
		path = new GeneralPath();
	}

	public void addControlPoint(double x, double y) {

	}

	public static GeneralPath cardinalSpline(GeneralPath p, float pts[],
			int start, int npoints, float slack, boolean closed, float tx,
			float ty) {
		// compute the size of the path
		int len = 2 * npoints;
		int end = start + len;

		if (len < 6) {
			throw new IllegalArgumentException(
					"To create spline requires at least 3 points");
		}

		float dx1, dy1, dx2, dy2;

		// compute first control point
		if (closed) {
			dx2 = pts[start + 2] - pts[end - 2];
			dy2 = pts[start + 3] - pts[end - 1];
		} else {
			dx2 = pts[start + 4] - pts[start];
			dy2 = pts[start + 5] - pts[start + 1];
		}

		// repeatedly compute next control point and append curve
		int i;
		for (i = start + 2; i < end - 2; i += 2) {
			dx1 = dx2;
			dy1 = dy2;
			dx2 = pts[i + 2] - pts[i - 2];
			dy2 = pts[i + 3] - pts[i - 1];
			p.curveTo(tx + pts[i - 2] + slack * dx1, ty + pts[i - 1] + slack
					* dy1, tx + pts[i] - slack * dx2, ty + pts[i + 1] - slack
					* dy2, tx + pts[i], ty + pts[i + 1]);
		}

		// compute last control point
		if (closed) {
			dx1 = dx2;
			dy1 = dy2;
			dx2 = pts[start] - pts[i - 2];
			dy2 = pts[start + 1] - pts[i - 1];
			p.curveTo(tx + pts[i - 2] + slack * dx1, ty + pts[i - 1] + slack
					* dy1, tx + pts[i] - slack * dx2, ty + pts[i + 1] - slack
					* dy2, tx + pts[i], ty + pts[i + 1]);

			dx1 = dx2;
			dy1 = dy2;
			dx2 = pts[start + 2] - pts[end - 2];
			dy2 = pts[start + 3] - pts[end - 1];
			p.curveTo(tx + pts[end - 2] + slack * dx1, ty + pts[end - 1]
					+ slack * dy1, tx + pts[0] - slack * dx2, ty + pts[1]
					- slack * dy2, tx + pts[0], ty + pts[1]);
			p.closePath();
		} else {
			p.curveTo(tx + pts[i - 2] + slack * dx2, ty + pts[i - 1] + slack
					* dy2, tx + pts[i] - slack * dx2, ty + pts[i + 1] - slack
					* dy2, tx + pts[i], ty + pts[i + 1]);
		}
		return p;
	}

}
