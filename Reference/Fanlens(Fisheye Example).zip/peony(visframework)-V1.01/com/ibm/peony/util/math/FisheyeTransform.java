
package com.ibm.peony.util.math;

/**
 * 
 * Transform normal coordinate into fisheye coordinate.
 * @author Lou, Xinghua
 *
 */

public class FisheyeTransform {

	/*
	 * border of fisheye transformation 
	 */
	public static final int BORDER_FULL = 0;
	public static final int BORDER_PARTIAL = 1;
	
	private static final boolean debug_on = false;
	
	public static double[] transform(double[] x_normal, double x_min,
			double x_focus, double x_max, double d, int border_type) {
		
		if (debug_on)
			System.out.println("entering fisheye transformation function ...");
		
		// validate parameters
		if (border_type == FisheyeTransform.BORDER_FULL) {
			x_min = x_normal[0];
			x_max = x_normal[x_normal.length-1];
		}
		if (x_min >= x_max)
			return x_normal;
		if (x_focus <= x_min || x_focus >= x_max)
			return x_normal;
		
		if (debug_on)
			System.out.println(x_min + " " + x_focus + " " + x_max + " " + d);		
		
		// do the transformation
		double[] fisheye = new double[x_normal.length];
		for (int i=0; i<x_normal.length; i++) {
			double normal = x_normal[i];
			if (normal >= x_min && normal < x_focus) {
				double x_normalized = (normal - x_min)/(x_focus - x_min);
				fisheye[i] = x_min + x_normalized/(d+1-d*x_normalized)*(x_focus - x_min);
				
				if (debug_on)
					System.out.println("A: normal value: "+normal+", fisheye value: "+fisheye[i]);
				
			}
			else if (normal >= x_focus && normal <= x_max) {
				double x_normalized = (x_max - normal)/(x_max - x_focus);
				fisheye[i] = x_max - x_normalized/(d+1-d*x_normalized)*(x_max - x_focus);
				
				if (debug_on)
					System.out.println("B: normal value: "+normal+", fisheye value: "+fisheye[i]);
			}
			else {
				fisheye[i] = normal;
				
				if (debug_on)
					System.out.println("C: normal value: "+normal+", fisheye value: "+fisheye[i]);
			}
		}

		return fisheye;
	}	
}
