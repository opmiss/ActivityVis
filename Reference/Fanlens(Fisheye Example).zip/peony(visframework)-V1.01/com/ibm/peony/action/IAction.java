/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.util.EventListener;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.util.activity.IActivity;


public interface IAction extends EventListener {
	
	public void setOwner(ILayer layer);
	public ILayer getOwner();
	
	public void setEnable(boolean enable);
	public boolean isEnable();
	
	public void setGeneralAction(boolean bGeneral);
	public boolean isGeneralAction();
	
	public void setActionMask(int mask);
	public int getActionMask();
	
	public void actionAdded();
	public void actionRemoved();
	
	public void elemsSelected(Object[] elements);
	
	public void elemDragged(Object element, MouseEvent e);
	public void elemMoved(Object element, MouseEvent e);
	public void elemWheelMoved(Object element, MouseWheelEvent e);
	public void elemClicked(Object element, MouseEvent e);
	public void elemPressed(Object element, MouseEvent e);
	public void elemReleased(Object element, MouseEvent e);
	public void elemEntered(Object element, MouseEvent e);
	public void elemExited(Object element, MouseEvent e);
	public void elemKeyPressed(Object element, KeyEvent e);
	public void elemKeyReleased(Object element, KeyEvent e);
	public void elemKeyTyped(Object element, KeyEvent e);
	
    public void mouseEntered(MouseEvent e);
    
    public void mouseExited(MouseEvent e);
    
    public void mousePressed(MouseEvent e);
    
    public void mouseReleased(MouseEvent e);
    
    public void mouseClicked(MouseEvent e);
    
    public void mouseDragged(MouseEvent e);
    
    public void mouseMoved(MouseEvent e);
    
    public void mouseWheelMoved(MouseWheelEvent e);
    
    public void keyPressed(KeyEvent e);
    
    public void keyReleased(KeyEvent e);
    
    public void keyTyped(KeyEvent e);
    
    public void addActionPerformer(IActivity activity);
    
    public void removeActionPerformer(IActivity activity);
    
    public IActivity[] getActionPerformers();
    
    public void removeAll();
	
}
