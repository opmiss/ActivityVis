/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import com.ibm.peony.display.Display;
import com.ibm.peony.util.activity.ActivityManager;
import com.ibm.peony.util.activity.PanAnimator;

public class PanAction extends ActionAdapter {

	private int m_xDown, m_yDown;
	
	private PanAnimator m_animator = new PanAnimator();

	public PanAction() {
		this(MouseEvent.BUTTON3_DOWN_MASK, false);
	}

	public PanAction(boolean bgeneral) {
		this(MouseEvent.BUTTON3_DOWN_MASK, bgeneral);
	}

	public PanAction(int mouseButton) {
		this(mouseButton, false);
	}

	public PanAction(int mask, boolean bgeneral) {
		m_mask = mask;
		m_bGeneralAction = bgeneral;
	}

	public void mousePressed(MouseEvent e) {
		if (m_mask == e.getModifiersEx()) {
			m_xDown = e.getX();
			m_yDown = e.getY();
			m_trigger = true;
			
			if(2 == e.getClickCount()) {
				Display display = (Display)e.getComponent();
				
				ActivityManager manager = display.getActivityManager();
				Point2D pt = e.getPoint();
				display.screenToWorld(pt, pt);
				m_animator.setStart( 
			        	display.getWidth() / 2.0, 
						display.getHeight() / 2.0);
		        m_animator.setTarget(pt);
		        m_animator.setStartTime(System.currentTimeMillis());
				manager.addActivity(m_animator);
			}
		}
	}
	
	public void mouseDragged(MouseEvent e) {
		if (m_mask == e.getModifiersEx()) {
			e.getComponent().setCursor(
					Cursor.getPredefinedCursor(Cursor.MOVE_CURSOR));
			Display display = (Display) e.getComponent();
			
			int x = e.getX(), y = e.getY();
			int dx = x - m_xDown, dy = y - m_yDown;
			display.pan(dx, dy);
			m_xDown = x;
			m_yDown = y;
			
			m_owner.update();
			display.clearCavas();
			display.repaint();
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (m_trigger) {
			e.getComponent().setCursor(Cursor.getDefaultCursor());
			m_xDown = -1;
			m_yDown = -1;
			m_trigger = false;
		}
	}
}
