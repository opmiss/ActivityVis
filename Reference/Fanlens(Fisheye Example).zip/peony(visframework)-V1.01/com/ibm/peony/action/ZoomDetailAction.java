/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.Color;
import java.awt.event.MouseEvent;

import com.ibm.peony.display.Display;
import com.ibm.peony.display.FullParentLayout;
import com.ibm.peony.display.ILayer;
import com.ibm.peony.display.LayerManager;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.util.activity.LayerAnimator;

public class ZoomDetailAction extends SelectAction {
	
	protected ILayer m_parent = null;
	protected Class m_type = null;
	protected ILayer m_content = null;
	protected LayerAnimator m_zoomin = null;
	
	public ZoomDetailAction() {
		this(MouseEvent.BUTTON3_DOWN_MASK);
	}

	public ZoomDetailAction(int mask) {
		super(mask);
		
		m_zoomin = new LayerAnimator() {
			public void finish() {
				m_owner.setQuality(true);
				Display disp = m_owner.getOwner();
				ILayer layer = disp.getLayer();
				LayerManager manager = null;
				if(layer instanceof LayerManager) {
					manager = ((LayerManager)layer);
					manager.addLayer(m_owner, m_content);
				} else {
					manager = new LayerManager();
					disp.setLayer(manager);
					FullParentLayout layout = new FullParentLayout();
					layout.setParent(m_owner);
					manager.addLayer(m_owner);
					manager.addLayer(m_owner, m_content);
					manager.registerLayout(layout);
					manager.setBackground(disp.getBackground());
				}
				m_content.setBounds(
						m_owner.getX(), m_owner.getY(), 
						m_owner.getWidth(), m_owner.getHeight());
				m_content.doLayout();
				manager.focusLayer(m_content);
				disp.doLayout();
				super.finish();
			}
		};
		addActionPerformer(m_zoomin);
		
		m_content = new VisualLayer();
		m_content.setBackground(new Color(0f, 0f, 0.8f, 0.55f));
		m_content.addAction(new CloseLayerAction());
	}
	
	public void setContent(ILayer layer) {
		m_content = layer;
		if(null != layer) {
			layer.addAction(new CloseLayerAction());
		}
	}
	
	public void perform(Object param) {
		if(null == m_content) {
			return;
		}
		m_zoomin.setInitLoc(m_selectclip.getBounds2D());
		m_zoomin.setLayerColor(m_content.getBackground());
		m_zoomin.setTarget(m_owner.getBounds());
		super.perform(param);
	}
}
