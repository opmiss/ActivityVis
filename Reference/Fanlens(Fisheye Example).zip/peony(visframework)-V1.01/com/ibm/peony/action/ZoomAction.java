/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.event.MouseWheelEvent;
import java.awt.geom.Point2D;

import com.ibm.peony.display.Display;
import com.ibm.peony.display.ICamera;

public class ZoomAction extends ActionAdapter {
	
	protected double m_minScale = ICamera.DEFAULT_MIN_SCALE;

	protected double m_maxScale = ICamera.DEFAULT_MAX_SCALE;
	
	private Point2D down = new Point2D.Float();


	public ZoomAction() {
	}

	public ZoomAction(int mask) {
		m_mask = mask;
	}

	public double getMaxScale() {
		return m_maxScale;
	}

	public void setMaxScale(double maxScale) {
		this.m_maxScale = maxScale;
	}

	public double getMinScale() {
		return m_minScale;
	}

	public void setMinScale(double minScale) {
		this.m_minScale = minScale;
	}
	
	public void mouseWheelMoved(MouseWheelEvent e) {
		Display display = (Display) e.getComponent();
		
		if (display.isAnimating()) {
			return;
		}
		
		ICamera c = display.getCamera();
		double center_x = display.getX() + display.getWidth() / 2.0;
		double center_y = display.getY() + display.getHeight() / 2.0;
		display.screenToWorld(new Point2D.Double(center_x, center_y), down);
		
		if(0 < e.getWheelRotation()) {
			
			double zoom = 0.9;
			int status = c.zoom(down, zoom, m_minScale, m_maxScale, true);
			double scale = c.getScale();
			
		} else {
			double zoom = 1.1;
			int status = c.zoom(down, zoom, m_minScale, m_maxScale, true);
		}
		
		m_owner.update();
		display.clearCavas();
		display.repaint();		
	}
}
