/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.Paint;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

import com.ibm.peony.display.RenderClip;
import com.ibm.peony.display.VisualLayer;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.interaction.IElementHighlightRender;
import com.ibm.peony.render.interaction.RangeHighlightRender;

public class SelectAction extends ActionAdapter {

	protected RangeHighlightRender m_render = null;
	
	protected boolean m_keytrigger = false;
	
	protected IElementHighlightRender m_elemrender = null;
	
	protected Point2D start = null;
	
	protected Point2D end = null;
	
	protected Rectangle2D m_range = null;
	
	protected List m_elems = null;
	
	protected RenderClip m_selectclip = null;
	
	/**
	 * Create a new RangeSelectAction.
	 */
	public SelectAction() {
		this(MouseEvent.BUTTON3_DOWN_MASK);
	}

	/**
	 * Create a new RangeSelectAction.
	 * 
	 * @param mouseButton
	 *            the mouse button that should initiate a pan.	 
	 */
	public SelectAction(int mask) {
		m_mask = mask;
		m_bGeneralAction = true;
		m_render = new RangeHighlightRender();
		m_render.setEnable(false);
		start = new Point2D.Double();
		end = new Point2D.Double();
		m_range = new Rectangle2D.Double();
		m_elems = new ArrayList();
		m_selectclip = new RenderClip();
	}
	
	public Object[] getElements() {
		return m_elems.toArray();
	}
	
	public void setFillColor(Paint paint) {
		m_render.setFillPaint(paint);
	}
	
	public void mouseDragged(MouseEvent e) {
		if (m_mask == e.getModifiersEx()) {
			int x = e.getX();
			int y = e.getY();
			if(!m_isdragged) {
				m_isdragged = true;
				if(null != m_elemrender) {
					m_elemrender.clear();
					m_owner.addInteractionRender(m_elemrender);
				}
				m_owner.addInteractionRender(m_render);
				m_range.setFrame(-1, -1, -1, -1);
				m_render.setBounds(-1, -1, -1, -1);
				m_render.setEnable(true);
				m_trigger = true;
				start.setLocation(-1, -1);
				end.setLocation(-1, -1);
				m_owner.getOwner().screenToWorld(e.getPoint(), start);
				
				x = Math.max((int)start.getX(), m_owner.getX() + 1);
				y = Math.max((int)start.getY(), m_owner.getY() + 1);
				
				x = Math.min(x, m_owner.getWidth() + m_owner.getX() - 1);
				y = Math.min(y, m_owner.getHeight() + m_owner.getY() - 1);

				start.setLocation(x, y);
				return;
			}
			
			m_owner.update(m_range);
						
			end.setLocation(x, y);
			m_owner.getOwner().screenToWorld(end, end);
			
			x = Math.max((int)end.getX(), m_owner.getX() + 1);
			y = Math.max((int)end.getY(), m_owner.getY() + 1);
			
			x = Math.min(x, m_owner.getWidth() + m_owner.getX() - 1);
			y = Math.min(y, m_owner.getHeight() + m_owner.getY() - 1);
			
			end.setLocation(x, y);

			m_render.setBoundsFromDiagonal(start, end);
			m_range.setFrameFromDiagonal(start, end);
			m_elems.clear();
			Object[] elems = m_owner.getElements(m_range);
			if(null != elems) {
				for(int i = 0; i < elems.length; ++i) {
					m_elems.add(elems[i]);
				}
//				Collections.addAll(m_elems, elems);
				m_render.setElements(elems);
			}
			if(null != m_elemrender) {
				m_elemrender.setElements(m_elems);
			}
			m_selectclip.expand(5);
			m_owner.update(m_selectclip);
			m_selectclip.reset();
			if(null != elems) {
				for(int i = 0; i < elems.length; ++i) {
					Shape s = getRawShape(elems[i]);
					m_selectclip.union(s.getBounds2D());
				}
			}
			m_owner.update(m_selectclip);
			m_owner.getOwner().repaint();
		}
		super.mouseDragged(e);
	}
	
	public void mouseReleased(MouseEvent e) {
		if(m_trigger) {
			if(m_isdragged) {
				m_isdragged = false;				
				if(!m_elems.isEmpty()) {
					Object[] elems = m_elems.toArray();
					perform(elems);
				} else {
					reset();
				}
				if(null != m_elemrender) {
					m_elemrender.clear();
				}
			}
			m_trigger = false;
			m_render.setEnable(false);
			m_render.setElements(null);
			m_owner.removeInteractionRender(m_render);
			m_owner.update(m_range);
			m_owner.getOwner().repaint();
		}
		super.mouseReleased(e);
	}
	
	public void elemPressed(Object elem, MouseEvent e) {
		if((m_mask | MouseEvent.SHIFT_DOWN_MASK )== e.getModifiersEx()) {
			if(null != m_elemrender) {
				m_elems.add(elem);
				m_elemrender.addElement(elem);
				Shape s = getRawShape(elem);
				if(s != null) {
					Rectangle2D r = s.getBounds2D();
					m_selectclip.union(r);
					m_range.setFrame(m_selectclip.getBounds2D());
					m_render.setBounds(m_selectclip.getBounds2D());
				}
				m_owner.update();
				m_owner.getOwner().repaint();				
			}
		}
		super.elemPressed(elem, e);
	}
	
	public void keyPressed(KeyEvent e) {
		if(KeyEvent.VK_SHIFT == e.getKeyCode()) {
			if(!m_keytrigger) {
				if(null != m_elemrender) {
					m_elems.clear();
					m_elemrender.clear();
					m_selectclip.reset();
					m_owner.addInteractionRender(m_elemrender);
				}
				m_keytrigger = true;
			}
		}
	}
	
	public void keyReleased(KeyEvent e) {
		if(m_keytrigger) {
			m_keytrigger = false;
			if(null != m_elemrender) {
				m_owner.removeInteractionRender(m_elemrender);
			}
			if(!m_elems.isEmpty()) {
				perform(m_elems.toArray());
			} else {
				reset();
			}
			m_owner.update();
			m_owner.getOwner().repaint();
		}
	}
	
	public Rectangle2D getSelectedRange() {
		return m_selectclip.getBounds2D();
	}
	
	public Object[] getSelectedElems() {
		return m_elems.toArray();
	}
	
	protected Shape getRawShape(Object e) {
		VisualLayer layer = (VisualLayer)m_owner;
		IVisualElement ve = (IVisualElement)e;
		IRender r = layer.getRender(ve);
		return r.getRawShape(ve);
	}
}
