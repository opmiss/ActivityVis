/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.ibm.peony.display.Display;
import com.ibm.peony.display.ILayer;
import com.ibm.peony.util.activity.ActivityManager;
import com.ibm.peony.util.activity.IActivity;

public class ActionAdapter implements IAction {
	
	protected boolean m_bEnable = true;
	
	protected boolean m_bGeneralAction = false;
	
	protected ILayer m_owner;
	
	protected int m_mask = MouseEvent.BUTTON3;
	
	protected boolean m_trigger = false;
	
	protected Point m_mousePt = null;
	
	protected boolean m_isdragged = false;
	
	protected List m_activities = null;
	
	public ActionAdapter() {
		m_activities = new ArrayList(0);
	}
	
	public ActionAdapter(IActivity act) {
		m_activities.add(act);
	}
	
	public ActionAdapter(Collection c) {
		m_activities.addAll(c);
	}
	
	public void elemsSelected(Object[] elems) {
	}
	
	public void elemDragged(Object element, MouseEvent e){
		if(m_bGeneralAction) {
			mouseDragged(e);
		}
	}
	public void elemMoved(Object element, MouseEvent e){
		if(m_bGeneralAction) {
			mouseMoved(e);
		}
	}
	public void elemWheelMoved(Object element, MouseWheelEvent e){
		if(m_bGeneralAction) {
			mouseWheelMoved(e);
		}
	}
	public void elemClicked(Object element, MouseEvent e){
		if(m_bGeneralAction) {
			mouseClicked(e);
		}
	}
	public void elemPressed(Object element, MouseEvent e){
		m_mousePt = e.getPoint();
		if(m_bGeneralAction) {
			mousePressed(e);
		}
	}
	public void elemReleased(Object element, MouseEvent e){
		if(m_bGeneralAction) {
			mouseReleased(e);
		}
	}
	public void elemEntered(Object element, MouseEvent e){}
	public void elemExited(Object element, MouseEvent e){}
	
	public void elemKeyPressed(Object element, KeyEvent e) {
		if(m_bGeneralAction) {
			keyPressed(e);
		}
	}
	public void elemKeyReleased(Object element, KeyEvent e) {
		if(m_bGeneralAction) {
			keyReleased(e);
		}
	}
	public void elemKeyTyped(Object element, KeyEvent e){
		if(m_bGeneralAction) {
			keyTyped(e);
		}
	}

	public void mouseClicked(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {
		m_mousePt = e.getPoint();
	}
	public void mouseReleased(MouseEvent e) {
		if(m_isdragged) {
			m_isdragged = false;
		}
	}
	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseDragged(MouseEvent e) {
		m_isdragged = true;
	}
	public void mouseMoved(MouseEvent e) {}
	public void mouseWheelMoved(MouseWheelEvent e) {}
	public void keyTyped(KeyEvent e) {}
	public void keyPressed(KeyEvent e) {}
	public void keyReleased(KeyEvent e) {}
	
	public void setEnable(boolean enable) {
		m_bEnable = enable;
	}
	
	public boolean isEnable() {
		return m_bEnable;
	}
	
	public boolean isGeneralAction() {
		return m_bGeneralAction;
	}
	
	public void setGeneralAction(boolean bGeneral) {
		m_bGeneralAction = bGeneral;
	}
	
	public void setOwner(ILayer layer) {
		m_owner = layer;
	}
	
	public ILayer getOwner() {
		return m_owner;
	}
	
	public void setActionMask(int mask) {
		m_mask = mask;
	}
	
	public int getActionMask() {
		return m_mask;
	}

	public void actionAdded() {}

	public void actionRemoved() {}

	
	public void addActionPerformer(IActivity activity) {
		m_activities.add(activity);
	}

	public void removeActionPerformer(IActivity activity) {
		m_activities.remove(activity);
	}

	public IActivity[] getActionPerformers() {
		return (IActivity[])m_activities.toArray(new IActivity[]{});
	}

	public void removeAll() {
		m_activities.clear();
	}
	
	public void perform(Object param) {
		Display display = m_owner.getOwner();
		ActivityManager manager = display.getActivityManager();
		int size = m_activities.size();
		IActivity act = null;
		for(int i = 0; i < size; ++i) {
			act = (IActivity)m_activities.get(i);
			act.setLayer(m_owner);
			act.setStartTime(System.currentTimeMillis());
			manager.addActivity(act);
		}
	}
	
	public void reset() {
	}
}
