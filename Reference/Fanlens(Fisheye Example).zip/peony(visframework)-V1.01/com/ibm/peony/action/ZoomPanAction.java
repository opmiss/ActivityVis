/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;

import com.ibm.peony.display.Display;
import com.ibm.peony.display.ICamera;
import com.ibm.peony.util.activity.ActivityGroup;
import com.ibm.peony.util.activity.PanAnimator;
import com.ibm.peony.util.activity.ZoomAnimator;

public class ZoomPanAction extends SelectAction {

	private ZoomAnimator m_zoom = null;
	private PanAnimator m_pan = null;
	
	private Point2D m_target = null;
	
	private Point2D m_start = null;
	
	private boolean first = true;
	
	public ZoomPanAction() {
		this(MouseEvent.BUTTON3_DOWN_MASK);
	}

	public ZoomPanAction(int mask) {
		this(mask, false);
	}
	
	public ZoomPanAction(boolean general) {
		this(MouseEvent.BUTTON3_DOWN_MASK, general);
	}
	
	public ZoomPanAction(int mask, boolean general) {
		super(mask);
		m_bGeneralAction = general;
		m_zoom = new ZoomAnimator();
		m_pan = new PanAnimator();
		
		m_zoom.enableZoomAbs(true);
		m_pan.enablePanAbs(false);
		
		ActivityGroup actgroup = new ActivityGroup();
		actgroup.add(m_pan);
		actgroup.add(m_zoom);
		addActionPerformer(actgroup);
		
		m_start = new Point2D.Double();
		m_target = new Point2D.Double();
	}

	public void perform(Object param) {
		
		// the range is in the world coordinate
		m_zoom.setZoomRange(m_range);
		
		// the point is in the world coordinate
		Point2D pt = m_zoom.getZoomPt();
		
		Display display = m_owner.getOwner();
		ICamera c = display.getCamera();
		if(first) {
			double center_x = display.getX() + display.getWidth() / 2.0;
			double center_y = display.getY() + display.getHeight() / 2.0;
			m_start.setLocation(center_x, center_y);
			first = false;
		}
		
		double x = (pt.getX() - m_start.getX()) * c.getScale();
		double y = (pt.getY() - m_start.getY()) * c.getScale();
				
		x = m_start.getX() - x;
		y = m_start.getY() - y;
		
		m_target.setLocation(x, y);
		
		m_pan.setStart(m_start);
		m_pan.setTarget(m_target);
		
		m_start.setLocation(pt);
		
		super.perform(param);
	}
}
