/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.event.MouseEvent;

import com.ibm.peony.display.ILayer;
import com.ibm.peony.display.ILayerManager;

public class CloseLayerAction extends ActionAdapter {

	public CloseLayerAction() {
		this(MouseEvent.BUTTON3_DOWN_MASK, false);
	}

	public CloseLayerAction(boolean general) {
		this(MouseEvent.BUTTON3_DOWN_MASK, general);
	}

	public CloseLayerAction(int mask) {
		this(mask, false);
	}

	public CloseLayerAction(int mask, boolean panOverItem) {
		m_mask = mask;
		m_bGeneralAction = panOverItem;
	}
	
	public void mousePressed(MouseEvent e) {
		if(m_mask == e.getModifiersEx()) {
			if(2 == e.getClickCount()) {
				ILayerManager manager = m_owner.getLayerManager();
				if(null != manager) {
					ILayer next = manager.removeLayer(m_owner);
					if(next != null) {
						manager.focusLayer(next);
					}
					manager.getOwner().clearCavas();
					manager.update();
					manager.getOwner().repaint();
				}
			}
		}
	}
}
