/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.event.MouseEvent;

import com.ibm.peony.util.activity.ZoomAnimator;

public class AnimateZoomAction extends SelectAction {

	private ZoomAnimator m_animator = null;
	
	/**
	 * Create a new zoom control.
	 */
	public AnimateZoomAction() {
		this(MouseEvent.BUTTON3_DOWN_MASK);
	}

	/**
	 * Create a new zoom control.
	 * 
	 * @param mouseButton
	 *            the mouse button that should initiate a zoom. One of
	 */
	public AnimateZoomAction(int mask) {
		super(mask);
		m_animator = new ZoomAnimator();
		m_animator.enableZoomAbs(true);
		addActionPerformer(m_animator);
	}
	
	public void perform(Object param) {
		m_animator.setZoomRange(m_range);
		super.perform(param);
	}
}
