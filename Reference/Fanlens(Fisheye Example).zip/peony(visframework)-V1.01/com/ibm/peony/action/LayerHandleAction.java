/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.Cursor;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;

import com.ibm.peony.display.BaseLayer;
import com.ibm.peony.display.ICamera;
import com.ibm.sdl.util.PropOperator;

public class LayerHandleAction extends ActionAdapter {
	
	private int delta_x = -1;
	private int delta_y = -1;
	
	public LayerHandleAction() {
		m_bGeneralAction = true;
	}
	
	public void mouseClicked(MouseEvent e) {
		
		BaseLayer layer = (BaseLayer)m_owner;
		boolean flag = false;
		if(MouseEvent.BUTTON1 == e.getButton()) {
			if(
				2 == e.getClickCount() && 
				!layer.isLayerHandleActive() && 
				null != layer.getLayerManager()) {
				
				layer.setLayerHandleActive(true);
				flag = true;
			}
		} else if(
				MouseEvent.BUTTON3 == e.getButton() && 
				null != layer.getLayerManager()) {
			if(layer.isLayerHandleActive()) {
				layer.setLayerHandleActive(false);
				flag = true;
			}
		}
		if(flag) {
			layer.update();
			layer.getOwner().repaint();
		}
	}
	
	public void elemDragged(Object element, MouseEvent e) {
		BaseLayer m_layer = (BaseLayer)m_owner;
		
		if(!m_layer.isLayerHandleActive()) {
			return;
		}
		
		Point pt = e.getPoint();
        
        ICamera camera = m_owner.getOwner().getCamera();
        
        AffineTransform f = camera.getInverseTransform();
        
        f.transform(pt, pt);
		
		int x = (int)pt.getX();
		int y = (int)pt.getY();
		
		int xx = m_layer.getX();
		int yy = m_layer.getY();
		int ww = m_layer.getWidth();
		int hh = m_layer.getHeight();
		
		m_layer.update();
		
		int cursor = getCursor(element);
		switch(cursor) {
		case Cursor.N_RESIZE_CURSOR:
			m_layer.setY(y);
			m_layer.setHeight(hh + yy - y);
			break;
		case Cursor.S_RESIZE_CURSOR:
			m_layer.setHeight(y - yy);
			break;
		case Cursor.E_RESIZE_CURSOR:
			m_layer.setWidth(x - xx);
			break;
		case Cursor.W_RESIZE_CURSOR:
			m_layer.setX(x);
			m_layer.setWidth(ww + xx - x);
			break;
		case Cursor.NE_RESIZE_CURSOR:
			m_layer.setWidth(x - xx);
			m_layer.setY(y);
			m_layer.setHeight(hh + yy - y);
			m_layer.setWidth(x - xx);
			break;
		case Cursor.NW_RESIZE_CURSOR:
			m_layer.setY(y);
			m_layer.setHeight(hh + yy - y);
			m_layer.setX(x);
			m_layer.setWidth(ww + xx - x);
			break;
		case Cursor.SE_RESIZE_CURSOR:
			m_layer.setHeight(y - yy);
			m_layer.setWidth(x - xx);
			break;
		case Cursor.SW_RESIZE_CURSOR:
			m_layer.setHeight(y - yy);
			m_layer.setX(x);
			m_layer.setWidth(ww + xx - x);
			break;
		}
		m_layer.doLayout();
		m_layer.update();
		m_layer.getOwner().repaint();
		
		super.mouseDragged(e);
	}
	
	Point m_temp = new Point();
	
	public void mouseDragged(MouseEvent e) {
		BaseLayer m_layer = (BaseLayer)m_owner;
		
		if(!m_layer.isLayerHandleActive()) {
			return;
		}
		
		Point pt = e.getPoint();
        
        ICamera camera = m_owner.getOwner().getCamera();
        
        AffineTransform t = camera.getInverseTransform();
        
        t.transform(pt, pt);
		
		m_temp.x = delta_x;
		m_temp.y = delta_y;
		
//		t.transform(m_temp, m_temp);
		
		m_layer.update();
		
		if(!m_layer.isOffLayer(pt)) {
			m_layer.getOwner().setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			m_layer.setX(pt.x - m_temp.x);
			m_layer.setY(pt.y - m_temp.y);	
		}
		m_layer.update();
		m_layer.doLayout();
		m_layer.getOwner().repaint();
	}
	
	public void mousePressed(MouseEvent e) {
		BaseLayer m_layer = (BaseLayer)m_owner;
		
		if(!m_layer.isLayerHandleActive()) {
			return;
		}
		
		Point pt = e.getPoint();
        
        ICamera camera = m_owner.getOwner().getCamera();
        
        AffineTransform t = camera.getInverseTransform();
        
        t.transform(pt, pt);
				
		delta_x = (int)(pt.getX() - m_layer.getX());
		delta_y = (int)(pt.getY() - m_layer.getY());
	}
	
	public void mouseReleased(MouseEvent e) {
		BaseLayer m_layer = (BaseLayer)m_owner;
		
		if(!m_layer.isLayerHandleActive()) {
			return;
		}
		
		delta_x = -1;
		delta_y = -1;
		
		m_layer.getOwner().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
	
	public void elemEntered(Object element, MouseEvent e) {
		
		BaseLayer m_layer = (BaseLayer)m_owner;
		
		if(!m_layer.isLayerHandleActive()) {
			return;
		}
		
		m_owner.getOwner().setCursor(Cursor.getPredefinedCursor(getCursor(element)));
	}
	
	public void elemExited(Object element, MouseEvent e) {
		BaseLayer m_layer = (BaseLayer)m_owner;
		
		if(!m_layer.isLayerHandleActive()) {
			return;
		}
		
		m_owner.getOwner().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
	}
	
	private int getCursor(Object node) {
		
		Object value = PropOperator.getInstance().getProperty("cursor", node);
		
		return value == null ? Cursor.DEFAULT_CURSOR : ((Integer)value).intValue();
	}
}
