/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.action;

import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;

import com.ibm.peony.interaction.distortion.IDistortion;

public class DistortionAction extends ActionAdapter {
	
	public DistortionAction() {
		this(KeyEvent.SHIFT_DOWN_MASK);
	}
	
	public DistortionAction(int mask) {
		m_bGeneralAction = true;
		m_mask = mask;
	}
	
	public void keyPressed(KeyEvent e) {
		if(null == m_owner) {
			return;
		}
		if(m_mask == e.getModifiersEx()) {
			IDistortion distortion = m_owner.getDistortion();
	        if (distortion != null) {
	        	distortion.setEnabled(true);
	        }
	        m_trigger = true;
		}
	}
	
	public void keyReleased(KeyEvent e) {
		if(null == m_owner) {
			return;
		}
		if(m_trigger) {
			IDistortion distortion = m_owner.getDistortion();
	        if (distortion != null) {
	        	distortion.setEnabled(false);
	        	m_owner.update(distortion.getBounds());
	        	m_owner.getOwner().repaint();
	        	System.gc();
	        }
	        m_trigger = false;
		}
	}
	
	public void mouseMoved(MouseEvent e) {
		if(null == m_owner) {
			return;
		}
		
		if(m_mask != e.getModifiersEx()) return;
		
		IDistortion distortion = m_owner.getDistortion();
        if (distortion != null && distortion.isEnabled()) {
        	
        	Point pt = e.getPoint();
        	m_owner.getOwner().screenToWorld(pt, pt);
        	
        	m_owner.update(distortion.getBounds());
        	distortion.setLens((float)pt.getX(), (float)pt.getY());
        	m_owner.update(distortion.getBounds());
        	m_owner.getOwner().repaint();
        }
	}
	
	public void mouseWheelMoved(MouseWheelEvent e) {
		if(null == m_owner) {
			return;
		}
		IDistortion distortion = m_owner.getDistortion();
		if (distortion != null && distortion.isEnabled()) {
			float height = distortion.getFocusHeight() + e.getWheelRotation();
			distortion.setFocusHeight(height);
			m_owner.update(distortion.getBounds());
			m_owner.getOwner().repaint();
		}		
	}
}
