package com.ibm.peony.interaction.distortion;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import com.ibm.peony.util.math.Translation;

public class Fisheye extends VisualLens implements IDistortion {

	protected float m_focusRadius = 0;
	protected Line2D m_tempLine = null;
	protected float m_tol = 1f;
	
	public Fisheye() {
		this(100, 0, 9);
	}
	
	public Fisheye(float lensR, float focusR, float focalHeight) {
		setLensRadius(lensR);
		setFocusRadius(focusR);
		setFocusHeight(focalHeight);
		m_tempLine = new Line2D.Double();
	}
	
	public void setFocusRadius(float radius) {
		m_focusRadius = radius;
	}
	
	public float getFocusRadius() {
		return m_focusRadius;
	}
	
	public boolean isTransformed(float x, float y) {
		return isEnabled()
				&& DistortionUtil.compareDist(m_radius, x - m_lensX, y - m_lensY) > 0;
	}
	
	public boolean isTransformed(double x, double y) {
		return isEnabled() && isTransformed((float) x, (float) y);
	}

	public boolean isTransformed(Point2D p) {
		return isEnabled() && isTransformed(p.getX(), p.getY());
	}

	public boolean isTransformed(Rectangle2D bounds) {
		return isEnabled() && bounds.intersects(getBounds());
	}

	public boolean isTransformed(Shape s) {
		return isEnabled() && s.intersects(getBounds());
	}
	
	public Font transform(Font f, float x, float y) {
		float size = f.getSize2D();
		f = f.deriveFont(size * getScale(x, y));
		return f;
	}

	public Shape transform(Shape s) {
		if (!isTransformed(s))
			return s;

		GeneralPath p = new GeneralPath();
		float[] coords = { 0, 0, 0, 0, 0, 0 };
		float first_x = 0;
		float first_y = 0;
		float prev_x = 0;
		float prev_y = 0;
		for (PathIterator iter = s.getPathIterator(null, m_tol
				/ getMaximumScale()); !iter.isDone(); iter.next()) {
			switch (iter.currentSegment(coords)) {
			case PathIterator.SEG_MOVETO:
				prev_x = coords[0];
				prev_y = coords[1];
				first_x = prev_x;
				first_y = prev_y;
				transform(coords, 1);
				p.moveTo(coords[0], coords[1]);
				break;
			case PathIterator.SEG_LINETO:
				float x = coords[0];
				float y = coords[1];
				divide(prev_x, prev_y, x, y, p);
				prev_x = x;
				prev_y = y;
				break;
			case PathIterator.SEG_CLOSE: 
				divide(prev_x, prev_y, first_x, first_y, p);
				p.closePath();
				break;
			}
		}
		return p;
	}
	
	public Point2D inversTransform(Point2D src, Point2D dst) {
		float scale = getScale((float) src.getX(), (float) src.getY());
		
		if(null == dst) {
			dst = new Point2D.Float();
		}
		
		if (scale != 1) {
			dst.setLocation(inversTransformX(
					(float) src.getX(), scale), inversTransformY(
					(float) src.getY(), scale));
		} else if (dst != src) {
			dst.setLocation(src);
		}
		
		return dst;
	}

	public Point2D transform(Point2D src, Point2D dst) {
		
		float scale = getScale((float) src.getX(), (float) src.getY());
		
		if(null == dst) {
			dst = new Point2D.Float();
		}
		
		if (scale != 1) {
			dst.setLocation(transformX(
					(float) src.getX(), scale), transformY(
					(float) src.getY(), scale));
		} else if (dst != src) {
			dst.setLocation(src);
		}
		
		return dst;
	}

	public void transform(float[] coords, int npoints) {
		if (!isEnabled())
			return;
		for (int i = 0; i < npoints; i++) {
			float scale = getScale(coords[2 * i], coords[2 * i + 1]);
			if (scale != 1) {
				coords[2 * i] = transformX(coords[2 * i], scale);
				coords[2 * i + 1] = transformY(coords[2 * i + 1], scale);
			}
		}
	}
	
	public float transformX(float x, float scale) {
		if (isEnabled()) {
			return (x - m_lensX) * scale + m_lensX + 1e-8F;
		}
		return x;
	}

	public float transformY(float y, float scale) {
		if (isEnabled())
			return (y - m_lensY) * scale + m_lensY + 1e-8F;
		return y;
	}
	
	public float inversTransformX(float x, float scale) {
		if (isEnabled()) {
			return (x - m_lensX) / scale + m_lensX + 1e-8F;
		}	
		return x;
	}
	
	public float inversTransformY(float y, float scale) {
		if (isEnabled()) {
			return (y - m_lensY) / scale + m_lensY + 1e-8F;
		}	
		return y;
	}

	public Image transform(BufferedImage image) {
		if (null == image) {
			return null;
		}

		int imgH = image.getHeight();
		int imgW = image.getWidth();

		BufferedImage img = new BufferedImage(imgW, imgH,
				BufferedImage.TYPE_INT_ARGB);
		Graphics g = img.getGraphics();
		g.drawImage(image, 0, 0, null);

		int start_x = Translation.atoi(m_lensX - m_radius);
		int start_y = Translation.atoi(m_lensY - m_radius);
		if (start_x < 0) {
			start_x = 0;
		}
		if (start_y < 0) {
			start_y = 0;
		}
		int end_x = Translation.atoi(start_x + 2 * m_radius);
		if (end_x > imgW) {
			end_x = imgW;
		}
		int end_y = Translation.atoi(start_y + 2 * m_radius);
		if (end_y > imgH) {
			end_y = imgH;
		}

		for (int x = start_x; x < end_x; x++) {
			for (int y = start_y; y < end_y; y++) {

				if (!isTransformed(x, y))
					continue;

				float scale = 1 / getScale(x, y);
				int xx = Translation.atoi(transformX(x, scale));
				int yy = Translation.atoi(transformY(y, scale));
				if (x != xx || y != yy) {
					// System.out.println("scale = " + scale);
					// System.out.println("x = " + x + ", xx = " + xx);
					// System.out.println("y = " + y + ", yy = " + yy);
					img.setRGB(x, y, image.getRGB(xx, yy));
				}
			}
		}
		// this.setLensRadius(lensRadius / 1.5F);
		return img;
	}
	
	public float getScale(float x, float y) {
		if (!isEnabled()) {
			return 1;
		}

		return (float) getScale(x, y, 0);
	}

	public double getScale(float x, float y, int mode) {
		double scale = 1.0;
		float halfWidth = 300;
		halfWidth = DistortionUtil.distance(halfWidth, halfWidth);

		double dist = DistortionUtil.distance(x, y);
		dist = dist / halfWidth;

		if (mode == 0) {
			float height = height(x, y);
			return MAX_LENS_HEIGHT / (MAX_LENS_HEIGHT - height);
		} else if (mode == 1) {
			double A = 1;
			double C = 2;
			scale = 1 + A / (1 + C * dist * dist);
		} else if (mode == 2) {
			double d = 3;
			scale = (d + 1) / (d * dist + 1);
		}
		if (scale < 1) {
			scale = 1;
		}
		return scale;
	}
	
	public float getMaximumScale() {
		return MAX_LENS_HEIGHT / (MAX_LENS_HEIGHT - m_height);
	}
	
	public float height(float x, float y) {
		float dx = (x - m_lensX);
		float dy = (y - m_lensY);
		float dist = (float)Math.sqrt(dx * dx + dy * dy);
		return height(dist);
	}
	
	public float height(float dist) {
		if (m_height == 0) {
			return 0;
		}

		float realFocus = m_height / getMaximumScale();
		if (dist > m_radius) {
			return Math.min(m_height * DistortionUtil.fisheyeLinear(1), m_height);
		} else if (dist < realFocus) {
			return Math.min(m_height * DistortionUtil.fisheyeLinear(0), m_height);
		} else {
			float t = (dist - realFocus) / (m_radius - realFocus);
			return Math.min(m_height * DistortionUtil.fisheyeLinear(t), m_height);
		}
	}
	
	/**
	 * Returns the tolerance.
	 * 
	 * @return float
	 */
	public float getTolerance() {
		return m_tol;
	}

	/**
	 * Sets the tolerance.
	 * 
	 * @param tolerance
	 *            The tolerance to set
	 */
	public void setTolerance(float tolerance) {
		if (tolerance < 1)
			tolerance = 1;
		this.m_tol = tolerance;
	}
	
	/**
	 * Subdivide a line segment.
	 * 
	 * @param x1
	 *            X coordinate of first point
	 * @param y1
	 *            Y coordinate of first point
	 * @param x2
	 *            X coordinate of second point
	 * @param y2
	 *            Y coordinate of second point
	 * @param p
	 *            GeneralPath to fill
	 */
	private void divide(float x1, float y1, float x2, float y2, GeneralPath p) {

		Line2D.Double l;
		// l = tmpLine;
		// double t = System.currentTimeMillis();
		m_tempLine.setLine(x1, y1, x2, y2);
		// l = clip(tmpLine, lensX, lensY, lensRadius);
		l = (Line2D.Double)DistortionUtil.clip(m_tempLine, m_bounds);
		// for (int i = 1; i < 1000; i++) {
		// tmpLine.setLine(x1, y1, x2, y2);
		// l = clip(tmpLine, bounds);
		// l = clip(tmpLine, lensX, lensY, lensRadius);
		// }
		// t = System.currentTimeMillis() - t;
		// System.out.println("time = " + t);
		// l = clip(tmpLine, bounds);
		if (l == null) {
			p.lineTo(x2, y2);
			return;
		}

		if (l.x1 != x1 || l.y1 != y1) {
			x1 = (float) l.x1;
			y1 = (float) l.y1;

			p.lineTo(x1, y1);
		}
		float scale = getScale(x1, y1);
		float tx1 = transformX(x1, scale);
		float ty1 = transformY(y1, scale);
		scale = getScale((float) l.x2, (float) l.y2);
		float tx2 = transformX((float) l.x2, scale);
		float ty2 = transformY((float) l.y2, scale);

		subdivideSegment(x1, y1, tx1, ty1, (float) l.x2, (float) l.y2, tx2,
				ty2, p, 0);
		if (l.x2 != x2 || l.y2 != y2) {
			p.lineTo(x2, y2);
		}
	}
	
	private void subdivideSegment(float x1, float y1, float tx1, float ty1,
			float x2, float y2, float tx2, float ty2, GeneralPath p, int depth) {

		if (depth > 20)
			throw new RuntimeException("too deep in subdivideSegment");
		if (x1 == x2 && y1 == y2) {
			p.lineTo(tx2, ty2);
			return;
		}
		if (m_radius <= m_focusRadius) {
			p.lineTo(tx1, ty1);
			p.lineTo(tx2, ty2);
			p.lineTo(x2, y2);
			return;
		}

		float xm = (x1 + x2) / 2;
		float ym = (y1 + y2) / 2;
		float scale = getScale(xm, ym);
		float txm = transformX(xm, scale);
		float tym = transformY(ym, scale);

		// subdivide in small pieces to avoid losing the compression portion
		float maxLen = (m_radius - m_focusRadius) / 3;
		if ((DistortionUtil.distance2(x2 - x1, y2 - y1) > maxLen * maxLen)
				|| (DistortionUtil.distance2(txm - (tx1 + tx2) / 2, tym - (ty1 + ty2) / 2) > m_tol)) {
			subdivideSegment(x1, y1, tx1, ty1, xm, ym, txm, tym, p, depth + 1);
			subdivideSegment(xm, ym, txm, tym, x2, y2, tx2, ty2, p, depth + 1);
		} else {
			p.lineTo(tx2, ty2);
		}
	}
}
