/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.interaction.distortion;

import java.awt.geom.Rectangle2D;

public interface IVisualLens {
    
	/**
	 * Returns the height of the focus area.
	 * 
	 * @return the height of the focus area
	 */
	public abstract float getFocusHeight();

	/**
	 * Sets the height of the focus area.
	 * 
	 * @param h
	 *            the height of the focus area.
	 */
	public abstract void setFocusHeight(float h);
    
    /**
     * Returns whether this magic lens is enabled.
     * 
     * @return whether this magic lens is enabled.
     */
    public abstract boolean isEnabled();
    
    /**
     * Sets the enabled state of the magic lens.
     * 
     * @param set the enabled state to set
     */
    public abstract void setEnabled(boolean set); 
    
    /**
     * Returns the bounds of the transformed coordinates.
     * Coordintates outside these bounds are not transformed.
     * 
     * @return the bounds of the transformed coordinates.
     */
    public abstract Rectangle2D getBounds();

    /**
     * Sets for focus position
     *
     * @param x X coordinate of the position
     * @param y X coordinate of the position
     */
    public abstract void setLens(float x, float y);

    /**
     * Returns the lens X center position.
     *
     * @return float
     */
    public abstract float getLensX();

    /**
     * Returns the lens Y center position.
     *
     * @return float
     */
    public abstract float getLensY();

    /**
     * Sets the lensX.
     *
     * @param x The lest X to set
     */
    public abstract void setLensX(float x);

    /**
     * Sets the lensY.
     *
     * @param y The lens Y to set
     */
    public abstract void setLensY(float y);
    
    /**
     * Sets the lens radius.
     * 
     * @param radius the new radius.
     */
    public abstract void setLensRadius(float radius);
    
    /**
     * Returns the lens radius.
     * 
     * @return the lens radius.
     */
    public abstract float getLensRadius();        
}
