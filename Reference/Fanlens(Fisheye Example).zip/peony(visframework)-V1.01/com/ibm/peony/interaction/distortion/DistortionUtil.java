package com.ibm.peony.interaction.distortion;

import java.awt.Shape;
import java.awt.geom.Line2D;
import java.awt.geom.PathIterator;
import java.awt.geom.Rectangle2D;

public class DistortionUtil {

	private static Line2D.Double m_line = new Line2D.Double();
	
	public static float distance(float dx, float dy) {
		return (float) Math.sqrt((dx * dx) + (dy * dy));
	}
	
	public static float distance2(float dx, float dy) {
		return dx * dx + dy * dy;
	}

	public static int compareDist(float dist, float dx, float dy) {
		float d = dist * dist - (dx * dx) - (dy * dy);
		if (d < 0) {
			return -1;
		} else if (d == 0) {
			return 0;
		} else {
			return 1;
		}
	}
	
//	TODO : -------------------------- fisheye algorithms -----------------------------------
	public static float fisheyePolyfocal(float t) {
		double A = 1;
		double C = 16;
		return (float) (A / (1 + A + C * t * t));
	}
	
	public static float fisheyeCos(float t) {
		return (float) Math.cos(t * Math.PI / 2);
	}
	
	public static float fisheyeGuass(float t) {
		double RO = 0.1;
		return (float) Math.exp((-t * t) / RO);
	}

	public static float fisheyeInverseSin(float t) {
		return 1 - (float) Math.sin(t);
	}
	
	public static float fisheyeLinear(float t) {
		return 1 - t;
	}
	
	public static float fisheyePolynome(float t) {
		return 1 - (-0.75F * t * t * t + 1.5F * t * t + 0.25F * t);
	}
	
	public static float fisheyeSphere(float t) {
		double d = 9;
		if (1 == t) {
			return 0;
		}
		return (float) (d * (1 - t) * 10 / (d + 1) / 9);
	}
	
	public static float fisheyeInverse(float t) {
		return 1 - t;
	}
	
//	TODO : -------------------------- clip to the shape of the lens -----------------------------------
	
	public static Line2D clip(Line2D.Double l, double x, double y, double r) {
		double d = l.ptLineDist(x, y);
		if (d >= r)
			return null;
		double L = Math.sqrt(r * r - d * d);

		if (l.x1 == l.x2) {
			l.y1 = y - L;
			l.y2 = y + L;
		} else if (l.y1 == l.y2) {
			l.x1 = x - L;
			l.x2 = x + L;
		}
		return l;
	}
	
	public static Line2D clip(double x1, double y1, double x2, double y2, Rectangle2D bounds) {
		
		m_line.setLine(x1, y1, x2, y2);
		
		int out1 = bounds.outcode(x1, y1);
		int out2 = bounds.outcode(x2, y2);
		if (out1 != 0 && out2 != 0 && (out1 & out2) != 0)
			return null;
		
		int cnt = 0;
		while (out1 != 0) {
			if (cnt++ > 2)
				throw new RuntimeException("too many loops in clip1");
			if ((out1 & out2) != 0) {
				return null;
			}
			if ((out1 & (Rectangle2D.OUT_LEFT | Rectangle2D.OUT_RIGHT)) != 0) {
				double x = bounds.getX();
				if ((out1 & Rectangle2D.OUT_RIGHT) != 0) {
					x += bounds.getWidth();
				}
				y1 = y1 + (x - x1) * (y2 - y1) / (x2 - x1);
				x1 = x;
			} else {
				double y = bounds.getY();
				if ((out1 & Rectangle2D.OUT_BOTTOM) != 0) {
					y += bounds.getHeight();
				}
				x1 = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
				y1 = y;
			}
			out1 = bounds.outcode(x1, y1);
		}

		cnt = 0;
		while (out2 != 0) {
			if (cnt++ > 2)
				throw new RuntimeException("too many loops in clip2");
			if ((out2 & (Rectangle2D.OUT_LEFT | Rectangle2D.OUT_RIGHT)) != 0) {
				double x = bounds.getX();
				if ((out2 & Rectangle2D.OUT_RIGHT) != 0) {
					x += bounds.getWidth();
				}
				y2 = y2 + (x - x2) * (y2 - m_line.y1) / (x2 - m_line.x1);
				x2 = x;
			} else {
				double y = bounds.getY();
				if ((out2 & Rectangle2D.OUT_BOTTOM) != 0) {
					y += bounds.getHeight();
				}
				x2 = x2 + (y - y2) * (x2 - m_line.x1) / (y2 - m_line.y1);
				y2 = y;
			}
			out2 = bounds.outcode(x2, y2);
		}

		return new Line2D.Double(x1, y1, x2, y2);
	}
	
	public static Line2D clip(Line2D line, Rectangle2D bounds) {
		double x1 = line.getX1();
		double y1 = line.getY1();
		double x2 = line.getX2();
		double y2 = line.getY2();
		int out1 = bounds.outcode(x1, y1);
		int out2 = bounds.outcode(x2, y2);
		if (out1 != 0 && out2 != 0 && (out1 & out2) != 0)
			return null;

		int cnt = 0;
		while (out1 != 0) {
			if (cnt++ > 2)
				throw new RuntimeException("too many loops in clip1");
			if ((out1 & out2) != 0) {
				return null;
			}
			if ((out1 & (Rectangle2D.OUT_LEFT | Rectangle2D.OUT_RIGHT)) != 0) {
				double x = bounds.getX();
				if ((out1 & Rectangle2D.OUT_RIGHT) != 0) {
					x += bounds.getWidth();
				}
				y1 = y1 + (x - x1) * (y2 - y1) / (x2 - x1);
				x1 = x;
			} else {
				double y = bounds.getY();
				if ((out1 & Rectangle2D.OUT_BOTTOM) != 0) {
					y += bounds.getHeight();
				}
				x1 = x1 + (y - y1) * (x2 - x1) / (y2 - y1);
				y1 = y;
			}
			out1 = bounds.outcode(x1, y1);
		}

		cnt = 0;
		while (out2 != 0) {
			if (cnt++ > 2)
				throw new RuntimeException("too many loops in clip2");
			if ((out2 & (Rectangle2D.OUT_LEFT | Rectangle2D.OUT_RIGHT)) != 0) {
				double x = bounds.getX();
				if ((out2 & Rectangle2D.OUT_RIGHT) != 0) {
					x += bounds.getWidth();
				}
				y2 = y2 + (x - x2) * (y2 - line.getY1()) / (x2 - line.getX1());
				x2 = x;
			} else {
				double y = bounds.getY();
				if ((out2 & Rectangle2D.OUT_BOTTOM) != 0) {
					y += bounds.getHeight();
				}
				x2 = x2 + (y - y2) * (x2 - line.getX1()) / (y2 - line.getY1());
				y2 = y;
			}
			out2 = bounds.outcode(x2, y2);
		}
		line.setLine(x1, y1, x2, y2);
		return line;
	}

	public static Line2D clip(Line2D l, Shape shape) {

		if (shape instanceof Rectangle2D) {
			return clip(l, (Rectangle2D) shape);
		}
		if (!shape.contains(l.getX2(), l.getY2()))
			return l;
		double[] coords = new double[6];
		double prev_x = 0;
		double prev_y = 0;
		for (PathIterator iter = shape.getPathIterator(null, 1); !iter.isDone();) {
			switch (iter.currentSegment(coords)) {
			case PathIterator.SEG_LINETO:
				if (l.intersectsLine(prev_x, prev_y, coords[0], coords[1])) {
				}
			// fall through
			case PathIterator.SEG_MOVETO:
				prev_x = coords[0];
				prev_y = coords[1];
				break;
			}
		}
		return l;
	}

}
