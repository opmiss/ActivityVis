/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.interaction.distortion;

import java.awt.Font;
import java.awt.Image;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;

public interface IDistortion extends IVisualLens {

	public static final String PROPERTY_FOCUS_HEIGHT = "focusHeight";
	
	/**
	 * Transforms the specified shape, returning its deformation through the
	 * Fisheye.
	 * 
	 * @param s
	 *         the initial shape
	 * 
	 * @return the transformed shape
	 */
	public Shape transform(Shape s);

	public Font transform(Font f, float x, float y);
	
	public Point2D inversTransform(Point2D src, Point2D dst);

	public Point2D transform(Point2D src, Point2D dst);

	public void transform(float[] coords, int npoints);

	public Image transform(BufferedImage image);
	
//	public void refreshInfoDensityMap(int[] infoDensityMap, int peak);
}
