/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.interaction.distortion;

import java.awt.geom.Rectangle2D;

public class VisualLens implements IVisualLens {
	
	public static final float MAX_LENS_HEIGHT = 10.0f;
	
    protected boolean bEnabled = false;;
    protected float m_lensX = 0;
    protected float m_lensY = 0;
    protected float m_radius = 100;
    protected transient Rectangle2D.Float m_bounds = new Rectangle2D.Float();
	protected float m_height = MAX_LENS_HEIGHT;
	
    
    public VisualLens() {
        m_bounds = new Rectangle2D.Float();
    }
    
	/**
	 * Returns the focal height.
	 * 
	 * @return float
	 */
	public float getFocusHeight() {
		return m_height;
	}

	/**
	 * Sets the focal height.
	 * 
	 * @param focalHeight
	 *            The focal height to set
	 */
	public void setFocusHeight(float height) {
		if (height < 0) {
			height = 0;
		} else if (height > MAX_LENS_HEIGHT) {
			height = MAX_LENS_HEIGHT;
		}

		this.m_height = height;
	}
    
    public boolean isEnabled() {
        return bEnabled;
    }
    
    public void setEnabled(boolean enabled) {
        if (this.bEnabled == enabled) return;
        this.bEnabled = enabled;
    }

    public Rectangle2D getBounds() {
    	double d = 2 * m_radius;
    	m_bounds.setRect(
    			m_lensX - m_radius,
    			m_lensY - m_radius, d, d);
        return m_bounds;
    }
    
    public void setLens(float x, float y) {
        m_lensX = x;
        m_lensY = y;
    }

    public float getLensX() {
        return m_lensX;
    }

    public float getLensY() {
        return m_lensY;
    }

    public void setLensX(float focusX) {
        this.m_lensX = focusX;
    }

    public void setLensY(float focusY) {
        this.m_lensY = focusY;
    }

    public float getLensRadius() {
        return m_radius;
    }
    
    public void setLensRadius(float radius) {
        this.m_radius = radius;
    }
}
