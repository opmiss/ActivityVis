/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.layout;

import java.io.Serializable;


public interface ILayout extends Serializable {
	
	/**
	 * Get the name of the layout
	 * @return layout name
	 */
	public String getName();
	
	/**
	 * Get the discription of the layout
	 * @return layout discription
	 */
	public String getDescription();
	
	/**
	 * Layout algorithm of the visual data
	 * <br>
	 * The layer parameter is used to get display geometry 
	 * info such as the width and height of the layer related 
	 * display, and is also used to get the visual data that 
	 * related to the specified layer from the visual model. 
	 * 
	 * @param data
	 */
	public void layout(Object context);
	
	public void reset();
	
}
