package com.ibm.peony.layout;

import com.ibm.sdl.data.hierarchy.implv1.HierarchicalGraph;

public interface IHGraphLayout extends ILayout {

	public HierarchicalGraph getHierarchicalGraph();
	
//	public int getCurrentHeight();
//	
//	public int getMaxHeight();
	
}
