/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.util.Comparator;
import java.util.Map;

import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.ITheme;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.util.filter.IItemFilter;

public interface IVisualLayer extends ILayer {
	
    public Object[] getNodes(IItemFilter filter, Comparator c);
    
    public IEdge[] getEdges(IItemFilter filter, Comparator c);
    
    public Object[] getRows(IItemFilter filter, Comparator c);
    
    public Object[] getElements(IItemFilter filter, Comparator comparator);
	
	/**
	 * Register the default node render
	 * <br>
	 * @param m_render default node render
	 */
	public void registerNodeRender(IRender m_render);
	
	/**
	 * Register the default edge render
	 * <br>
	 * @param m_render default edge render
	 */
	public void registerEdgeRender(IRender m_render);
	
	/**
	 * Register the render to a specified visual node
	 * <br>
	 * @param e the specified visual element
	 * @param render the render used for the visual elemnt
	 */
	public void registerRender(IVisualElement e, IRender render);
	
	/**
	 * Get all the node renders in a map structure
	 * <br>
	 * @return the node render mapping info
	 */
	public Map getNodeRenders();
	
	/**
	 * Get all the edge renders in a map structure
	 * <br>
	 * @return the edge render mapping info
	 */
	public Map getEdgeRenders();
	
	/**
	 * Get the default node render
	 * @return the default node render
	 */
	public IRender getDefaultNodeRender();
	
	/**
	 * Get the default node theme
	 * @return the default node theme
	 */
	public ITheme getDefaultNodeTheme();
	
	/**
	 * Get the default edge render
	 * @return the default edge render
	 */
	public IRender getDefaultEdgeRender();
	
	/**
	 * Get the default edge theme
	 * @return the default edge theme
	 */
	public ITheme getDefaultEdgeTheme();
	
	/**
	 * Register the node render to a specified type
	 * <br>
	 * 
	 * The type info comes from the user data and is assigned 
	 * by the users. peony use IType interface to provide a 
	 * getType() method to classify the different data:
	 * 
	 * type = ((IType)VisualElement.getDataObject()).getType()
	 * 
	 * @param type the specified type
	 * @param r the render used for that type
	 * 
	 */
	public void registerNodeRender(String type, IRender r);

	/**
	 * Register the edge render to a specified type
	 * <br>
	 * 
	 * The type info comes from the user data and is assigned 
	 * by the users. peony use IType interface to provide a 
	 * getType() method to classify the different data:
	 * 
	 * type = ((IType)VisualElement.getDataObject()).getType()
	 * 
	 * @param type the specified type
	 * @param r the render used for that type
	 * 
	 */
	public void registerEdgeRender(String type, IRender r);
	
	/**
	 * Register default node theme
	 * 
	 * @param theme default node theme
	 */
	public void registerNodeTheme(ITheme theme);
	
	/**
	 * Register the theme for the node elements which are in 
	 * the specified type
	 * <br>
	 * 
	 * The type info comes from the user data and is assigned 
	 * by the users. peony use IType interface to provide a 
	 * getType() method to classify the different data:
	 * 
	 * type = ((IType)VisualElement.getDataObject()).getType()

	 * @param type the specified type
	 * @param theme the theme for that type
	 */
	public void registerNodeTheme(String type, ITheme theme);
	
	/**
	 * Register the default edge theme
	 * 
	 * @param theme default edge theme
	 */
	public void registerEdgeTheme(ITheme theme);
	
	/**
	 * Register the theme for the edge elements which are in 
	 * the specified type
	 * 
	 * @param type the specified type
	 * @param theme the theme for that type
	 */
	public void registerEdgeTheme(String type, ITheme theme);
	
	/**
	 * Register the theme for a specified visual element
	 * <br>
	 * @param e the specified visual element
	 * @param theme the theme for the element
	 */
	public void registerTheme(IVisualElement e, ITheme theme);
	
	public void setPickComparator(Comparator c);
	
	public Comparator getPickComparator();
	
	public void setPaintComparator(Comparator c);
	
	public Comparator getPaintComparator();
	
	public void update(Object elem);
	
	public void setClipFilter(IItemFilter filter);

	public IItemFilter getClipFilter();
	
	public void setPickingFilter(IItemFilter filter);
	
	public IItemFilter getPickingFilter();
}
