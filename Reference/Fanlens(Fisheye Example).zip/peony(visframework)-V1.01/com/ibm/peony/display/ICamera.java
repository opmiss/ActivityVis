/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;

public interface ICamera {
	
	public static final double DEFAULT_MIN_SCALE = 1E-3;

	public static final double DEFAULT_MAX_SCALE = 75;

	// zoom status
	public static final int ZOOM_DONE = 0;
	public static final int ZOOM_REACH_MIN = 1;
	public static final int ZOOM_REACH_MAX = 2;
	public static final int ZOOM_NONE = 3;

	public boolean isTransforming();
	
	/**
	 * Set the 2D AffineTransform (e.g., scale, shear, pan, rotate) used by this
	 * display before rendering visual items. The provided transform must be
	 * invertible, otherwise an expection will be thrown. For simple panning and
	 * zooming transforms, you can instead use the provided pan() and zoom()
	 * methods.
	 */
	public void setTransform(AffineTransform transform) throws NoninvertibleTransformException;

	/**
	 * Returns a reference to the AffineTransformation used by this Display.
	 * Changes made to this reference WILL corrupt the state of this display.
	 * Use setTransform() to safely update the transform state.
	 * 
	 * @return the AffineTransform
	 */
	public AffineTransform getTransform();

	/**
	 * Returns a reference to the inverse of the AffineTransformation used by
	 * this display. Direct changes made to this reference WILL corrupt the
	 * state of this display.
	 * 
	 * @return the inverse AffineTransform
	 */
	public AffineTransform getInverseTransform();
	
	
	public AffineTransform getOringnalTransform();
	
	/**
	 * Gets the world co-ordinate corresponding to the given screen
	 * co-ordinate.
	 * 
	 * @param screen
	 *            the screen co-ordinate to transform
	 * @param abs
	 *            a reference to put the result in. If this is the same object
	 *            as the screen co-ordinate, it will be overridden safely. If
	 *            this value is null, a new Point2D instance will be created and
	 *            returned.
	 * @return the point in absolute co-ordinates
	 */
	public Point2D screenToWorld(Point2D screen, Point2D abs);
	
	public Point2D worldToScreen(Point2D world, Point2D screen);

	/**
	 * Returns the current scale (zoom) value.
	 * 
	 * @return the current scale. This is the scaling factor along the
	 *         x-dimension, so be careful when using this value in rare
	 *         non-uniform scaling cases.
	 */
	public double getScale();

	/**
	 * Returns the x-coordinate of the top-left of the display, in world
	 * co-ordinates.
	 * 
	 * @return the x co-ord of the top-left corner, in absolute coordinates
	 */
	public double getDisplayX();

	/**
	 * Returns the y-coordinate of the top-left of the display, in world
	 * co-ordinates.
	 * 
	 * @return the y co-ord of the top-left corner, in absolute coordinates
	 */
	public double getDisplayY();

	/**
	 * Pans the view provided by this display in screen coordinates.
	 * 
	 * @param dx
	 *            the amount to pan along the x-dimension, in pixel units
	 * @param dy
	 *            the amount to pan along the y-dimension, in pixel units
	 */
	public void pan(double dx, double dy);
	
	/**
	 * Pans the view provided by this display in the world coordinates.
	 * 
	 * @param dx
	 *            the amount to pan along the x-dimension, in absolute co-ords
	 * @param dy
	 *            the amount to pan along the y-dimension, in absolute co-ords
	 */
	public void panAbs(double dx, double dy);

	/**
	 * Pans the display view to center on the provided point in screen (pixel)
	 * coordinates.
	 * 
	 * @param p
	 *            the point to center on, in screen co-ords
	 */
	public void panTo(Point2D p);
	
	/**
	 * Pans the display view to center on the provided point in the world coordinates.
	 * 
	 * @param p
	 *            the point to center on, in absolute co-ords
	 */
	public void panToAbs(Point2D p);


	/**
	 * Zooms the view provided by this display by the given scale, anchoring the
	 * zoom at the specified point in screen coordinates.
	 * 
	 * @param p
	 *            the anchor point for the zoom, in screen coordinates
	 * @param scale
	 *            the amount to zoom by
	 */
	public void zoom(final Point2D p, double scale);

	/**
	 * Zooms the view provided by this display by the given scale, anchoring the
	 * zoom at the specified point in absolute coordinates.
	 * 
	 * @param p
	 *            the anchor point for the zoom, in the world
	 *            co-ordinates
	 * @param scale
	 *            the amount to zoom by
	 */
	public void zoomAbs(final Point2D p, double scale);

	public int zoom(final Point2D p, double scale, double min, double max, boolean abs);
	
	/**
	 * Rotates the view provided by this display by the given angle in radians,
	 * anchoring the rotation at the specified point in screen coordinates.
	 * 
	 * @param p
	 *            the anchor point for the rotation, in screen coordinates
	 * @param theta
	 *            the angle to rotate by, in radians
	 */
	public void rotate(final Point2D p, double theta);
	
	/**
	 * Rotates the view provided by this display by the given angle in radians,
	 * anchoring the rotation at the specified point in absolute coordinates.
	 * 
	 * @param p
	 *            the anchor point for the rotation, in the world co-ordinates
	 * @param theta
	 *            the angle to rotation by, in radians
	 */
	public void rotateAbs(final Point2D p, double theta);
	
	public void lookAt(Display m_display);
	
	public void reset();
}
