/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.FontMetrics;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.JComponent;

import com.ibm.peony.geometry.IVisualEdge;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.ITheme;
import com.ibm.peony.util.InfoVisUtil;
import com.ibm.sdl.data.DataEvent;
import com.ibm.sdl.data.IData;
import com.ibm.sdl.data.IDataListener;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.data.api.ICubeData;
import com.ibm.sdl.data.api.IEdge;
import com.ibm.sdl.data.api.IGraphData;
import com.ibm.sdl.data.api.IGraphDataEx;
import com.ibm.sdl.data.api.ITableData;
import com.ibm.sdl.data.api.ITableDataEx;
import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.filter.IItemFilter;
import com.ibm.sdl.util.prop.IName;
import com.ibm.sdl.util.prop.IWeight;

public class VisualLayer extends BaseLayer implements
		IVisualLayer, IDataListener {

	private static final long serialVersionUID = 5146824350505996992L;

	public static final String DEFAULT_NODE_RENDER = "#DEFAULT_NODE_RENDER#";

	public static final String DEFAULT_EDGE_RENDER = "#DEFAULT_EDGE_RENDER#";

	public static final String DEFAULT_NODE_THEME = "#DEFAULT_NODE_THEME#";

	public static final String DEFAULT_EDGE_THEME = "#DEFAULT_EDGE_THEME#";

	protected Map m_node_renders = new HashMap(0);

	protected Map m_edge_renders = new HashMap(0);

	protected Map m_node_themes = new HashMap(0);

	protected Map m_edge_themes = new HashMap(0);

	protected boolean bFocusEdge = false;
	
	protected Object[] m_pickqueue = null;

	private IItemFilter m_clipfilter = null;
	
	private Comparator m_pickComaprator = null;
	
	private Comparator m_paintComparator = null;
	
	private IItemFilter m_rangefilter = null;
	
	private IItemFilter m_pickFilter = null;
	
	private Rectangle2D m_selectRange = null;

	public VisualLayer() {
		this(null);
	}
	
	public VisualLayer(Display owner) {
		super(owner);
		
		m_selectRange = new Rectangle2D.Double();
		
		m_clipfilter = new IItemFilter() {
			RenderClip c = null;
			public boolean accept(Object elem) {
				
				if(!(elem instanceof IVisualElement)) {
					return false;
				}
				
				IVisualElement e = (IVisualElement)elem;
				IRender r = null;
				Shape s = null;
				
				r = getRender(e);
				if(null == r) {
					return false;
				}
				
				s = r.getRawShape(e);
				if(null == s) {
					return false;
				}
				
				if(null == c) {
					c = getClip();
				}
				if(s.intersects(c.getBounds2D())) {
					return true;
				}
				
				return true;
			}
		};
		
		m_finder = new IElemFinder() {
			
			public Object findElement(double x, double y) {
				int i = 0;
				for(i = 0; i < m_handle.length; ++i) {
					if(m_handleRenderer.
							locatePoint(x, y, m_handle[i])) {
						return m_handle[i];
					}
				}
				
				if (m_data == null) {
					return null;
				}

				if(null == m_pickqueue) {
					m_pickqueue = getElements(m_pickFilter, m_pickComaprator);
				}
				
				if(null == m_pickqueue || 0 == m_pickqueue.length) {
					return null;
				}
				
				IVisualElement e = null, target = null;
				IRender r = null;
				
				for(i = m_pickqueue.length - 1; i >= 0; --i) {
					e = (IVisualElement) m_pickqueue[i];
					r = getRender(e);
					
					if(r == null) {
						continue;
					}
					
					if(e instanceof IVisualEdge && !bFocusEdge) {
						continue;
					}
					
					if(e.isVisible() && r.locatePoint(x, y, e)) {
						target = e;
						break;
					}
				}
				
				return target;
			}
			
			public void setOwner(ILayer layer) {
			}

			public ILayer getOwner() {
				return VisualLayer.this;
			}
		};
		
		m_rangefilter = new IItemFilter(){
			public boolean accept(Object elem) {
				IVisualElement ve = (IVisualElement)elem;
				if(!ve.isVisible()) {
					return false;
				}
				
				IRender r = getRender(ve);
				if(r == null) {
					return false;
				}
				
				Shape s = r.getRawShape(ve);
				if(null == s) {
					return false;
				}
				if(s.intersects(m_selectRange)) {
					return true;
				}
				ve.setHighlight(false);
				return false;
			}
		};
	}

	public Object getData() {
		return m_data;
	}

	/**
	 * Detach the current data from view
	 * 
	 */
	public synchronized void detachDataFromLayer() {
		if (null != m_data && m_data instanceof IData) {
			((IData) m_data).removeDataListener(this);
		}
	}

	/**
	 * Attacth the current data to the view
	 * 
	 */
	public synchronized void detachDataToLayer() {
		if (null != m_data && m_data instanceof IData) {
			((IData) m_data).addDataListener(this);
		}
	}

	public void setData(Object data) throws InvalidateDataException {
		
		if (null != m_data) {
			if(m_layout != null) {
				m_layout.reset();
			}
		}
		
		if (null != m_data && m_data instanceof IData) {
			((IData) m_data).removeDataListener(this);
			((IData) m_data).clear();
		}
		m_data = data;
		if (m_data == null) {
			return;
		}
		if (m_data instanceof IData) {
			((IData) m_data).addDataListener(this);
		}

		Object[] nodes = getNodes(null, null);
		if (nodes == null) {
			nodes = getRows(null, null);
		}

//		if (null == nodes) {
//			throw new InvalidateDataException("Invalidate data type : " + data);
//		}
		
		if(null == nodes) {
			return;
		}

		for (int i = 0; i < nodes.length; ++i) {
			if (!(nodes[i] instanceof IVisualNode)) {
//				throw new InvalidateDataException(
//						"Can't convert data to visual elements");
				break;
			}
			calGeometryInfo((IVisualNode) nodes[i]);
		}
	}

	public void enableFocusEdge(boolean enable) {
		bFocusEdge = enable;
	}

	public boolean isEdgeFocusable() {
		return bFocusEdge;
	}
	
	public void update(Object elem) {
		
		if(elem instanceof IVisualNode) {
			
			IRender r = getRender((IVisualNode)elem);
			Shape s = r.getRawShape((IVisualNode)elem);
			if(s == null) {
				return;
			}
			super.update(s.getBounds2D());			
		} else if(elem instanceof IVisualEdge) {
			
			IVisualEdge edge = (IVisualEdge)elem;
			IVisualNode node1 = (IVisualNode)edge.getFirstNode();
			IVisualNode node2 = (IVisualNode)edge.getSecondNode();
			
			IRender r = getRender(edge);
			if(r != null){
				Shape s = r.getRawShape((IVisualElement)elem);
				if(s != null){
					super.update(s.getBounds2D());
				}
			}
			
			
			r = getRender(node1);
			if(r != null){
				Shape s = r.getRawShape(node1);
				if(s != null){
					super.update(s.getBounds2D());
				}
			}
			
			r = getRender(node2);
			if(r != null){
				Shape s = r.getRawShape(node2);
				if(s != null){
					super.update(s.getBounds2D());
				}
			}
		}
	}

	/**
	 * Get the render which is mapped to the specified visual element. <br>
	 * 
	 * @param e
	 *            the specified visual element
	 * @return the render maped to visual element e
	 */
	public IRender getRender(IVisualElement e) {

		String type = PropOperator.getInstance().getType(e);

		if (e instanceof IVisualNode) {
			if (m_node_renders.containsKey(e)) {
				return (IRender) m_node_renders.get(e);
			}

			if (null != type && !"".equals(type)
					&& m_node_themes.containsKey(type)) {
				return (IRender) m_node_renders.get(type);
			}

			return (IRender) m_node_renders.get(DEFAULT_NODE_RENDER);
		}

		if (e instanceof IEdge) {
			if (m_edge_renders.containsKey(e)) {
				return (IRender) m_edge_renders.get(e);
			}

			if (null != type && !"".equals(type)
					&& m_edge_themes.containsKey(type)) {
				return (IRender) m_edge_renders.get(type);
			}

			return (IRender) m_edge_renders.get(DEFAULT_EDGE_RENDER);
		}

		return null;
	}

	public IRender[] getNodeRenders(IItemFilter filter) {

		if (null == filter) {
			return (IRender[]) m_node_renders.values().toArray(new IRender[] {});
		}

		List renders = new ArrayList();

		Iterator it = m_node_renders.values().iterator();
		while (it.hasNext()) {
			Object render = it.next();
			if (filter.accept(render)) {
				renders.add(render);
			}
		}

		return (IRender[]) renders.toArray(new IRender[] {});
	}

	public IRender[] getEdgeRenders(IItemFilter filter) {
		if (null == filter) {
			return (IRender[]) m_node_renders.values()
					.toArray(new IRender[] {});
		}

		List renders = new ArrayList();

		Iterator it = m_edge_renders.values().iterator();
		while (it.hasNext()) {
			Object render = it.next();
			if (filter.accept(render)) {
				renders.add(render);
			}
		}

		return (IRender[]) renders.toArray(new IRender[] {});
	}

	/**
	 * Get the element theme mapped to the specified visual element <br>
	 * In peony component, each visual element mapped to a theme, usually the
	 * default theme will be mapped on every visual elements and special themes
	 * also can be specified.
	 * 
	 * @param e
	 *            the specified visual element
	 * @return the theme mapped to e
	 */
	public ITheme getTheme(IVisualElement e) {

		String type = PropOperator.getInstance().getType(e);

		if (e instanceof IVisualNode) {
			if (m_node_themes.containsKey(e)) {
				return (ITheme) m_node_themes.get(e);
			}
			if (null != type && m_node_themes.containsKey(type)) {
				return (ITheme) m_node_themes.get(type);
			}
			return (ITheme) m_node_themes.get(DEFAULT_NODE_THEME);
		} else if (e instanceof IEdge) {
			if (m_edge_themes.containsKey(e)) {
				return (ITheme) m_edge_themes.get(e);
			}
			if (null != type && m_edge_themes.containsKey(type)) {
				return (ITheme) m_edge_themes.get(type);
			}
			return (ITheme) m_edge_themes.get(DEFAULT_EDGE_THEME);
		}
		return null;
	}

	public IRender getDefaultNodeRender() {
		return (IRender) m_node_renders.get(DEFAULT_NODE_RENDER);
	}

	public ITheme getDefaultNodeTheme() {
		return (ITheme) m_node_themes.get(DEFAULT_NODE_THEME);
	}

	public IRender getDefaultEdgeRender() {
		return (IRender) m_edge_renders.get(DEFAULT_EDGE_RENDER);
	}

	public ITheme getDefaultEdgeTheme() {
		return (ITheme) m_edge_themes.get(DEFAULT_EDGE_THEME);
	}

	public void registerNodeRender(IRender render) {
		render.setOwner(this);
		this.m_node_renders.put(DEFAULT_NODE_RENDER, render);
	}

	public void registerEdgeRender(IRender render) {
		render.setOwner(this);
		this.m_edge_renders.put(DEFAULT_EDGE_RENDER, render);
	}

	public void registerRender(IVisualElement e, IRender render) {
		render.setOwner(this);
		if (e instanceof IVisualNode) {
			m_node_renders.put(e, render);
		} else if (e instanceof IEdge) {
			m_edge_renders.put(e, render);
		}
	}

	public void registerNodeRender(String type, IRender r) {
		r.setOwner(this);
		this.m_node_renders.put(type, r);
	}

	public void registerEdgeRender(String type, IRender r) {
		r.setOwner(this);
		this.m_edge_renders.put(type, r);
	}

	public Map getNodeRenders() {
		return m_node_renders;
	}

	public Map getEdgeRenders() {
		return m_edge_renders;
	}

	public void registerNodeTheme(ITheme theme) {
		theme.setOwner(this);
		this.m_node_themes.put(DEFAULT_NODE_THEME, theme);
	}

	public void registerNodeTheme(String type, ITheme theme) {
		theme.setOwner(this);
		this.m_node_themes.put(type, theme);
	}

	public void registerEdgeTheme(ITheme theme) {
		theme.setOwner(this);
		this.m_edge_themes.put(DEFAULT_EDGE_THEME, theme);
	}

	public void registerEdgeTheme(String type, ITheme theme) {
		theme.setOwner(this);
		this.m_edge_themes.put(type, theme);
	}

	public void registerTheme(IVisualElement e, ITheme theme) {
		theme.setOwner(this);
		if (e instanceof IVisualNode) {
			this.m_node_themes.put(e, theme);

			InfoVisUtil.DEFAULT_GRAPHICS.setFont(theme.getLabelFont(e, false));
			FontMetrics fm = InfoVisUtil.DEFAULT_GRAPHICS.getFontMetrics();
			String name = PropOperator.getInstance().getName(e);

			((IVisualNode) e).setWidth(fm.stringWidth(name) + 6);
			((IVisualNode) e).setHeight(fm.getFont().getSize() + 6);
		} else if (e instanceof IEdge) {
			this.m_edge_themes.put(e, theme);
		}
	}

	protected boolean isOffComponent(MouseEvent e) {
		int x = e.getX(), y = e.getY();
		JComponent comp = (JComponent) e.getSource();
		boolean flag = x < 0 || x > comp.getWidth() || y < 0
				|| y > comp.getHeight();
		if (flag) {
			focus = null;
			m_owner.repaint();
		}
		return flag;
	}

	protected void calGeometryInfo(IVisualNode node) {

		FontMetrics fm = null;
		String name = "";
		ITheme theme = null;

		int m = 2;

		if (null == node) {
			return;
		}

		name = PropOperator.getInstance().getName(node);

		theme = getTheme(node);
		if (null != theme && null != name) {
			InfoVisUtil.DEFAULT_GRAPHICS.setFont(theme
					.getLabelFont(node, false));
			fm = InfoVisUtil.DEFAULT_GRAPHICS.getFontMetrics();
			int sh = 2 * m + fm.getLeading() + fm.getAscent();
			node.setWidth(fm.stringWidth(name) + m * 3);
			node.setHeight(sh);
		}
	}
	
	public Object[] getNodes(IItemFilter filter, Comparator c) {

		if (null == m_data) {
			return null;
		}

		List temp = new ArrayList(0);

		if (m_data instanceof IGraphDataEx) {
			return ((IGraphDataEx) m_data).getNodes(filter, c);
		} else if (m_data instanceof ITableDataEx) {
			return null;
		} else if (m_data instanceof IGraphData) {
			int size = ((IGraphData) m_data).getNodeCount();
			Object node = null;
			for (int i = 0; i < size; ++i) {
				node = ((IGraphData) m_data).getNode(i);
				if (null == filter || filter.accept(node)) {
					temp.add(node);
				}
			}
			return temp.toArray();
		} else if (m_data instanceof ICubeData) {
			int size = ((ICubeData)m_data).size();
			Object cubic = null;
			for (int i = 0; i < size; ++i) {
				cubic = ((ICubeData) m_data).getCubicElem(i);
				if (null != cubic && (null == filter || filter.accept(cubic))) {
					temp.add(cubic);
				}
			}
			return temp.toArray();
		} else {
			return null;
		}
	}

	public IEdge[] getEdges(IItemFilter filter, Comparator c) {
		if (null == m_data) {
			return null;
		}

		List temp = new ArrayList(0);

		if (m_data instanceof IGraphDataEx) {
			return ((IGraphDataEx) m_data).getEdges(filter, c);
		} else if (m_data instanceof IGraphData) {
			int size = ((IGraphData) m_data).getEdgeCount();
			Object edge = null;
			for (int i = 0; i < size; ++i) {
				edge = ((IGraphData) m_data).getEdge(i);
				if (null == filter || filter.accept(edge)) {
					temp.add(edge);
				}
			}
			
			IEdge[] edges = (IEdge[]) temp.toArray(new IEdge[] {});
			Arrays.sort(edges, c);
			return edges;
		} else {
			return null;
		}
	}

	public Object[] getRows(IItemFilter filter, Comparator c) {

		if (m_data instanceof ITableDataEx) {
			return ((ITableDataEx) m_data).getRows(filter, c);
		} else if (m_data instanceof ITableData) {
			List temp = new ArrayList(0);
			int size = ((ITableData) m_data).getRowCount();
			Object row = null;
			for (int i = 0; i < size; ++i) {
				row = ((ITableData) m_data).getRow(i);
				if (null == filter || filter.accept(row)) {
					temp.add(row);
				}
			}
			Object[] rows = temp.toArray();
			Arrays.sort(rows, c);
			return rows;
		} else {
			return null;
		}
	}
	
	public Object[] getElements(Rectangle2D rect) {
		m_selectRange.setFrame(rect);
		return getElements(m_rangefilter, null);
	}
	
	public Object[] getElements(IItemFilter filter, Comparator c) {
		
		List temp = new ArrayList(0);
		
		Object[] nodes = getNodes(filter, c);
		if(null == nodes) {
			nodes = getRows(filter, c);
		}
		if(null == nodes) {
			return null;
		}
				
		IEdge[] edges = getEdges(filter, c);
		if(null != edges) {
//			Collections.addAll(temp, edges);
			for(int i = 0; i < edges.length; ++i) {
				temp.add(edges[i]);
			}
		}
//		Collections.addAll(temp, nodes);
		for(int i = 0; i < nodes.length; ++i) {
			temp.add(nodes[i]);
		}
		
		if(null != c) {
			Collections.sort(temp, c);
		}
		
		return temp.toArray();
	}

	// /////////////////////////////////////////////////////////////////
	// TODO: implements the data listener
	// /////////////////////////////////////////////////////////////////
	public void itemChanged(DataEvent e) {
		
		if(null != m_owner && null != m_layout) {
			return;
		}
		
		Object item = e.getItem();
		if(null == item) {
			return;
		}
		
		Object key = e.getKey();
		if (IName.PROP_NAME.equals(key) || IVisualElement.PROP_FOCUSED.equals(key)) {
			update(item);
			m_owner.repaint();
		} else if (IWeight.PROP_WEIGHT.equals(key)) {			
			m_layout.reset();
			m_layout.layout(this);
			m_owner.repaint();
		}
	}

	public void itemRemoved(DataEvent e) {
		if (null != m_owner && null != m_layout) {
			m_pickqueue = getElements(null, m_pickComaprator);
		}
	}

	public void itemAdded(DataEvent e) {
		Object item = e.getItem();
		if (null != m_owner && null != m_layout && item instanceof IVisualNode) {
			m_pickqueue = getElements(null, m_pickComaprator);
			calGeometryInfo((IVisualNode) item);
		}
	}

	public void dataCleared(DataEvent e) {
		if (null != m_owner) {
			m_owner.repaint();
		}
	}

	public void dataRefreshed(DataEvent e) {
		if (null != m_owner) {
			m_owner.repaint();
		}
	}

	public void setPickComparator(Comparator c) {
		m_pickComaprator = c;
//		m_pickqueue = getElements(null, m_pickComaprator);
	}

	public void setPaintComparator(Comparator c) {
		this.m_paintComparator = c;
	}

	public Comparator getPickComparator() {
		return m_pickComaprator;
	}

	public Comparator getPaintComparator() {
		return m_paintComparator;
	}
	
	public void setClipFilter(IItemFilter filter) {
		m_clipfilter = filter;
	}

	public IItemFilter getClipFilter() {
		return m_clipfilter;
	}
	
	public void setPickingFilter(IItemFilter filter) {
		if(filter != m_pickFilter) {
			this.m_pickFilter = filter;
			this.m_pickqueue = null;
		}
	}
	
	public IItemFilter getPickingFilter() {
		return this.m_pickFilter;
	}
}
