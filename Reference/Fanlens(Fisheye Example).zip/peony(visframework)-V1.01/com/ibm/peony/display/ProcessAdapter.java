package com.ibm.peony.display;

public class ProcessAdapter implements IProcessListener {

	public ProcessAdapter() {
	}

	public void beforeRender(Object context) {
	}

	public void afterRender(Object context) {
	}

	public void beforeLayout(Object context) {
	}

	public void afterLayout(Object context) {
	}

}
