/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.event.InputEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelListener;
import java.util.Collection;

import com.ibm.peony.action.IAction;

public interface IEventDispatcher extends MouseMotionListener, MouseWheelListener, MouseListener, KeyListener {
	
    public static final int INPUT_EVENT_ELEM_ENTERED = 0;
    public static final int INPUT_EVENT_ELEM_EXITED = 1;
    public static final int INPUT_EVENT_ELEM_PRESSED = 2;
    public static final int INPUT_EVENT_ELEM_RELEASED = 3;
    public static final int INPUT_EVENT_ELEM_CLICKED = 4;
    public static final int INPUT_EVENT_ELEM_DRAGGED = 5;
    public static final int INPUT_EVENT_ELEM_MOVED = 6;
    public static final int INPUT_EVENT_ELEM_WHEEL_MOVED = 7;
    public static final int INPUT_EVENT_ELEM_KEY_PRESSED = 8;
    public static final int INPUT_EVENT_ELEM_KEY_RELEASED = 9;
    public static final int INPUT_EVENT_ELEM_KEY_TYPED = 10;
    
    public static final int INPUT_EVENT_MOUSE_ENTERED = 11;
    public static final int INPUT_EVENT_MOUSE_EXITED = 12;
    public static final int INPUT_EVENT_MOUSE_PRESSED = 13;
    public static final int INPUT_EVENT_MOUSE_RELEASED = 14;
    public static final int INPUT_EVENT_MOUSE_CLICKED = 15;
    public static final int INPUT_EVENT_MOUSE_DRAGGED = 16;
    public static final int INPUT_EVENT_MOUSE_MOVED = 17;
    public static final int INPUT_EVENT_MOUSE_WHEEL_MOVED = 18;
    public static final int INPUT_EVENT_KEY_PRESSED = 19;
    public static final int INPUT_EVENT_KEY_RELEASED = 20;
    public static final int INPUT_EVENT_KEY_TYPED = 21;
    
    public void dispatchEvents(int type, Object ve, InputEvent e);
    
	public void addAction(IAction l);
	public void removeAction(IAction l);
	public void removeActions(Collection c);
	public void removeActions();
	public IAction[] getActions();
	
}
