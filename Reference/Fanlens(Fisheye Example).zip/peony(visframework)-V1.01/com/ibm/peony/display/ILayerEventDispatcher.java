/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

public interface ILayerEventDispatcher {

	public void addLayerFocusListener(ILayerFocusListener l);
	public void removeLayerFocusListener(ILayerFocusListener l);
	
	public void addLayerEventListener(ILayerEventListener l);
	public void removeLayerEventListener(ILayerEventListener l);
	
	public void addLayerContainerListener(ILayerContainerListener l);
	public void removeLayerContainerListener(ILayerContainerListener l);
	
}
