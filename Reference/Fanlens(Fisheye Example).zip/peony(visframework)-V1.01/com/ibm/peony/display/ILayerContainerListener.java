/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;


public interface ILayerContainerListener {

    /**
     * Invoked when a layer has been added to the container.
     */
    public void layerAdded(LayerManager mamager, ILayer layer);

    /**
     * Invoked when a layer has been removed from the container.
     */    
    public void layerRemoved(LayerManager mamager, ILayer layer);
	
}
