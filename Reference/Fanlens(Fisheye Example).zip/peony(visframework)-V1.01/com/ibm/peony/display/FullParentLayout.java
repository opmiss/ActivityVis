/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import com.ibm.peony.layout.ILayout;

public class FullParentLayout implements ILayout {

	private static final long serialVersionUID = -8091191120289831644L;
	
	private ILayer m_parent = null;
	
	public FullParentLayout() {
	}
	
	public String getName() {
		return null;
	}

	public String getDescription() {
		return null;
	}
	
	public void setParent(ILayer parent) {
		m_parent = parent;
	}

	public void layout(Object context) {
		if(!(context instanceof LayerManager)) {
			return;
		}
		
		LayerManager manager = (LayerManager)context;
		
		ILayer layer = null;
		
		Object[] layers = manager.getChildren(m_parent, null);
		int size = layers == null ? 0 : layers.length;
		int x = m_parent.getX();
		int y = m_parent.getY();
		int w = m_parent.getWidth();
		int h = m_parent.getHeight();
		for(int i = size - 1; i >= 0; --i) {
			layer = (ILayer)layers[i];
			if(layer instanceof LayerManager) {
				continue;
			}
			layer.setBounds(x, y, w, h);
		}
	}

	public void reset() {
	}

}
