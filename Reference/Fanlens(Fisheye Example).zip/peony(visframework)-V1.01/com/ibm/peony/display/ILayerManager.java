/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.util.Comparator;

import com.ibm.sdl.util.filter.IItemFilter;

public interface ILayerManager extends ILayerEventDispatcher, ILayer {

	public boolean focusLayer(ILayer layer);
	
	public Object[] getPickQueue();

	public Object[] getLayers(IItemFilter fitler, Comparator c);
	
	public void addLayer(ILayer layer);
	
	public ILayer removeLayer(ILayer layer);
	
	public void showLayer(ILayer layer);
	
	public void hideLayer(ILayer layer);
	
	public void clear();
	
	public ILayer getActiveLayer();
}
