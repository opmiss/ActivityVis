/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;

public class Camera implements ICamera {

	protected AffineTransform m_viewtransform = null;

	protected AffineTransform m_itransform = null;

	protected Point2D m_tmpPoint = new Point2D.Double();

	protected Display m_canvas = null;
	
	protected boolean m_bTransforming = false;
	
	protected AffineTransform m_oringnal = null;
	
	public Camera(Display canvas) {
		lookAt(canvas);
		m_viewtransform = new AffineTransform();
		m_itransform = new AffineTransform();
		m_oringnal = (AffineTransform)m_viewtransform.clone();
	}
	
	public void lookAt(Display canvas) {
		m_canvas = canvas;
	}
	
	public synchronized void setTransform(AffineTransform transform)
			throws NoninvertibleTransformException {
		m_viewtransform = transform;
		m_itransform = m_viewtransform.createInverse();
	}

	public AffineTransform getTransform() {
		return m_viewtransform;
	}

	public AffineTransform getInverseTransform() {
		return m_itransform;
	}
	
	public AffineTransform getOringnalTransform() {
		return m_oringnal;
	}

	public Point2D screenToWorld(Point2D screen, Point2D world) {
		return m_itransform.transform(screen, world);
	}
	
	public Point2D worldToScreen(Point2D world, Point2D screen) {
		return m_viewtransform.transform(world, screen);
	}

	public double getScale() {
		return m_viewtransform.getScaleX();
	}

	public double getDisplayX() {
		return -m_viewtransform.getTranslateX();
	}

	public double getDisplayY() {
		return -m_viewtransform.getTranslateY();
	}

	public synchronized void pan(double dx, double dy) {
		double panx = dx / m_viewtransform.getScaleX();
		double pany = dy / m_viewtransform.getScaleY();
		panAbs(panx, pany);
	}

	public synchronized void panAbs(double dx, double dy) {
		m_viewtransform.translate(dx, dy);
		try {
			m_itransform = m_viewtransform.createInverse();
		} catch (Exception e) { /* will never happen here */
		}
	}

	public synchronized void panTo(Point2D p) {
		m_itransform.transform(p, m_tmpPoint);
		panToAbs(m_tmpPoint);
	}

	public synchronized void panToAbs(Point2D p) {
		double sx = m_viewtransform.getScaleX();
		double sy = m_viewtransform.getScaleY();
		double x = p.getX();
		x = (Double.isNaN(x) ? 0 : x);
		double y = p.getY();
		y = (Double.isNaN(y) ? 0 : y);
		x = m_canvas.getWidth() / (2 * sx) - x;
		y = m_canvas.getHeight() / (2 * sy) - y;

		double dx = x - (m_viewtransform.getTranslateX() / sx);
		double dy = y - (m_viewtransform.getTranslateY() / sy);

		m_viewtransform.translate(dx, dy);
		try {
			m_itransform = m_viewtransform.createInverse();
		} catch (Exception e) { /* will never happen here */
		}
	}

	public synchronized void zoom(final Point2D p, double scale) {
		m_itransform.transform(p, m_tmpPoint);
		zoomAbs(m_tmpPoint, scale);
	}

	public synchronized void zoomAbs(final Point2D p, double scale) {
		double zx = p.getX(), zy = p.getY();
		m_viewtransform.translate(zx, zy);
		m_viewtransform.scale(scale, scale);
		m_viewtransform.translate(- zx, - zy);
		try {
			m_itransform = m_viewtransform.createInverse();
		} catch (Exception e) { /* will never happen here */
		}
	}
	
	public synchronized int zoom(Point2D p, double zoom, double min, double max, boolean abs) {

		double scale = getScale();
		double result = scale * zoom;
		int status = ZOOM_DONE;

		if (result < min) {
			zoom = min / scale;
			status = ZOOM_REACH_MIN;
		} else if (result > max) {
			zoom = max / scale;
			status = ZOOM_REACH_MAX;
		} else {
			if (abs) {
				zoomAbs(p, zoom);
			} else {
				zoom(p, zoom);
			}
		}
		return status;
	}

	public synchronized void rotate(final Point2D p, double theta) {
		m_itransform.transform(p, m_tmpPoint);
		rotateAbs(m_tmpPoint, theta);
	}

	public synchronized void rotateAbs(final Point2D p, double theta) {
		double zx = p.getX(), zy = p.getY();
		m_viewtransform.translate(zx, zy);
		m_viewtransform.rotate(theta);
		m_viewtransform.translate(-zx, -zy);
		try {
			m_itransform = m_viewtransform.createInverse();
		} catch (Exception e) { /* will never happen here */
		}
	}
	
	public boolean isTransforming() {
		return m_bTransforming;
	}

	public void reset() {
		this.m_viewtransform = (AffineTransform)m_oringnal.clone();
		try {
			this.m_itransform = m_viewtransform.createInverse();
		} catch (Exception e) {
		}
	}
}
