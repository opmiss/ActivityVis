package com.ibm.peony.display;

public interface IProcessListener {
	
    public void beforeRender(Object context);

    public void afterRender(Object context);
    
    public void beforeLayout(Object context);
    
    public void afterLayout(Object context);

}
