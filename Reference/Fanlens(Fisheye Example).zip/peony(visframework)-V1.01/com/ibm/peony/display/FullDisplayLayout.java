/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import com.ibm.peony.layout.ILayout;

public class FullDisplayLayout implements ILayout {

	private static final long serialVersionUID = -415894119503632951L;

	public FullDisplayLayout() {
	}
	
	public String getName() {
		return null;
	}

	public String getDescription() {
		return null;
	}

	public void layout(Object context) {
		if(!(context instanceof LayerManager)) {
			return;
		}
		
		LayerManager manager = (LayerManager)context;
		
		ILayer layer = null;
		
		Object[] layers = manager.getChildren(manager, null);
		int size = layers == null ? 0 : layers.length;
		int x = manager.getX();
		int y = manager.getY();
		int w = manager.getWidth();
		int h = manager.getHeight();
		for(int i = size - 1; i >= 0; --i) {
			layer = (ILayer)layers[i];
			if(layer instanceof LayerManager) {
				continue;
			}
			layer.setBounds(x, y, w, h);
		}
	}

	public void reset() {
	}
}
