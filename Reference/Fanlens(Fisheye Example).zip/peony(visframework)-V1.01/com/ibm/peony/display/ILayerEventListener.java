/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.util.EventListener;


public interface ILayerEventListener extends EventListener {
	
    /**
     * Invoked when the layer's size changes.
     */
    public void layerResized(LayerManager manager, ILayer layer);

    /**
     * Invoked when the layer's position changes.
     */    
    public void layerMoved(LayerManager manager, ILayer layer);

    /**
     * Invoked when the layer has been made visible.
     */
    public void layerShown(LayerManager manager, ILayer layer);

    /**
     * Invoked when the component has been made invisible.
     */
    public void layerHidden(LayerManager manager, ILayer layer);
	
}
