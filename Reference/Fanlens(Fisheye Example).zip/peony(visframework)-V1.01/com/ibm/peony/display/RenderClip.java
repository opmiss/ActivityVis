/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.logging.Logger;

/**
 * Represents a clipping rectangle in a prefuse <code>Display</code>.
 *
 */
public class RenderClip implements Shape {
    
    private static final byte EMPTY   = 0;
    private static final byte INUSE   = 1;
    private static final byte INVALID = 2;
    
    private double[] clip = new double[8];
    private byte status = INVALID;
    
    private Rectangle rect = new Rectangle();
    
    public void reset() {
        status = EMPTY;
    }
    
    public void invalidate() {
        status = INVALID;
    }
       
    public void setClip(RenderClip c) {
        status = INUSE;
        System.arraycopy(c.clip, 0, clip, 0, clip.length);
        setRectangle();
    }
    
    public void setClip(Rectangle2D r) {
        setClip(r.getX(),r.getY(),r.getWidth(),r.getHeight());
    }
    
    public void setClip(double x, double y, double w, double h) {
        status = INUSE;
        clip[0] = x;
        clip[1] = y;
        clip[6] = x+w;
        clip[7] = y+h;
        setRectangle();
    }
    
    public void setClipFromDiagonal(Point2D p1, Point2D p2) {
    	rect.setFrameFromDiagonal(p1, p2);
    }
    
    public void transform(AffineTransform at) {
        // make the extra corner points valid
        clip[2] = clip[0]; clip[3] = clip[7];
        clip[4] = clip[6]; clip[5] = clip[1];
        
        // transform the points
        at.transform(clip,0,clip,0,4);       
        
        // make safe against rotation
        double xmin = clip[0], ymin = clip[1];
        double xmax = clip[6], ymax = clip[7];
        for ( int i=0; i<7; i+=2 ) {
            if ( clip[i] < xmin )
                xmin = clip[i];
            if ( clip[i] > xmax )
                xmax = clip[i];
            if ( clip[i+1] < ymin )
                ymin = clip[i+1];
            if ( clip[i+1] > ymax )
                ymax = clip[i+1];
        }
        clip[0] = xmin; clip[1] = ymin;
        clip[6] = xmax; clip[7] = ymax;
        setRectangle();
    }
    
    public void limit(double x1, double y1, double x2, double y2) {
        clip[0] = Math.max(clip[0],x1);
        clip[1] = Math.max(clip[1],y1);
        clip[6] = Math.min(clip[6],x2);
        clip[7] = Math.min(clip[7],y2);
        setRectangle();
    }
    
    public boolean intersects(Rectangle2D r, double margin) {
        double tw = clip[6]-clip[0];
        double th = clip[7]-clip[1];
        double rw = r.getWidth();
        double rh = r.getHeight();
        if (rw < 0 || rh < 0 || tw < 0 || th < 0) {
            return false;
        }
        double tx = clip[0];
        double ty = clip[1];
        double rx = r.getX()-margin;
        double ry = r.getY()-margin;
        rw += rx+2*margin;
        rh += ry+2*margin;
        tw += tx;
        th += ty;
        //      overflow || intersect
        return ((rw < rx || rw > tx) &&
                (rh < ry || rh > ty) &&
                (tw < tx || tw > rx) &&
                (th < ty || th > ry));
    }
      
    public void union(RenderClip c) {
        if ( status == INVALID )
            return;
        if ( status == EMPTY ) {
            setClip(c);
            status = INUSE;
            return;
        }
        clip[0] = Math.min(clip[0], c.clip[0]);
        clip[1] = Math.min(clip[1], c.clip[1]);
        clip[6] = Math.max(clip[6], c.clip[6]);
        clip[7] = Math.max(clip[7], c.clip[7]);
        setRectangle();
    }
    
    public void union(Rectangle2D r) {
        if ( status == INVALID )
            return;
       
        double minx = r.getMinX();
        double miny = r.getMinY();
        double maxx = r.getMaxX();
        double maxy = r.getMaxY();
        
        if ( java.lang.Double.isNaN(minx) || java.lang.Double.isNaN(miny) ||
        		java.lang.Double.isNaN(maxx) || java.lang.Double.isNaN(maxy) ) {
            Logger.getLogger(getClass().getName()).warning(
                "Union with invalid clip region: "+r);
            return;
        }
        
        if ( status == EMPTY ) {
            setClip(r);
            status = INUSE;
            return;
        }
        clip[0] = Math.min(clip[0], minx);
        clip[1] = Math.min(clip[1], miny);
        clip[6] = Math.max(clip[6], maxx);
        clip[7] = Math.max(clip[7], maxy);
        setRectangle();
    }
    
    public void union(double x, double y, double w, double h) {
        if ( status == INVALID )
            return;
        if ( status == EMPTY ) {
            setClip(x,y,w,h);
            status = INUSE;
            return;
        }
        clip[0] = Math.min(clip[0], x);
        clip[1] = Math.min(clip[1], y);
        clip[6] = Math.max(clip[6], x+w);
        clip[7] = Math.max(clip[7], y+h);
        setRectangle();
    }
    
    public void intersection(RenderClip c) {
        if ( status == INVALID )
            return;
        if ( status == EMPTY ) {
            setClip(c);
            status = INUSE;
            return;
        }
        clip[0] = Math.max(clip[0], c.clip[0]);
        clip[1] = Math.max(clip[1], c.clip[1]);
        clip[6] = Math.min(clip[6], c.clip[6]);
        clip[7] = Math.min(clip[7], c.clip[7]);
        setRectangle();
    }
    
    public void intersection(Rectangle2D r) {
        if ( status == INVALID )
            return;
        if ( status == EMPTY ) {
            setClip(r);
            status = INUSE;
            return;
        }
        clip[0] = Math.max(clip[0], r.getMinX());
        clip[1] = Math.max(clip[1], r.getMinY());
        clip[6] = Math.min(clip[6], r.getMaxX());
        clip[7] = Math.min(clip[7], r.getMaxY());
        setRectangle();
    }
    
    public void intersection(double x, double y, double w, double h) {
        if ( status == INVALID )
            return;
        if ( status == EMPTY ) {
            setClip(x,y,w,h);
            status = INUSE;
            return;
        }
        clip[0] = Math.max(clip[0], x);
        clip[1] = Math.max(clip[1], y);
        clip[6] = Math.min(clip[6], x+w);
        clip[7] = Math.min(clip[7], y+h);
        setRectangle();
    }
    
    public void expandToIntegerLimits() {
        clip[0] = Math.floor(clip[0]);
        clip[1] = Math.floor(clip[1]);
        clip[6] = Math.ceil(clip[6]);
        clip[7] = Math.ceil(clip[7]);
        setRectangle();
    }
    
    public void expand(double b) {
        clip[0] -= b; clip[1] -= b;
        clip[6] += b; clip[7] += b;
        setRectangle();
    }

    public void grow(double b) {
        clip[6] += b; clip[7] += b;
    }
    
    public double getMinX() {
        return clip[0];
    }
    
    public double getMinY() {
        return clip[1];
    }
    
    public double getMaxX() {
        return clip[6];
    }
    
    public double getMaxY() {
        return clip[7];
    }
    
    public double getWidth() {
        return clip[6]-clip[0];
    }

    public double getHeight() {
        return clip[7]-clip[1];
    }
    
    public boolean isEmpty() {
        return status==EMPTY;
    }
    
    public boolean isInvalid() {
        return status==INVALID;
    }
    
    // ------------------------------------------------------------------------
    
    public boolean equals(Object o) {
        if ( o instanceof Rectangle2D ) {
            Rectangle2D r = (Rectangle2D)o;
            return ( r.getMinX()==clip[0] && r.getMinY()==clip[1] &&
                     r.getMaxX()==clip[6] && r.getMaxY()==clip[7] );
        } else if ( o instanceof RenderClip ) {
            RenderClip r = (RenderClip)o;
            if ( r.status == status ) {
                if ( status == RenderClip.INUSE )
                    return ( r.clip[0]==clip[0] && r.clip[1]==clip[1] &&
                            r.clip[6]==clip[6] && r.clip[7]==clip[7] );
                else
                    return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }
    
    public String toString() {
        StringBuffer sb = new StringBuffer(20);
        sb.append("Clip[");
        switch (status) {
        case INVALID:
            sb.append("invalid");
            break;
        case EMPTY:
            sb.append("empty");
            break;
        default:
            sb.append(clip[0]).append(",");
            sb.append(clip[1]).append(",");
            sb.append(clip[6]).append(",");
            sb.append(clip[7]);
        }
        sb.append("]");
        return sb.toString();
    }
    
    private void setRectangle() {
    	rect.setFrameFromDiagonal(clip[0], clip[1], clip[6], clip[7]);
    }

	public Rectangle getBounds() {
		return rect.getBounds();
	}

	public Rectangle2D getBounds2D() {
		return rect.getBounds2D();
	}

	public boolean contains(double x, double y) {
		return rect.contains(x, y);
	}

	public boolean contains(Point2D p) {
		return rect.contains(p);
	}

	public boolean intersects(double x, double y, double w, double h) {
		return rect.intersects(x, y, w, h);
	}

	public boolean intersects(Rectangle2D r) {
		return rect.intersects(r);
	}

	public boolean contains(double x, double y, double w, double h) {
		return rect.contains(x, y, w, h);
	}

	public boolean contains(Rectangle2D r) {
		return rect.contains(r);
	}

	public PathIterator getPathIterator(AffineTransform at) {
		return rect.getPathIterator(at);
	}

	public PathIterator getPathIterator(AffineTransform at, double flatness) {
		return rect.getPathIterator(at, flatness);
	}
}
