/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.JComponent;

import com.ibm.peony.action.IAction;
import com.ibm.peony.action.LayerHandleAction;
import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.geometry.IVisualNode;
import com.ibm.peony.geometry.VisualNode;
import com.ibm.peony.interaction.distortion.IDistortion;
import com.ibm.peony.layout.ILayout;
import com.ibm.peony.render.DefaultLayerHandleRenderer;
import com.ibm.peony.render.DefaultNodeTheme;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.ITheme;
import com.ibm.peony.render.layer.DefaultGroupLayerRender;
import com.ibm.peony.render.layer.IGroupLayerRender;
import com.ibm.peony.render.layer.ILayerRender;
import com.ibm.peony.state.ActionListRecorder;
import com.ibm.peony.state.ActionRecord;
import com.ibm.peony.state.IActionPerformer;
import com.ibm.peony.state.IActionRecorder;
import com.ibm.peony.state.IViewState;
import com.ibm.peony.state.ViewState;
import com.ibm.peony.util.activity.ActivityManager;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.util.prop.Property;

/**
 * 
 * The default visual layer
 * 
 * @author CaoNan
 * @version 0.2
 * @since 0.1
 */
public class BaseLayer extends Property implements ILayer {

	private static final long serialVersionUID = -6163548564158670326L;

	/**
	 * The topest visual element in the data structure, for example, in the tree
	 * structure "top" is the root of the trere
	 */
	public Object top;

	/**
	 * The last selected visual element.
	 */
	public Object lastSelected;

	/**
	 * The visual element which is picked up by mouse click or press.
	 */
	public Object selected;

	/**
	 * The current foucsed visual element
	 */
	public Object focus;

	/**
	 * The visual element that are dragged
	 */
	public Object dragged;

	/*
	 * interaction parameter
	 */

	protected boolean mouseDragged = false;

	protected boolean mouseMoved = false;

//	protected int m_x = 0;
//
//	protected int m_y = 0;
//
//	protected int m_width = 0;
//
//	protected int m_height = 0;
	
	protected Rectangle2D m_bounds = null;

	protected Display m_owner = null;
	
	protected ILayerManager m_manager = null;

	protected ArrayList m_actions = null;
	
	protected ArrayList m_listeners = null;

	// layout
	protected ILayout m_layout = null;

	protected IGroupLayerRender m_backRender = null;

	protected ILayerRender m_layerRender = null;
	
	protected IGroupLayerRender m_intRender = null;

	protected IElemFinder m_finder = null;
	
	protected Object m_data = null;

	/*
	 * Layer Attributes
	 */
	protected Paint m_background = Color.black;

	protected boolean bHighQuality = true;

	protected boolean bVisible = true;

	protected boolean bFocused = false;

	protected int mouseX = -1;

	protected int mouseY = -1;

	protected IDistortion m_distortion = null;

	protected int m_level = 0;

	/*
	 * Layer handler
	 */
	protected IVisualNode[] m_handle = null;

	protected boolean isHandleActive = false;

	protected IRender m_handleRenderer = null;

	protected ITheme m_handleTheme = null;

	protected Point2D m_tempPoint = null;

	protected RenderClip m_clip = null;

	protected RenderClip m_screen = null;
	
	protected IActionRecorder m_recorder = null;
	
	public BaseLayer() {
		
		m_bounds = new Rectangle2D.Double();
		m_handle = new VisualNode[8];
		for (int i = 0; i < 8; ++i) {
			m_handle[i] = new VisualNode();
		}

		m_handle[0].addProperty("cursor", new Integer(Cursor.NW_RESIZE_CURSOR));
		m_handle[1].addProperty("cursor", new Integer(Cursor.N_RESIZE_CURSOR));
		m_handle[2].addProperty("cursor", new Integer(Cursor.NE_RESIZE_CURSOR));
		m_handle[3].addProperty("cursor", new Integer(Cursor.E_RESIZE_CURSOR));
		m_handle[4].addProperty("cursor", new Integer(Cursor.SE_RESIZE_CURSOR));
		m_handle[5].addProperty("cursor", new Integer(Cursor.S_RESIZE_CURSOR));
		m_handle[6].addProperty("cursor", new Integer(Cursor.SW_RESIZE_CURSOR));
		m_handle[7].addProperty("cursor", new Integer(Cursor.W_RESIZE_CURSOR));
		m_handleRenderer = new DefaultLayerHandleRenderer();
		m_handleRenderer.setOwner(this);
		m_handleTheme = new DefaultNodeTheme();
		m_handleTheme.setOwner(this);
		
		m_finder = new IElemFinder() {
			public Object findElement(double x, double y) {
				if(isHandleActive) {
					for (int i = 0; i < m_handle.length; ++i) {
						if (m_handleRenderer.locatePoint(x, y, m_handle[i])) {
							return m_handle[i];
						}
					}
				}
				return null;
			}

			public void setOwner(ILayer layer) {
			}

			public ILayer getOwner() {
				return BaseLayer.this;
			}
		};
		
		m_actions = new ArrayList(0);
		m_tempPoint = new Point2D.Double();
		m_clip = new RenderClip();
		m_screen = new RenderClip();
		
		m_backRender = new DefaultGroupLayerRender();
		m_intRender = new DefaultGroupLayerRender();
		
		m_listeners = new ArrayList(0);
		m_recorder = new ActionListRecorder();
	}

	public BaseLayer(Display owner) {
		this();
		m_owner = owner;
	}
	
	public void setActionRecorder(IActionRecorder recorder) {
		m_recorder = recorder;
	}
	
	public IActionRecorder getActionRecroder() {
		return m_recorder;
	}
	
	public Object[] getElements(Rectangle2D rect) {
		return null;
	}

	public void setElemFinder(IElemFinder finder) {
		m_finder = finder;
		if(m_finder != null) {
			m_finder.setOwner(this);
		}
	}

	public IElemFinder getElemFinder() {
		return m_finder;
	}

	public void addBackgroundRender(ILayerRender render) {
		if(render != null) {
			m_backRender.addRender(render);
		}
	}

	public ILayerRender[] getBackgroundRenders() {
		return m_backRender.getLayerRenders();
	}
	
	public void removeBackgroundRender(ILayerRender render) {
		m_backRender.removeRender(render);
	}
	
	public void clearBackgroundRenders() {
		m_backRender.clear();
	}

	public void setLayerRender(ILayerRender render) {
		m_layerRender = render;
	}

	public ILayerRender getLayerRender() {
		return m_layerRender;
	}

	public void addInteractionRender(ILayerRender render) {
		if(null == render) {
			return;
		}
		m_intRender.addRender(render);
	}
	
	public ILayerRender[] getInteractionRenders() {
		return m_intRender.getLayerRenders();
	}
	
	public void removeInteractionRender(ILayerRender render) {
		m_intRender.removeRender(render);
	}
	
	public void clearInteractionRenders() {
		m_intRender.clear();
	}

	public void setDistortion(IDistortion dis) {
		m_distortion = dis;
	}

	public IDistortion getDistortion() {
		return m_distortion;
	}

	public void setFocus(boolean focus) {
		this.bFocused = focus;
	}

	public void setVisible(boolean visible) {
		this.bVisible = visible;
	}

	public boolean isVisible() {
		return this.bVisible;
	}

	public boolean isFocused() {
		return this.bFocused;
	}

	public void doLayout() {
		// layout handles

		double x = this.getX();
		double y = this.getY();
		double w = this.getWidth();
		double h = this.getHeight();
		double xx = 0, yy = 0;
		double rr = 8;

		m_handle[0].setNode(x, y, rr, rr);
		xx = x + w / 2.0;
		m_handle[1].setNode(xx, y, rr, rr);
		xx = x + w;
		m_handle[2].setNode(xx, y, rr, rr);
		yy = y + h / 2.0;
		m_handle[3].setNode(xx, yy, rr, rr);
		yy = y + h;
		m_handle[4].setNode(xx, yy, rr, rr);
		xx = x + w / 2.0;
		m_handle[5].setNode(xx, yy, rr, rr);
		xx = x;
		m_handle[6].setNode(xx, yy, rr, rr);
		yy = y + h / 2.0;
		m_handle[7].setNode(xx, yy, rr, rr);

		if (null != m_layout) {
			this.fireBeforeLayout();
			m_layout.layout(this);
			this.fireAfterLayout();
		}
	}

	public void setQuality(boolean bHighQuality) {
		this.bHighQuality = bHighQuality;
	}

	public boolean isHighQuality() {
		return this.bHighQuality;
	}

	public void setBackground(Paint paint) {
		this.m_background = paint;
	}

	public Paint getBackground() {
		return this.m_background;
	}

	public void registerLayout(ILayout layout) {
		m_layout = layout;
	}

	public ILayout getLayout() {
		return m_layout;
	}

	public void addAction(IAction l) {
		l.setOwner(this);
		l.actionAdded();
		this.m_actions.add(l);
	}

	public void removeAction(IAction l) {
		l.actionRemoved();
		l.setOwner(null);
		this.m_actions.remove(l);
	}

	public void removeActions(Collection c) {
		this.m_actions.removeAll(c);
	}
	
	public void removeActions() {
		this.m_actions.clear();
	}

	public IAction[] getActions() {
		return (IAction[]) m_actions
				.toArray(new IAction[] {});
	}

	public void ownerChanged(Display newOwner) {
		m_owner = newOwner;
	}

	public Display getOwner() {
		return m_owner;
	}

	public void setOwner(Display owner) {
		m_owner = owner;
		m_recorder.setActionPerformer(m_owner);
	}
	
	public void setLayerManager(ILayerManager manager) {
		m_manager = manager;
	}
	
	public ILayerManager getLayerManager() {
		return m_manager;
	}
	
	
	// TODO: ---------------------------------- Render -------------------------------------
	public synchronized void paint(Graphics2D g) {
		
		if (m_owner == null) {
			return;
		}

		if (m_clip.isEmpty()) {
//			System.out.println("clip is empty : " + this.getClass());
			return;
		}

		m_screen.setClip(m_bounds);

		ICamera camera = m_owner.getCamera();

		double pixel = 1.0 + 1.0 / camera.getScale();
		double d = m_handle[0].getWidth() / 2;
		double ph = d + d / camera.getScale();
		
		if (m_clip.isInvalid()) {
			m_clip.setClip(m_screen);
		} else {
			m_clip.intersection(m_screen);
		}

		// expand the clip by the extra pixel margin
//		m_clip.expand(pixel);

		// arragne elements

		Shape c = g.getClip();
		// clear dirty region
//		g.setClip(x, y, w, h);
//		if(isHandleActive) {
//			g.setClip(
//					(int)(m_clip.getMinX() - ph), 
//					(int)(m_clip.getMinY() - ph), 
//					(int)(m_clip.getWidth() + ph + ph), 
//					(int)(m_clip.getHeight() + ph + ph));
//		} else {
			g.setClip(m_clip);
//		}

		g.setPaint(m_background);
		g.fillRect(
				(int)(m_clip.getMinX() - pixel), 
				(int)(m_clip.getMinY() - pixel), 
				(int)(m_clip.getWidth() + pixel + pixel), 
				(int)(m_clip.getHeight() + pixel + pixel));
//		g.setColor(Color.black);
//		g.drawRect((int)m_clip.getMinX(), (int)m_clip.getMinY(), 
//				(int)m_clip.getWidth()-1, (int)m_clip.getHeight()-1);

		this.fireBeforeRender();
		
		// render background
		if (m_backRender != null && m_backRender.isEnable()) {
			m_backRender.render(g, this);
		}
		// render the layer
		if (m_layerRender != null && m_layerRender.isEnable()) {
			m_layerRender.render(g, this);
		}
		
		// render interactinos
		if (m_intRender != null && m_intRender.isEnable()) {
			m_intRender.render(g, this);
		}

		this.fireAfterRender();
		
		// render the layer handlers
		// TODO: need some refine
		if (isHandleActive) {
			for (int i = 0; i < m_handle.length; ++i) {
				this.m_handleRenderer.render(g, m_handle[i], m_handleTheme, false);
			}
		}

		m_clip.reset();

		g.setClip(c);
	}

	public synchronized void update() {
		if(null != m_manager) {
			m_manager.update(m_bounds);
		}
		m_clip.union(m_bounds);
	}

	public synchronized void update(RenderClip c) {
		if(null != m_manager) {
			m_manager.update(c);
		}
		if (m_clip.isInvalid()) {
			m_clip.setClip(c);
		} else {
			m_clip.union(c);
		}
	}

	public synchronized void update(double x, double y, double w, double h) {
		if(null != m_manager) {
			m_manager.update(x, y, w, h);
		}
		if (m_clip.isInvalid()) {
			m_clip.setClip(x, y, w, h);
		} else {
			m_clip.union(x, y, w, h);
		}
	}

	public synchronized void update(Rectangle2D r) {
		if(null != m_manager) {
			m_manager.update(r);
		}
		if (m_clip.isInvalid()) {
			m_clip.setClip(r);
		} else {
			m_clip.union(r);
		}
	}

	public synchronized void update(Object elem) {
	}

	public RenderClip getClip() {
		return m_clip;
	}

	// TODO: ---------------------------------- render end -----------------------------

	public void mouseMoved(MouseEvent e) {

		if (!mouseMoved) {
			mouseMoved = true;
		}

		mouseX = e.getX();
		mouseY = e.getY();

		m_tempPoint.setLocation(mouseX, mouseY);

		ICamera camera = m_owner == null ? null : m_owner.getCamera();

		AffineTransform t = camera == null ? null : camera
				.getInverseTransform();

		if (null != m_distortion) {
			m_distortion.inversTransform(m_tempPoint, m_tempPoint);
		}

		if (null != t) {
			t.transform(m_tempPoint, m_tempPoint);
		}

		if (isOffComponent(e)) {
			if(focus != null) {
				dispatchEvents(INPUT_EVENT_ELEM_EXITED, focus, e);
			}
			dispatchEvents(INPUT_EVENT_MOUSE_EXITED, focus, e);
			focus = null;
			return;
		}

		if (!check(e.getPoint())) {
			if (isOffLayer(e.getPoint())) {
				// dispatchElementEvents(INPUT_EVENT_ELEM_EXITED, focus, e);
				focus = null;
			}
			return;
		}

		boolean earlyReturn = false;
		Object ve = null;

		if(null == m_finder) {
			return;
		}
		
		ve = m_finder.findElement(m_tempPoint.getX(), m_tempPoint.getY());

		if (focus != null && focus != ve) {
			dispatchEvents(INPUT_EVENT_ELEM_EXITED, focus, e);
			earlyReturn = true;
			if (focus instanceof IVisualElement) {
				((IVisualElement) focus).setFocused(false);
			}
			focus = null;
		}
		if (ve != null && ve != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_ENTERED, ve, e);
			earlyReturn = true;
			focus = ve;
			if (focus instanceof IVisualElement) {
				((IVisualElement) focus).setFocused(true);
			}
		}

		if (earlyReturn)
			return;
		
		focus = ve;
		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_MOVED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_MOUSE_MOVED, null, e);
		}
	}

	public void mouseWheelMoved(MouseWheelEvent e) {

		if (!check(e.getPoint())) {
			return;
		}

		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_WHEEL_MOVED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_MOUSE_WHEEL_MOVED, null, e);
		}
	}

	public void mouseClicked(MouseEvent e) {

		if (!check(e.getPoint())) {
			return;
		}

		this.lastSelected = this.selected;
		this.selected = focus;

		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_CLICKED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_MOUSE_CLICKED, null, e);
		}
	}

	public void mousePressed(MouseEvent e) {
		if (!check(e.getPoint())) {
			return;
		}

		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_PRESSED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_MOUSE_PRESSED, null, e);
		}
	}

	public void mouseDragged(MouseEvent e) {

		mouseX = e.getX();
		mouseY = e.getY();

		if (!check(e.getPoint())) {
			return;
		}
		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_DRAGGED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_MOUSE_DRAGGED, null, e);
		}
	}

	public void mouseReleased(MouseEvent e) {

		if (!check(e.getPoint())) {
			return;
		}

//		if (!isOffComponent(e)) {
			if (mouseDragged) {
				mouseDragged = false;
				mouseX = -1;
				mouseY = -1;
				if (dragged != null) {
					dispatchEvents(INPUT_EVENT_ELEM_RELEASED, dragged, e);
				} else {
					dispatchEvents(INPUT_EVENT_MOUSE_RELEASED, null, e);
				}
				focus = null;
				dragged = null;
			}
			if (null != focus) {
				dispatchEvents(INPUT_EVENT_ELEM_RELEASED, focus, e);
			} else {
				dispatchEvents(INPUT_EVENT_MOUSE_RELEASED, null, e);
			}
//		} else {
//			dispatchEvents(INPUT_EVENT_ELEM_EXITED, focus, e);
//			dispatchEvents(INPUT_EVENT_MOUSE_EXITED, focus, e);
//		}
	}

	public void mouseExited(MouseEvent e) {
		if(focus != null) {
			dispatchEvents(INPUT_EVENT_ELEM_EXITED, focus, e);
			focus = null;
		}
		dispatchEvents(INPUT_EVENT_MOUSE_EXITED, null, e);
	}

	public void mouseEntered(MouseEvent e) {
		dispatchEvents(INPUT_EVENT_MOUSE_ENTERED, null, e);
	}

	public void keyPressed(KeyEvent e) {

		
//		if(this instanceof VisualLayer) {
//			System.out.println("this = " + getClass());			
//		}
		
		if (!check(null)) {
//			System.out.println("returned");
			return;
		}

		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_KEY_PRESSED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_KEY_PRESSED, null, e);
		}
	}

	public void keyReleased(KeyEvent e) {

		if (!check(null)) {
			return;
		}

		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_KEY_RELEASED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_KEY_RELEASED, null, e);
		}
	}

	public void keyTyped(KeyEvent e) {

		if (!check(null)) {
			return;
		}

		if (null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_KEY_TYPED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_KEY_TYPED, null, e);
		}
	}

	public int getX() {
		return (int)m_bounds.getX();
	}

	public int getY() {
		return (int)m_bounds.getY();
	}

	public int getWidth() {
		return (int)m_bounds.getWidth();
	}

	public int getHeight() {
		return (int)m_bounds.getHeight();
	}

	public void setX(int x) {
		m_bounds.setFrame(x, m_bounds.getY(), m_bounds.getWidth(), m_bounds.getHeight());
	}

	public void setY(int y) {
		m_bounds.setFrame(m_bounds.getX(), y, m_bounds.getWidth(), m_bounds.getHeight());
	}

	public void setWidth(int width) {
		m_bounds.setFrame(m_bounds.getX(), m_bounds.getY(), width, m_bounds.getHeight());
	}

	public void setHeight(int height) {
		m_bounds.setFrame(m_bounds.getX(), m_bounds.getY(), m_bounds.getWidth(), height);
	}

	public Rectangle2D getBounds() {
		return m_bounds;
	}
	
	public void setBounds(int x, int y, int width, int height) {
		m_bounds.setFrame(x, y, width, height);
	}

	public Image transform(BufferedImage image) {
		if (null == m_distortion) {
			return image;
		}
		return m_distortion.transform(image);
	}

	public Shape transform(Shape s) {
		if (null == m_distortion) {
			return s;
		}
		return m_distortion.transform(s);
	}

	public Point2D transform(Point2D pt) {
		if (null == m_distortion) {
			return pt;
		}
		return m_distortion.transform(pt, pt);
	}

	public void transform(float[] coords, int npoints) {
		if (null == m_distortion) {
			return;
		}
		m_distortion.transform(coords, npoints);
	}

	public void transform(Point2D src, Point2D dst) {
		if (null == m_distortion) {
			return;
		}
		m_distortion.transform(src, dst);
	}

	public void setLevel(int level) {
		m_level = level;

	}

	public int getLevel() {
		return m_level;
	}

	public int compareTo(Object o) {

		if (null == o) {
			return 1;
		}

		if (!(o instanceof ILayer)) {
			return 1;
		}

		ILayer layer = (ILayer) o;

		return (getLevel() - layer.getLevel());
	}

	public void setLayerHandleActive(boolean active) {
		isHandleActive = active;
		Iterator it = m_actions.iterator();
		IAction action = null;
		while (it.hasNext()) {
			action = (IAction) it.next();
			if (action instanceof LayerHandleAction)
				continue;
			action.setEnable(!active);
		}
	}

	public boolean isLayerHandleActive() {
		return isHandleActive;
	}

	protected boolean isOffComponent(MouseEvent e) {
		int x = e.getX(), y = e.getY();
		JComponent comp = (JComponent) e.getSource();
		boolean flag = x < 0 || x > comp.getWidth() || y < 0
				|| y > comp.getHeight();
		return flag;
	}

	public boolean isOffLayer(Point e) {
		return !m_bounds.contains(e);
	}

	protected boolean check(Point e) {

		if (m_owner == null) {
			return false;
		}

		ActivityManager act = m_owner.getActivityManager();

		if (act.isPerforming()) {
			return false;
		}

		return bFocused;
	}

	public void dispatchEvents(int type, Object ve, InputEvent e) {

		if (m_actions.isEmpty())
			return;

		Iterator it = m_actions.iterator();
		while (it.hasNext()) {
			IAction l = (IAction) it.next();

			if (!l.isEnable())
				continue;

			switch (type) {
			case INPUT_EVENT_ELEM_ENTERED:
				l.elemEntered(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_EXITED:
				l.elemExited(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_PRESSED:
				l.elemPressed(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_RELEASED:
				l.elemReleased(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_CLICKED:
				l.elemClicked(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_DRAGGED:
				l.elemDragged(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_MOVED:
				l.elemMoved(ve, (MouseEvent) e);
				break;

			case INPUT_EVENT_ELEM_WHEEL_MOVED:
				l.elemWheelMoved(ve, (MouseWheelEvent) e);
				break;

			case INPUT_EVENT_ELEM_KEY_PRESSED:
				l.elemKeyPressed(ve, (KeyEvent) e);
				break;

			case INPUT_EVENT_ELEM_KEY_RELEASED:
				l.elemKeyReleased(ve, (KeyEvent) e);
				break;

			case INPUT_EVENT_ELEM_KEY_TYPED:
				l.elemKeyTyped(ve, (KeyEvent) e);
				break;
			case INPUT_EVENT_MOUSE_ENTERED:
				l.mouseEntered((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_EXITED:
				l.mouseExited((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_PRESSED:
				l.mousePressed((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_RELEASED:
				l.mouseReleased((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_CLICKED:
				l.mouseClicked((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_DRAGGED:
				l.mouseDragged((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_MOVED:
				l.mouseMoved((MouseEvent) e);
				break;
			case INPUT_EVENT_MOUSE_WHEEL_MOVED:
				l.mouseWheelMoved((MouseWheelEvent) e);
				break;
			case INPUT_EVENT_KEY_PRESSED:
				l.keyPressed((KeyEvent) e);
				break;
			case INPUT_EVENT_KEY_RELEASED:
				l.keyReleased((KeyEvent) e);
				break;
			case INPUT_EVENT_KEY_TYPED:
				l.keyTyped((KeyEvent) e);
				break;
			}
		}
	}
	
	public void addProcessListener(IProcessListener l) {
		this.m_listeners.add(l);
	}
	
	public void removeProcessListener(IProcessListener l) {
		this.m_listeners.remove(l);
	}
	
	public void removeAllProcessListeners() {
		this.m_listeners.clear();
	}
	
	public void fireBeforeRender() {
		int size = this.m_listeners.size();
		IProcessListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IProcessListener)m_listeners.get(i);
			l.beforeRender(this);
		}
	}
	
	public void fireAfterRender() {
		int size = this.m_listeners.size();
		IProcessListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IProcessListener)m_listeners.get(i);
			l.afterRender(this);
		}
	}
	
	public void fireBeforeLayout() {
		int size = this.m_listeners.size();
		IProcessListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IProcessListener)m_listeners.get(i);
			l.beforeLayout(this);
		}
	}
	
	public void fireAfterLayout() {
		int size = this.m_listeners.size();
		IProcessListener l = null;
		for(int i = 0; i < size; ++i) {
			l = (IProcessListener)m_listeners.get(i);
			l.afterLayout(this);
		}
	}

	public Object getData() {
		return m_data;
	}
	
	public void setData(Object data) throws InvalidateDataException {
		m_data = data;
	}
	
	public void setState(IViewState state) throws InvalidateDataException {
		
		// restore the data state
		this.setData(state.getDataState());
		this.doLayout();
		
		// restore the view state
		ActionRecord[] records = state.getActionTrail();
		IActionPerformer performer = m_recorder.getActionPerformer();
		for(int i = 0; i < records.length; ++i) {
			performer.execute(
					records[i].type, 
					records[i].param, true);
		}
		
		this.update();
		this.m_owner.repaint();
	}

	public IViewState getState() {
		ViewState state = new ViewState();
		state.setDataState(m_data);
		state.setViewState(m_recorder.getStateRecords());
		return state;
	}
}
