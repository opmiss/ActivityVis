/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.FocusTraversalPolicy;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Point2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.ibm.peony.action.DistortionAction;
import com.ibm.peony.action.IAction;
import com.ibm.peony.interaction.distortion.Fisheye;
import com.ibm.peony.interaction.distortion.IDistortion;
import com.ibm.peony.layout.ILayout;
import com.ibm.peony.state.IActionPerformer;
import com.ibm.peony.state.IViewState;
import com.ibm.peony.util.activity.ActivityManager;
import com.ibm.peony.util.math.Translation;
import com.ibm.peony.util.ui.PBusyDialog;
import com.ibm.sdl.data.InvalidateDataException;

/**
 * <p>
 * Display is a panel on which all the visual elements are rendered and the
 * input events are capthered and dispachted. Since the display extends swing's
 * JPanel class, it can be added into any swing component easily. <br>
 * One single display is composed of one or several layers which are managed by
 * LayerManager, each layer is an indepandent viaulization unit. A display
 * renders the visual elements and dispathes input events in a layer by layer
 * way through LayerManager. <br>
 * One display is mapped to one visual model which holds the visual elements
 * collection for different layers. <br>
 * Every visualizaton component has and only has one display, the display can be
 * the default dispaly which is an instance of this class and also can be some
 * other special component display which extends this class.
 * </p>
 * 
 * @author CaoNan nancao@cn.ibm.com
 * @version 0.2
 * @since 0.1
 */
public class Display extends JPanel implements Printable, IActionPerformer {

	private static final long serialVersionUID = -3945058782996642126L;
	
	protected static PBusyDialog m_dialog = null;

	protected Icon m_icon = null;

	// render parameter
	protected Graphics2D bufGraphics = null;

	protected Image m_buffer = null;

	// activity manager
	protected ActivityManager m_manager = null;

	protected int m_layout = 0x0011;

	private int m_width = 0;

	private int m_height = 0;

	protected ILayer m_layer = null;

	protected DistortionAction m_distortionAction = null;

	protected IDistortion m_defaultDistortion = null;

	protected ICamera m_camera = null;
	
	protected JFrame m_owner = null;

	/**
	 * Default constructor
	 */
	public Display() {
		super();
		m_manager = new ActivityManager();
		m_distortionAction = new DistortionAction();
		m_distortionAction.setOwner(m_layer);
		m_defaultDistortion = new Fisheye();
		m_camera = new Camera(this);
		
		this.setFocusable(true);
		this.setFocusCycleRoot(true);
//		this.setFocusTraversalPolicyProvider(true);
		this.setFocusTraversalPolicy(new FocusTraversalPolicy(){
			public Component getComponentAfter(Container arg0, Component arg1) {
				return Display.this;
			}

			public Component getComponentBefore(Container arg0, Component arg1) {
				return Display.this;
			}

			public Component getFirstComponent(Container arg0) {
				return Display.this;
			}

			public Component getLastComponent(Container arg0) {
				return Display.this;
			}

			public Component getDefaultComponent(Container arg0) {
				return Display.this;
			}
		});
	}

	public Display(ILayer layer) {
		this();
		setLayer(layer);
	}
	
	public Display(JFrame owner) {
		this();
		m_owner = owner;
	}
	
	public void setOwner(JFrame owner) {
		m_owner = owner;
	}
	
	public JFrame getOwner() {
		return m_owner;
	}
	
	public Image getBuffer() {
		return m_buffer;
	}

	public void setLayer(ILayer layer) {
		if (null != m_layer) {
			m_layer.setOwner(null);
			removeMouseListener(m_layer);
			removeMouseMotionListener(m_layer);
			removeMouseWheelListener(m_layer);
			removeKeyListener(m_layer);
			m_distortionAction.setOwner(null);
		}
		m_distortionAction.setOwner(layer);
		m_layer = layer;
		if(null != m_layer) {
			m_layer.setOwner(this);
			m_layer.setFocus(true);
			m_layer.setDistortion(m_defaultDistortion);
			addMouseListener(m_layer);
			addMouseMotionListener(m_layer);
			addMouseWheelListener(m_layer);
			addKeyListener(m_layer);
		}
	}

	public ILayer getLayer() {
		return m_layer;
	}

	public ActivityManager getActivityManager() {
		return m_manager;
	}

	public boolean isAnimating() {
		return m_manager.isPerforming();
	}

	public synchronized void paintComponent(Graphics g) {
		if (null != m_layer) {
			if (bclear) {
				bufGraphics.setTransform(m_camera.getInverseTransform());
				bufGraphics.setBackground(getBackground());
				bufGraphics.clearRect(0, 0, getWidth(), getHeight());
				bclear = false;
			}
			
//			if(bufGraphics == null) {
//				this.initCanvas(0, 0, getWidth(), getHeight());
//			}

			if (null != m_camera) {
//				if(!m_breset) {
				if(m_camera != null) {
					bufGraphics.setTransform(m_camera.getTransform());
				}
//				} else {
//					bufGraphics.setTransform(m_camera.getInverseTransform());
//					m_breset = false; 
//				}
			}

			// if the layer is a visual layer, it will calculate the visual
			// element
			// that need to be painted. if the layer is a layer manager, it will
			// calculate
			// the visual layers that need to be rendered.
			synchronized (this) {
				m_layer.paint(bufGraphics);
			}

			synchronized (this) {
				g.drawImage(m_buffer, 0, 0, null);
			}

		} else {
			super.paintComponent(g);
		}
	}
	
	public void reset() {
		if(m_camera != null) {
			m_camera.reset();
		}
		if(m_layer != null) {
			m_layer.update();
		}
		repaint();
	}

	private boolean bclear = false;

	public void clearCavas() {
		bclear = true;
	}

	public void doLayout() {

		if (null == m_layer) {
			return;
		}

		int w = getWidth();
		int h = getHeight();

		initCanvas(0, 0, w, h);
		m_layer.setBounds(0, 0, w, h);
		m_layer.doLayout();
		m_layer.update();
	}

	public Icon getIcon() {
		return m_icon;
	}

	public void setIcon(Icon icon) {
		m_icon = icon;
	}

	public void setDistortionRadius(float radius) {
		if (m_layer != null) {
			m_layer.getDistortion().setLensRadius(radius);
		}
	}

	public void setDistortionHeight(float height) {
		if (m_layer != null) {
			m_layer.getDistortion().setFocusHeight(height);
		}
	}
	
	public void addProcessListener(IProcessListener l) {
		if(null != m_layer) {
			m_layer.addProcessListener(l);
		}
	}

	public void addInteraction(IAction l) {
		if (null != m_layer) {
			m_layer.addAction(l);
		}
	}

	public void removeAction(IAction l) {
		if (null != m_layer) {
			m_layer.removeAction(l);
		}
	}
	
	public IAction[] getActions() {
		if (null != m_layer) {
			return m_layer.getActions();
		}
		return null;
	}

	public IDistortion getDistortion() {
		if (null == m_layer) {
			return null;
		}
		return m_layer.getDistortion();
	}

	public void setDistortion(IDistortion dis) {
		if (null == m_layer) {
			return;
		}
		m_layer.setDistortion(dis);
	}

	public void enableDistortion(boolean distortion) {
		if (null == m_layer.getDistortion()) {
			return;
		}
		if (distortion) {
			this.addInteraction(m_distortionAction);
		} else {
			this.removeAction(m_distortionAction);
		}
	}

	public void setBackground(Color color) {
		if (null != m_layer) {
			m_layer.setBackground(color);
		}
		super.setBackground(color);
	}

	public void setVisible(boolean visible) {
		if (null == m_layer) {
			return;
		}
		m_layer.setVisible(visible);
	}

	public void registerLayout(ILayout layout) {
		if (null == m_layer) {
			return;
		}
		m_layer.registerLayout(layout);
	}

	public ILayout getLayerLayout() {
		if (null == m_layer) {
			return null;
		}
		return m_layer.getLayout();
	}

	protected synchronized boolean initCanvas(int x, int y, int w, int h) {

		if (w == m_width && h == m_height) {
			return false;
		}

		m_width = w;
		m_height = h;

		if (bufGraphics != null) {
			bufGraphics.dispose();
			bufGraphics = null;
		}

		// The background layer image buffer
		m_buffer = this.createImage(w, h);

		bufGraphics = (Graphics2D) m_buffer.getGraphics();
		bufGraphics.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
		bufGraphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BICUBIC);

		int margin = 10;
		int wmargin = 20;

		bufGraphics.setBackground(getBackground());
		bufGraphics.clearRect(-margin, -margin, getWidth() + wmargin,
				getHeight() + wmargin);

		bufGraphics.setClip(0, 0, w, h);

		System.gc();
		return true;
	}

	/**
	 * Set the SDL data into the specified layer.
	 * 
	 * When the data is not an instance of SDL data strucuture, the
	 * InvalidateDataException
	 * 
	 * When the current layer is not an instance of LayerManager or
	 * IVisualLayer, the InvalidateLayerException will be throwed.
	 * 
	 * @param data
	 * @throws InvalidateDataException
	 * @throws InvalidateLayerException
	 */
	public void setData(Object data) throws InvalidateDataException {

		if (null == m_layer) {
			return;
		}
		if (m_layer instanceof IVisualLayer) {
			((IVisualLayer) m_layer).setData(data);
		}
	}
	
	public Object getData() {
		if (null == m_layer) {
			return null;
		}
		if (m_layer instanceof IVisualLayer) {
			return ((IVisualLayer) m_layer).getData();
		}
		return null;
	}

	public int print(Graphics g, PageFormat pageFormat, int pageIndex)
			throws PrinterException {

		if (pageIndex != 0) {
			return NO_SUCH_PAGE;
		}
		int x = Translation.atoi(pageFormat.getImageableX());
		int y = Translation.atoi(pageFormat.getImageableY());
		int w = Translation.atoi(pageFormat.getImageableWidth());
		int h = Translation.atoi(pageFormat.getImageableHeight());

		g.drawImage(m_buffer, x, y, x + w, y + h, 0, 0, getWidth(),
				getHeight(), null);

		return PAGE_EXISTS;
	}
	
	public Image getThumbnail(int width, int height) {
		Image image = createImage(width, height);
		Graphics2D g = (Graphics2D)image.getGraphics();
		System.out.println("image = " + image);
		g.drawImage(
				m_buffer, 0, 0, width, height, 0, 0, getWidth(),
				getHeight(), null);
		return image;
	}

	public void print() {
		PrinterJob job = PrinterJob.getPrinterJob();
		PageFormat pf = job.defaultPage();
		PageFormat pf2 = job.pageDialog(pf);
		if (pf2 != pf) {
			job.setPrintable(this, pf2);
			if (job.printDialog()) {
				try {
					job.print();
				} catch (PrinterException e) {
					JOptionPane.showMessageDialog(this, e);
				}
			}
		}
	}

	public void setCamera(Camera camera) {
		m_camera = camera;
		m_camera.lookAt(this);
	}

	public ICamera getCamera() {
		return m_camera;
	}

	public synchronized void pan(double dx, double dy) {
		if (null != m_camera) {
			m_camera.pan(dx, dy);
			m_layer.getClip().invalidate();
		}
	}

	public synchronized void panAbs(double dx, double dy) {
		if (null != m_camera) {
			m_camera.panAbs(dx, dy);
			m_layer.getClip().invalidate();
		}
	}

	public synchronized void panTo(Point2D pt) {
		if (null != m_camera) {
			m_camera.panTo(pt);
			m_layer.getClip().invalidate();
		}
	}

	public synchronized void zoom(Point2D p, double scale) {
		if (null != m_camera) {
			m_camera.zoom(p, scale);
			m_layer.getClip().invalidate();
		}
	}

	public synchronized void zoomAbs(Point2D p, double scale) {
		if (null != m_camera) {
			m_camera.zoomAbs(p, scale);
			m_layer.getClip().invalidate();
		}
	}

	public synchronized void zoom(Point2D p, double zoom, double min,
			double max, boolean abs) {
		if (null != m_camera) {
			m_camera.zoom(p, zoom, min, max, abs);
			m_layer.getClip().invalidate();
		}
	}

	public synchronized void rotate(Point2D p, double angle) {
		if (null != m_camera) {
			m_camera.rotate(p, angle);
			m_layer.getClip().invalidate();
		}
	}

	public Point2D screenToWorld(Point2D screen, Point2D world) {
		return m_camera.screenToWorld(screen, world);
	}

	public Point2D worldToScreen(Point2D world, Point2D screen) {
		return m_camera.worldToScreen(world, screen);
	}
	
	public void freeze(String message) {
		if(null == m_dialog) {
			m_dialog = new PBusyDialog(m_owner);
			if(null == m_dialog.getOwner()) {
				Frame[] frames = JFrame.getFrames();
				for(int i = 0; i < frames.length; ++i) {
					if(frames[i].isActive() && frames[i].isFocused()) {
						m_dialog.setOwner(frames[i]);
						break;
					}
				}
			}
		}
		m_dialog.setStateText(message);
		m_dialog.startProcess();
	}
	
	public void unfreeze() {
		m_dialog.stopProcess();
	}
	
	public void setState(Object state) {
		if(m_layer != null) {
			try {
				m_layer.setState((IViewState)state);
			} catch (InvalidateDataException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Object getState() {
		if(m_layer != null) {
			return m_layer.getState();
		}
		return null;
	}
	
	public boolean redo() {
		return m_layer.getActionRecroder().redo(1);
	}
	
	public boolean undo() {
		return m_layer.getActionRecroder().undo(1);
	}
	
	public boolean redo(int level) {
		return m_layer.getActionRecroder().redo(level);
	}
	
	public boolean undo(int level) {
		return m_layer.getActionRecroder().undo(level);
	}
	
	public void bookmark() {
	}

	public void execute(String type, Object param, boolean brestore) {
	}

	public void unexecute(String type, Object param, boolean brestore) {
	}
	
}
