/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import com.ibm.peony.geometry.VisualEdge;
import com.ibm.peony.render.layer.ILayerRender;
import com.ibm.peony.util.activity.ActivityManager;
import com.ibm.sdl.data.api.ITreeData;
import com.ibm.sdl.data.tree.impl.EntityTree;
import com.ibm.sdl.util.TreeTraverser;
import com.ibm.sdl.util.filter.IItemFilter;

public class LayerManager extends BaseLayer implements ILayerManager {

	private static final long serialVersionUID = 5740186078170018386L;
	
	protected static final int LAYER_EVENT_FOCUS_GAINED = 0;
    protected static final int LAYER_EVENT_FOCUS_LOSTED = 1;
    protected static final int LAYER_EVENT_RESIZED = 2;
    protected static final int LAYER_EVENT_MOVED = 3;
    protected static final int LAYER_EVENT_SHOWN = 4;
    protected static final int LAYER_EVENT_HIDDEN = 5;
    protected static final int LAYER_EVENT_ADDED = 6;
    protected static final int LAYER_EVENT_REMOVED = 7;
	
	protected EntityTree m_sensegraph = new EntityTree();
	protected TreeTraverser.IRecursionDelegator m_layoutOP = null;
	
	protected List m_layerEventListeners = null;
	protected List m_layerFocusListeners = null;
	protected List m_layerContainerListeners = null;
	
	protected int m_repaint = 0x1111;
	
//	protected Object[] m_paintqueue = null;
	
	protected Object[] m_pickqueue = null;

	private IItemFilter m_clipfilter = null;
	
	private Comparator m_pickComaprator = null;
	
	private Comparator m_paintComparator = null;
	
	private RenderClip tempClip = new RenderClip();
	
	public LayerManager() {
		m_sensegraph.setEdgeType(VisualEdge.class);
		m_sensegraph.setTreeRoot(this);
		m_layoutOP = new TreeTraverser.IRecursionDelegator() {
			public void perform(ITreeData tree, Object node, Object param) {
				if(node == LayerManager.this) {
					return;
				}
				ILayer layer = (ILayer)node;
				layer.doLayout();
			}
		};
		
		m_layerEventListeners = new ArrayList(0);
		m_layerFocusListeners = new ArrayList(0);
		m_layerContainerListeners = new ArrayList(0);
		
		bVisible = false;
		
		registerLayout(new FullDisplayLayout());
		
		m_clipfilter = new IItemFilter() {
			public boolean accept(Object elem) {
				
				if(!(elem instanceof ILayer)) {
					return false;
				}
				
				if(elem.equals(LayerManager.this)) {
					return false;
				}
				
				ILayer layer = (ILayer)elem;
				
				if(m_clip.intersects(layer.getBounds())) {
					return true;
				}
				
				return false;
			}
		};
		
		m_finder = new IElemFinder() {
			public Object findElement(double x, double y) {
				
				ILayer layer = null, target = null;
				
				if(m_pickqueue != null) {
					for(int i = m_pickqueue.length - 1; i >= 0; --i) {
						layer = (ILayer) m_pickqueue[i];
						int xx = layer.getX();
						int yy = layer.getY();
						int ww = layer.getWidth();
						int hh = layer.getHeight();
						
						if(layer.isVisible() && x > xx && x < xx + ww && y > yy && y < yy + hh)	{
							target = layer;
							break;
						}
					}
				}
				
				return target;
			}
			
			public void setOwner(ILayer layer) {
			}

			public ILayer getOwner() {
				return null;
			}
		};
		
		m_pickComaprator = new Comparator() {
			public int compare(Object layer1, Object layer2) {
				int flag = 0;
				if(layer1 instanceof ILayer && layer2 instanceof ILayer) {
					flag = m_sensegraph.getDepth(layer1) - m_sensegraph.getDepth(layer2);
					if(0 == flag) {
						flag = ((ILayer)layer1).getLevel() - ((ILayer)layer2).getLevel();
					}
				}
				return flag;
			}
		};
		
		m_paintComparator = new Comparator() {
			public int compare(Object layer1, Object layer2) {
				int flag = 0;
				if(layer1 instanceof ILayer && layer2 instanceof ILayer) {
					flag = m_sensegraph.getDepth(layer1) - m_sensegraph.getDepth(layer2);
					if(0 == flag) {
						flag = ((ILayer)layer1).getLevel() - ((ILayer)layer2).getLevel();
					}
				}
				return flag;
			}
		};
		
		m_layerRender = new ILayerRender(){
			private boolean enable = true;
			public void render(Graphics2D g, BaseLayer layer) {
				
				if(!(layer instanceof ILayerManager)) {
					return;
				}
				
				Object[] layers = getLayers(m_clipfilter, m_paintComparator);
				if(layers == null) {
					return;
				}
				
				for(int i = 0; i < layers.length; ++i) {
					((ILayer)layers[i]).getClip().intersection(m_bounds);
					((ILayer)layers[i]).paint(g);
				}
			}

			public boolean isEnable() {
				return enable;
			}

			public void setEnable(boolean enable) {
				this.enable = enable;
			}
		};
	}
	
	public LayerManager(Display owner) {
		this();
		m_owner = owner;
	}
	
	///////////////////////////////////////////////////////
	// TODO: layer management methods
	///////////////////////////////////////////////////////
	public void addLayer(ILayer layer) {
		addLayer(this, layer);
	}
	
	public void addLayer(ILayer parent, ILayer layer) {
		if(null == layer || null == parent) return;
		layer.setOwner(m_owner);
		layer.setLayerManager(this);
		m_sensegraph.addChild(parent, layer);
		layer.setLevel(m_sensegraph.getChildCount(parent));
		m_pickqueue = m_sensegraph.getNodes(null, m_pickComaprator);
		dispatchLayerEvents(LAYER_EVENT_ADDED, layer);
	}
	
	public ILayer removeLayer(ILayer layer) {
		if(null == layer) return null;
		
		ILayer next = null;
		if(layer.isFocused()) {
			ILayer p = (ILayer)m_sensegraph.getParent(layer);
			ILayer temp = null;
			
			int cnt = m_sensegraph.getChildCount(p);
			if(cnt > 1) {
				for(int i = 0; i < cnt; ++i) {
					temp = (ILayer)m_sensegraph.getChild(p, i);
					if(temp != layer) {
						next = layer;
						break;
					}
				}
			} else if(p != this){
				next = p;
			}
		}
		
		m_sensegraph.removeChild(layer);
		m_pickqueue = m_sensegraph.getNodes(null, m_pickComaprator);
		layer.setOwner(null);
		layer.setLayerManager(null);
		dispatchLayerEvents(LAYER_EVENT_REMOVED, layer);
		
		return next;
	}
	
	public void showLayer(ILayer layer) {
		if(null == layer) return;
		layer.setVisible(true);
		dispatchLayerEvents(LAYER_EVENT_SHOWN, layer);
	}
	
	public void hideLayer(ILayer layer) {
		if(null == layer) return;
		layer.setVisible(false);
		dispatchLayerEvents(LAYER_EVENT_HIDDEN, layer);
	}
	
	/**
	 * Focus a specified layer
	 * 
	 * When the layer is a child of the layer manager in the   
	 * @param layer
	 * @return true if the focus changed or reutrn false
	 */
	public boolean focusLayer(ILayer layer) {
		if(null == layer || layer.isFocused() || layer == this) {
			return false;
		}
		ILayer last = getActiveLayer();
		if(null != last) {
			last.setFocus(false);
			m_owner.removeMouseListener(last);
			m_owner.removeMouseMotionListener(last);
			m_owner.removeMouseWheelListener(last);
			m_owner.removeKeyListener(last);
			dispatchLayerEvents(LAYER_EVENT_FOCUS_LOSTED, last);
		}
		layer.setFocus(true);
		if(selected != layer) {
			focus = layer;
			lastSelected = selected;
			selected = focus;
		}
		
		m_owner.addMouseListener(layer);
		m_owner.addMouseMotionListener(layer);
		m_owner.addMouseWheelListener(layer);
		m_owner.addKeyListener(layer);
		dispatchLayerEvents(LAYER_EVENT_FOCUS_GAINED, layer);
		return true;
	}
	
	public void clear() {
		m_sensegraph.clear();
		m_sensegraph.setTreeRoot(this);
	}
	
	public synchronized ILayer getActiveLayer() {
		
		Object[] layers = getLayers(null, m_pickComaprator);
		
		if(layers == null) {
			return null;
		}
		
		int size = layers.length;
		if(0 == size) {
			return null;
		}
		ILayer layer = null, activeLayer = null;
		for(int i = size -1; i >= 0; --i) {
			layer = (ILayer)layers[i];
			if(layer.isVisible() && layer.isFocused()) {
				activeLayer = layer;
			} else {
				activeLayer = getActiveLayer(layer);
			}
			
			if(null != activeLayer) {
				break;
			}
		}
		return activeLayer;
	}
	
	protected ILayer getActiveLayer(Object parent) {
		int cnt = m_sensegraph.getChildCount(parent);
		ILayer layer = null;
		ILayer activeLayer = null;
		for(int i = 0; i < cnt; ++i) {
			layer = (ILayer)m_sensegraph.getChild(parent, i);
			if(layer.isVisible() && layer.isFocused()) {
				activeLayer = layer;
				break;
			}
		}
		return activeLayer;
	}
		
	////////////////////////////////////////////////////////////
	//TODO: Override BaseLayer
	////////////////////////////////////////////////////////////
	
	public synchronized void update(Object elem) {
		if(elem instanceof ILayer) {
			ILayer layer = (ILayer)elem;
			if(layer.equals(this)) {
				return;
			}
			if(m_clip.isInvalid()) {
				m_clip.setClip(layer.getBounds());
			} else {
				m_clip.union(layer.getBounds());
			}
		}
	}
	
	public synchronized void update() {
		super.update();
		this.updateLayers();
	}

	public synchronized void update(RenderClip c) {
		super.update(c);
		this.updateLayers();
	}

	public synchronized void update(double x, double y, double w, double h) {
		super.update(x, y, w, h);
		this.updateLayers();
	}

	public synchronized void update(Rectangle2D r) {
		super.update(r);
		this.updateLayers();
	}
	
	private void updateLayers() {
		Object[] layers = getLayers(null, null);
		for(int i = 0; i < layers.length; ++i) {
			ILayer layer = (ILayer)layers[i];
			if(layer.equals(this)) {
				continue;
			}
			if(m_clip.intersects(layer.getBounds())) {
				tempClip.setClip(m_clip);
				tempClip.intersection(layer.getBounds());
				layer.getClip().union(tempClip);
			}
		}
	}
	
	public void doLayout() {
		super.doLayout();
		TreeTraverser.dfsTraverse(m_sensegraph, m_layoutOP, null);
	}
	
	public void mouseClicked(MouseEvent e) {
		
		if(!check(e.getPoint())) {
			return;
		}
		
		if(e.getButton() == MouseEvent.BUTTON1) { 
			if(focus != selected && !(focus instanceof ILayerManager)) {
				lastSelected = selected;
				selected = focus;
			}
		}
		
		if(null != focus) {
			ILayer layer = (ILayer)focus;
			if(e.getButton() == MouseEvent.BUTTON1) {
				if(!(layer instanceof ILayerManager) && !layer.isFocused()) {
					focusLayer(layer);
					layer.update();
				}
			}
		}
		
		if(null != focus) {
			dispatchEvents(INPUT_EVENT_ELEM_CLICKED, focus, e);
		} else {
			dispatchEvents(INPUT_EVENT_MOUSE_CLICKED, focus, e);
		}
	}
	
	protected boolean check(Point e) {

		if (m_owner == null) {
			return false;
		}

		ICamera c = m_owner.getCamera();
		
		if(null != e) {
			if(null != c) {
				AffineTransform t = c.getTransform();
				t.transform(e, e);
			}
		}
		
		ActivityManager act = m_owner.getActivityManager();

		if (act.isPerforming()) {
			return false;
		}

		return true;
	}
	
	////////////////////////////////////////////////
	// TODO: Sense Graph Methods
	////////////////////////////////////////////////
	public ILayer getParent(ILayer layer) {
		return (ILayer)m_sensegraph.getParent(layer);
	}
	
	public Object[] getPickQueue() {
		return m_pickqueue;
	}
	
	public Object[] getLayers(IItemFilter filter, Comparator c) {
		if(m_sensegraph != null) {
			return m_sensegraph.getNodes(filter, c);
		}
		return null;
	}
	
	public boolean containsChild(ILayer parent, ILayer layer) {
		return m_sensegraph.containsChild(parent, layer);
	}
	
	public int getChildCount(ILayer parent) {
		return m_sensegraph.getChildCount(parent);
	}
	
	public ILayer getChild(ILayer parent, int index) {
		return (ILayer)m_sensegraph.getChild(parent, index);
	}
	
	public Object[] getChildren(ILayer parent, Comparator c) {
		Object[] children = m_sensegraph.getChildren(parent, c);
		if(null == children) {
			return null;
		}
		Arrays.sort(children);
		return children;
	}

	/////////////////////////////////////////////////////////
	// TODO: implement ILayerEventDispatcher
	/////////////////////////////////////////////////////////
	public void addLayerFocusListener(ILayerFocusListener l) {
		if(!m_layerFocusListeners.contains(l)) {
			this.m_layerFocusListeners.add(l);
		}
	}

	public void removeLayerFocusListener(ILayerFocusListener l) {
		this.m_layerFocusListeners.remove(l);
	}

	public void addLayerContainerListener(ILayerContainerListener l) {
		if(!m_layerContainerListeners.contains(l)) {
			this.m_layerContainerListeners.add(l);
		}
	}

	public void removeLayerContainerListener(ILayerContainerListener l) {
		this.m_layerContainerListeners.remove(l);
	}
	
	public void addLayerEventListener(ILayerEventListener l) {
		if(!m_layerEventListeners.contains(l)) {
			this.m_layerEventListeners.add(l);
		}
	}
	
	public void removeLayerEventListener(ILayerEventListener l) {
		this.m_layerEventListeners.remove(l);
	}
	
	///////////////////////////////////////////////////////////////
	// TODO: Event dispatcher
	///////////////////////////////////////////////////////////////
	protected void dispatchLayerEvents(int type, ILayer layer) {
		Iterator it = null;
		ILayerEventListener el = null;
		ILayerFocusListener fl = null;
		ILayerContainerListener cl = null;
		switch(type) {
		case LAYER_EVENT_FOCUS_GAINED:
			if(m_layerFocusListeners.isEmpty()) {
				return;
			}
			it = m_layerFocusListeners.iterator();
			while(it.hasNext()) {
				fl = (ILayerFocusListener)it.next();
				fl.focusGained(this, layer);
			}
			break;
		case LAYER_EVENT_FOCUS_LOSTED:
			if(m_layerFocusListeners.isEmpty()) {
				return;
			}
			it = m_layerFocusListeners.iterator();
			while(it.hasNext()) {
				fl = (ILayerFocusListener)it.next();
				fl.focusLost(this, layer);
			}
			break;
		case LAYER_EVENT_RESIZED:
			if(m_layerEventListeners.isEmpty()) {
				return;
			}
			it = m_layerEventListeners.iterator();
			while(it.hasNext()) {
				el = (ILayerEventListener)it.next();
				el.layerResized(this, layer);
			}
			break;
		case LAYER_EVENT_MOVED:
			if(m_layerEventListeners.isEmpty()) {
				return;
			}
			it = m_layerEventListeners.iterator();
			while(it.hasNext()) {
				el = (ILayerEventListener)it.next();
				el.layerMoved(this, layer);
			}
			break;
		case LAYER_EVENT_SHOWN:
			if(m_layerEventListeners.isEmpty()) {
				return;
			}
			it = m_layerEventListeners.iterator();
			while(it.hasNext()) {
				el = (ILayerEventListener)it.next();
				el.layerShown(this, layer);
			}
			break;
		case LAYER_EVENT_HIDDEN:
			if(m_layerEventListeners.isEmpty()) {
				return;
			}
			it = m_layerEventListeners.iterator();
			while(it.hasNext()) {
				el = (ILayerEventListener)it.next();
				el.layerHidden(this, layer);
			}
			break;
		case LAYER_EVENT_ADDED:
			if(m_layerContainerListeners.isEmpty()) {
				return;
			}
			it = m_layerContainerListeners.iterator();
			while(it.hasNext()) {
				cl = (ILayerContainerListener)it.next();
				cl.layerAdded(this, layer);
			}
			break;
		case LAYER_EVENT_REMOVED:
			if(m_layerContainerListeners.isEmpty()) {
				return;
			}
			it = m_layerContainerListeners.iterator();
			while(it.hasNext()) {
				cl = (ILayerContainerListener)it.next();
				cl.layerRemoved(this, layer);
			}
			break;
		}
	}
}
