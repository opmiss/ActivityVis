/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

public interface IElemFinder {

	public Object findElement(double x, double y);
	
	public void setOwner(ILayer layer);
	
	public ILayer getOwner();
}
