/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.Graphics2D;
import java.awt.RenderingHints;

import com.ibm.peony.geometry.IVisualElement;
import com.ibm.peony.render.IRender;
import com.ibm.peony.render.ITheme;
import com.ibm.peony.render.layer.AbstractLayerRender;

public class FIFOLayerRender extends AbstractLayerRender {

	public FIFOLayerRender() {
	}
	
	public void render(Graphics2D g, BaseLayer layer) {
				
		Display owner = layer.getOwner();
		
		if (owner == null) {
			return;
		}
				
		if(!(layer instanceof IVisualLayer)) {
			return;
		}

		final VisualLayer vislayer = (VisualLayer)layer;
		
		if (vislayer.isHighQuality()) {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		} else {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_OFF);
			g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
					RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
		}
		
		
		Object[] elems = vislayer.getElements(
				vislayer.getClipFilter(), 
				vislayer.getPaintComparator());
		
		if(null == elems || elems.length == 0) {
			return;
		}
		
		IVisualElement e = null;
		IRender r = null;
		ITheme t = null;
		for (int i = 0; i < elems.length; ++i) {
			e = (IVisualElement) elems[i];
			
			if (null == e || !e.isVisible()) {
				continue;
			}
			
			r = vislayer.getRender(e);
			if (null == r) {
				continue;
			}
			
			t = vislayer.getTheme(e);
			if(null == t) {
				continue;
			}
			
			r.render(g, e, t, e.isHighlight() || e.isFocused());
		}
	}
}
