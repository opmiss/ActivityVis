/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.display;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

import com.ibm.peony.interaction.distortion.IDistortion;
import com.ibm.peony.layout.ILayout;
import com.ibm.peony.render.layer.ILayerRender;
import com.ibm.peony.state.IActionRecorder;
import com.ibm.peony.state.IViewState;
import com.ibm.sdl.data.InvalidateDataException;
import com.ibm.sdl.util.prop.IProperty;

/**
 * Layer is a independent visualization unit in a display. Different 
 * layers in the same display are managed by a default layer manager 
 * in a stack data structrue, each layer maight  
 * <br>
 * The layer holds up the mapping relationship between visual elements 
 * and renders or themes, provides the rendering methods of the layer, 
 * dispatches the input events to every user event listener that related 
 * to it. 
 * <br>
 * generally speaking, a single layer is rendered in the following 
 * procedure by layer manager :
 * <br>
 * 1. rendering the background of layer.
 * 2. rendering the visual elements on this layer.
 * 3. rendering the focused visual element in a highlight way.
 * <br>
 * 
 * @author CaoNan
 * @version 0.2
 * @since 0.1
 *
 */
public interface ILayer extends IEventDispatcher, Comparable, IProperty {
	
	public static final String LAYER_UTIL = "LAYERUTIL";
	
//	TODO --------------------------- render ----------------------------------
	/**
	 * 
	 * @param g
	 */
	public void paint(Graphics2D g);
	
	public void update();
	
	public void update(RenderClip c);
	
	public void update(double x, double y, double w, double h);
	
	public void update(Rectangle2D r);
	
	public void update(Object elem);
	
	public RenderClip getClip();
	
	public void addBackgroundRender(ILayerRender render);

	public ILayerRender[] getBackgroundRenders();
	
	public void removeBackgroundRender(ILayerRender render);
	
	public void clearBackgroundRenders();
	
	public void setLayerRender(ILayerRender render);

	public ILayerRender getLayerRender();
	
	public void addInteractionRender(ILayerRender render);
	
	public ILayerRender[] getInteractionRenders();
	
	public void removeInteractionRender(ILayerRender render);
	
	public void clearInteractionRenders();
	
//	TODO --------------------------- layout -----------------------------------
	
	public void doLayout();
	
	public void registerLayout(ILayout layout);
	
	public ILayout getLayout();
	
//	TODO ------------------------ layer property ------------------------------
	
	public boolean isVisible();
	
	public boolean isFocused();
		
	public void setVisible(boolean visible);
	
	public void setFocus(boolean focus);
	
	public void setDistortion(IDistortion dis);
	
	public IDistortion getDistortion();
	
	public void setLevel(int level);
	
	public int getLevel();
	
	/**
	 * Set the backgound color of this layer
	 * <be>
	 * @param color background color
	 */
	public void setBackground(Paint color);
	
	/**
	 * Get the background color of this layer
	 * <br>
	 * @return the background color
	 */
	public Paint getBackground();
	
	public void setQuality(boolean bHighQuality);
	
	public boolean isHighQuality();

	public Display getOwner();
	
	public void setOwner(Display owner);
	
	public void setElemFinder(IElemFinder finder);
	
	public IElemFinder getElemFinder();
	
	public ILayerManager getLayerManager();
	
	public void setLayerManager(ILayerManager manager);
	
//	TODO ---------------- geometry info of layers ----------------------
	public int getX();
	
	public int getY();
	
	public int getWidth();

	public int getHeight();
	
	public void setX(int x);
	
	public void setY(int y);
	
	public void setWidth(int width);
	
	public void setHeight(int height);
	
	public void setBounds(int x, int y, int width, int height);
	
	public Rectangle2D getBounds();
	
//	TODO ---------------- distoriton related ----------------------------
	public Image transform(BufferedImage image);
	
	public Point2D transform(Point2D pt);
	
	public void transform(float[] coords, int npoints);
	
	public void transform(Point2D src, Point2D dst);
	
	public Shape transform(Shape shape);
	
//	TODO ----------------------------------------------------------------
	public Object[] getElements(Rectangle2D rect);
	
//	TODO ----------------------------------------------------------------
	public void addProcessListener(IProcessListener l);
	
	public void removeProcessListener(IProcessListener l);
	
	public void removeAllProcessListeners();
	
	/**
	 * Get the layer related visual data
	 * <br>
	 * @return return null if the SDL data has not been set.
	 */
	public Object getData();
	
	/**
	 * Set the SDL data structure that need to be visualized
	 * <br>
	 * When the data isn't an instanceof a SDL data sturucture, InvalidateDataException
	 * will be throwed.
	 * The related visual data will be also created during the process of this method.
	 * 
	 * @param data the SDL data structure
	 * @throws InvalidateDataException
	 */
	public void setData(Object data) throws InvalidateDataException;
	
	public void setState(IViewState state) throws InvalidateDataException;
	
	public IViewState getState();
		
	public void setActionRecorder(IActionRecorder recorder);
	
	public IActionRecorder getActionRecroder();
}
