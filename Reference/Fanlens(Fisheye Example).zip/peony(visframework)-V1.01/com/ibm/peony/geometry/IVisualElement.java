/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.peony.geometry;

import java.io.Serializable;

import com.ibm.sdl.util.prop.IProperty;


/**
 * VisualElement is an atom unit for visualization, which 
 * maintains the geometry information.
 * <br>
 * VisualElement is created automatically when the data set 
 * into the model.
 * <br>
 * Layout methods use visual element as an geometry 
 * information holder, and fill the position info, size info
 * and so on into each visual elemnt during the layout procudure. 
 * <br>
 * Each visual element reflects to a renderer, which is used for
 * rendering the element.
 * <br>
 * Each visual element reflects to a object data, which is used 
 * for maitaining the user data.
 * <br>
 * Each visual element contains a set of properties which can be
 * defined by users.
 * 
 * @author CaoNan
 *
 */
public interface IVisualElement extends IProperty, Comparable, Cloneable, Serializable {
	
	public static final String PROP_VISIBLE = "#visible#";
	
	public static final String PROP_FOCUSED = "#focus#";
	
	
	public static final double E = 1e-12;
	
	/**
	 * Can be seen or not
	 * 
	 * @return if true the element is visible 
	 */
	public boolean isVisible();
	
	/**
	 * Is focused or not
	 * 
	 * @return if true the element is focused
	 */
	public boolean isFocused();
	
	/**
	 * Is dragged or node
	 * 
	 * @return if true the element is dragged
	 */
	public boolean isDragged();
	
	public boolean isHighlight();
	
	/**
	 * Set the element visible propety.
	 * 
	 * @param v if true the element is visible.
	 */
	public void setVisible(boolean v);
	
	/**
	 * Set the element is focused or not
	 * 
	 * @param focused
	 */
	public void setFocused(boolean focused);
	
	/**
	 * Set the element is dragged or not
	 * 
	 * @param dragged
	 */
	public void setDragged(boolean dragged);
	
	public void setHighlight(boolean highlight);
	
	/**
	 * Get the weight of the node
	 * <br>
	 * Since in most visualization layout algorithms, 
	 * weight is an important paramenter used for calculate 
	 * the position and size info of a visual node, every
	 * visual has a default weight value. 
	 * 
	 * @return
	 */
	public double getWeight();
	
	/**
	 * Set the weight value of this node
	 * 
	 * @param weight 
	 */
	public void setWeight(double weight);
}
