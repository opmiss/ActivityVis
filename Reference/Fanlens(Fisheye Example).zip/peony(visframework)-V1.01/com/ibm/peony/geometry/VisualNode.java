/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.geometry;


/**
 * The default visual node
 * 
 * @author CaoNan
 * @version 0.2
 * @since 0.1
 */
public class VisualNode extends VisualElement implements IVisualNode {

	private static final long serialVersionUID = -7905150375304706893L;

	protected double x, y, z;
	
	protected double width, height, thick;
	
	/**
	 * Default constructor
	 *
	 */
	public VisualNode() {
	}
	
	/**
	 * Check the specified point(x, y) is inside the bound of node
	 * @param x the x-axis
	 * @param y the y-axis
	 * 
	 * @return If inside the bound of this node return true or return false
	 */
	public boolean contains(double x, double y) {
		double x1 = x;
		double x2 = x + width;
		double y1 = y;
		double y2 = y + height;
		
		if (x > x1 - E && x < x2 + E
				&& y > y1 - E && y < y2 + E)
			return true;
		
		return false;
	}
	
	public void setNode(IVisualNode node) {
		this.x = node.getX();
		this.y = node.getY();
		this.width = node.getWidth();
		this.height = node.getHeight();
	}
	
	public void setNode(double x, double y, double width, double height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public void setHeight(double height) {
		this.height = height;
	}
	
	public void setWidth(double width) {
		this.width = width;
	}
	
	public void setThick(double thick) {
		this.thick = thick;
	}
	
	public double getHeight() {
		return height;
	}
	
	public double getWidth() {
		return width;
	}
	
	public double getThick() {
		return thick;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public double getZ() {
		return z;
	}

	public void setX(double x) {
		this.x = x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public void setZ(double z) {
		this.z = z;
	}
	
	public Object clone() {
		VisualNode node = new VisualNode();
		node.x = x;
		node.y = y;
		node.z = z;
		node.width = width;
		node.height = height;
		node.thick = thick;
		
		Object[] keys = getKeyCollection();
		
		if(null != keys) {
			for(int i = 0; i < keys.length; ++i) {
				node.addProperty(keys[i], getProperty(keys[i]));
			}
		}
		return node;
	}
}
