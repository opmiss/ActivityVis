/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */

package com.ibm.peony.geometry;



public interface IVisualNode extends IVisualElement, Comparable, Cloneable {
	
	/**
	 * Get the x position of the node
	 * <br>
	 * The x position of a node could be the left up corner 
	 * or the center point of the node accroding to the node's 
	 * width
	 * 
	 * @return the x postion of the node
	 */
	public double getX();
	
	/**
	 * Get the y position of the node
	 * <br>
	 * The y position of a node could be the left up corner
	 * or the center point of the node accroding to the node's
	 * height
	 * 
	 * @return the y postion of the node
	 */
	public double getY();
	
	/**
	 * Get the z position of the node
	 * <br>
	 * The z position of a node could be the left up corner
	 * or the center point of the node accroding to the node's
	 * height
	 * 
	 * @return the z postion of the node
	 */
	public double getZ();
	
	/**
	 * Set the x position of the node
	 * <br>
	 * @param x
	 */
	public void setX(double x);
	
	/**
	 * Set the y position of the node
	 * <br>
	 * @param y
	 */
	public void setY(double y);
	
	/**
	 * Set the y position of the node
	 * <br>
	 * @param y
	 */
	public void setZ(double z);
	
	/**
	 * Set the width of the node
	 * <br>
	 * @param width
	 */
	public void setWidth(double width);
	
	/**
	 * Set the height of the node
	 * <br> 
	 * @param height
	 */
	public void setHeight(double height);
	
	/**
	 * Set the thick of the node
	 * <br> 
	 * @param height
	 */
	public void setThick(double thick);
	
	/**
	 * Set the this node the the parameter node's
	 * x position, y position, width and height.
	 *  
	 * @param node
	 */
	public void setNode(IVisualNode node);
	
	/**
	 * Set the key geometry information of the node
	 * 
	 * @param x x position of the node
	 * @param y y position of the node
	 * @param width the width of the node
	 * @param height the height of the node
	 */
	public void setNode(double x, double y, double width, double height);
	
	/**
	 * Get the width of the node
	 * @return width
	 */
	public double getWidth();
	

	/**
	 * Get the height of the node
	 * @return height
	 */
	public double getHeight();
}
