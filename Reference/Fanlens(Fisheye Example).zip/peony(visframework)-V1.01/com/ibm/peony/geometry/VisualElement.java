/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.geometry;

import java.util.HashMap;
import java.util.Map;

import com.ibm.sdl.util.PropOperator;
import com.ibm.sdl.util.prop.IWeight;
import com.ibm.sdl.util.prop.Property;

/**
 * Default visual element.
 * <br>
 * Since visual element is a logic concept in mind, 
 * this class is designed to be an abstract class.
 * 
 * @author CaoNan
 * @version 0.2
 * @since 0.1
 */
public abstract class VisualElement extends Property implements IVisualElement {
	
	private static final long serialVersionUID = 6826492721200276570L;

	protected boolean isVisible = true;
	
	protected boolean isFocused = false;
	
	protected boolean isDragged = false;
	
	protected boolean isHighlight = false;
	
	protected Map m_properties = new HashMap(0);
	
	/**
	 * Default constructor
	 *
	 */
	public VisualElement() {
	}
		
	public boolean isVisible() {
		return isVisible;
	}
	
	public boolean isFocused() {
		return isFocused;
	}
	
	public boolean isDragged() {
		return isDragged;
	}
	
	public boolean isHighlight() {
		return isHighlight;
	}
	
	public void setVisible(boolean v) {
		if(isVisible != v) {
			this.isVisible = v;
			this.firePropertyChanged(PROP_VISIBLE, this);
		}
	}
	
	public void setFocused(boolean focused) {
		if(isFocused != focused) {
			this.isFocused = focused;
			this.firePropertyChanged(PROP_FOCUSED, this);
		}
	}
	
	public void setDragged(boolean dragged) {
		this.isDragged = dragged;
	}
	
	public void setHighlight(boolean highlight) {
		this.isHighlight = highlight;
	}
	
	public void setWeight(double weight) {
		this.addProperty(IWeight.PROP_WEIGHT, new Double(weight));
	}
	
	public double getWeight() {
		return PropOperator.getInstance().getWeight(this);
	}
	
	public String toString() {
		String name = PropOperator.getInstance().getName(this);
		return name == null ? "" : name;
	}
	
	public int compareTo(Object n) {
		
		if(n == null) {
			return 1;
		}
		
		if(!(n instanceof IVisualElement)) {
			return 1;
		}
		double w1 = getWeight();
		double w2 = ((IVisualElement)n).getWeight();
		
		if(Math.abs(w1 - w2) < 1E-12) {
			return 0;
		}
		
		return w1 - w2 > 0 ? -1 : 1;
	}
}
