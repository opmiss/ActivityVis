/**
 * peony : A light weighted InfoVis toolkit
 * Copyright (C) 2005 - 2006 IBM CRL Information Visualization and Analysis Team All Rights Reserved
 * @author CaoNan (nancao@cn.ibm.com)
 * IBM Confidential
 */
package com.ibm.peony.geometry;


/**
 * Default visual edge
 * 
 * @author CaoNan
 * @version 0.2
 * @since 0.1
 */
public class VisualEdge extends VisualElement implements IVisualEdge {
	
	private static final long serialVersionUID = 7381238303149131832L;
	
	private Object m_node1 = null;
	private Object m_node2 = null;
	
	/**
	 * Default Constructor
	 *
	 */
	public VisualEdge() {
	}
	
	public void setFirstNode(Object node) {
		this.m_node1 = node;
	}
	
	public void setSecondNode(Object node) {
		this.m_node2 = node;
	}
	
	public Object getFirstNode() {
		return m_node1;
	}

	public Object getSecondNode() {
		return m_node2;
	}
	
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	
	public String toString() {
		return m_node1 + "->" + m_node2;
	}
}
