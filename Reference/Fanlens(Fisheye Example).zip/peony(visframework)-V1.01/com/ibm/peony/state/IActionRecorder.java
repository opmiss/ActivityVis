package com.ibm.peony.state;


public interface IActionRecorder {

	public ActionRecord[] getActionRecords();
	
	public ActionRecord[] getStateRecords();
	
	public void record(String actType, IStateParam param);
	
	public void setActionPerformer(IActionPerformer p);
	
	public IActionPerformer getActionPerformer();
	
	public boolean redo(int level);
	
	public boolean undo(int level);
		
	public void clear();
	
}
