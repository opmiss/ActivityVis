package com.ibm.peony.state;


public abstract class ActionRecorder implements IActionRecorder {

	protected int m_current = 0;
	
	protected IActionPerformer m_performer = null;
	
	public ActionRecorder() {
	}
	
		
	public void fireExcute(String type, Object param) {
		if(m_performer != null) {
			m_performer.execute(type, param, false);
		}
	}
	
	public void fireUnexcute(String type, Object param) {
		if(m_performer != null) {
			m_performer.unexecute(type, param, false);
		}
	}
	
	public void setActionPerformer(IActionPerformer p) {
		m_performer = p;
	}

	public IActionPerformer getActionPerformer() {
		return m_performer;
	}

}
