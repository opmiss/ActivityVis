package com.ibm.peony.state;

import java.util.ArrayList;
import java.util.List;

public class ActionListRecorder extends ActionRecorder implements IActionRecorder {

	private static final long serialVersionUID = 8981062153160444909L;

	protected List m_records = null;
	
	public ActionListRecorder() {
		m_records = new ArrayList();
	}
	
	public ActionRecord[] getActionRecords() {
		return (ActionRecord[])m_records.toArray(new ActionRecord[]{});
	}
	
	public synchronized void record(String actType, IStateParam param) {
		ActionRecord rec = null;
		int size = m_records.size();
		// in the middle of the record list, remove all the records behined the list
		if(m_current < size) {
			for(int i = size - 1; i >= m_current; --i) {
				m_records.remove(i);
			}
			rec = new ActionRecord(actType, param);
			m_records.add(rec);
			m_current ++;
		} else {
			rec = new ActionRecord(actType, param);
			m_records.add(rec);
			m_current = size + 1;
		}
	}

	public synchronized boolean redo(int levels) {
		ActionRecord record = null;
		int size = m_records.size();
		for (int i = 0; i < levels; ++i) {
			if (m_current < size) {
				record = (ActionRecord)m_records.get(m_current++);
				fireExcute(
						record.type, 
						record.param);
			} else {
				break;
			}
		}
		return m_current < size;
	}

	public synchronized boolean undo(int levels) {
		ActionRecord record = null;
		for (int i = 0; i < levels; ++i) {
			if (m_current > 0) {
				record = (ActionRecord) m_records.get(--m_current);
				fireUnexcute(
						record.type, 
						record.param);
			} else {
				break;
			}
		}
		return m_current > 0;
	}

	public synchronized void clear() {
		m_records.clear();
	}

	public synchronized ActionRecord[] getStateRecords() {
		ActionRecord[] record = new ActionRecord[m_current];
		for(int i = 0; i < m_current; ++i) {
			record[i] = (ActionRecord)m_records.get(i);
		}
		return record;
	}
}
