package com.ibm.peony.state;

import java.io.Serializable;


public interface IViewState extends Serializable {
	
	public Object getDataState();
	
	public ActionRecord[] getActionTrail();
	
}
