package com.ibm.peony.state;

public class ActionTreeRecorder extends ActionRecorder implements IActionRecorder {

	public ActionRecord[] getActionRecords() {
		return null;
	}

	public void record(String actType, IStateParam param) {
	}

	public boolean redo(int level) {
		return false;
	}

	public boolean undo(int level) {
		return false;
	}

	public void clear() {
	}

	public ActionRecord[] getStateRecords() {
		return null;
	}

}
