package com.ibm.peony.state;

import java.util.List;


public class ViewState implements IViewState {

	private static final long serialVersionUID = -8615953937436967431L;

	private Object m_data = null;
	
	private ActionRecord[] m_records = null;
	
	public ViewState() {
		
	}
	
	public void setDataState(Object data) {
		m_data = data;
	}

	public Object getDataState() {
		return m_data;
	}
	
	public void setViewState(ActionRecord[] actrecords) {
		m_records = actrecords;
	}

	public ActionRecord[] getActionTrail() {
		return m_records;
	}

}
