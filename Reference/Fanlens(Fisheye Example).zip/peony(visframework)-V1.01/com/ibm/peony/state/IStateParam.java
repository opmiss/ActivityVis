package com.ibm.peony.state;

import java.io.Serializable;

public interface IStateParam extends Serializable {
	
	public void setRedoParam(Object param);
	
	public void setUndoParam(Object param);
	
	public Object getRedoParam();
	
	public Object getUndoParam();
}
