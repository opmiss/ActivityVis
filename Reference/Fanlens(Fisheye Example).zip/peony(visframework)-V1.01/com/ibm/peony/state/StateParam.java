package com.ibm.peony.state;

import com.ibm.sdl.data.InvalidateDataException;

public class StateParam implements IStateParam {

	private static final long serialVersionUID = -3459789378224635645L;
	protected Object m_redo = null;
	protected Object m_undo = null;
	
	public StateParam() {
	}
	
	public StateParam(Object redoParam, Object undoParam) throws InvalidateDataException {
		m_redo = redoParam;
		m_undo = undoParam;
	}

	public void setRedoParam(Object param) {
		m_redo = param;
	}

	public void setUndoParam(Object param) {
		m_undo = param;
	}

	public Object getRedoParam() {
		return m_redo;
	}

	public Object getUndoParam() {
		return m_undo;
	}
}
