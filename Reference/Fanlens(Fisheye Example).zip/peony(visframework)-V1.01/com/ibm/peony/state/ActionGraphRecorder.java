package com.ibm.peony.state;


public class ActionGraphRecorder extends ActionRecorder implements IActionRecorder {

	public ActionRecord[] getActionRecords() {
		return null;
	}

	public void record(String actType, IStateParam param) {
	}

	public void clear() {
	}

	public boolean redo(int level) {
		return false;
	}

	public boolean undo(int level) {
		return false;
	}

	public ActionRecord[] getStateRecords() {
		return null;
	}

}
