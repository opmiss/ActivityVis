package com.ibm.peony.state;

import java.io.Serializable;

public class ActionRecord implements Serializable {

	private static final long serialVersionUID = -4302150294786968274L;
	
	public String type = null;
	public IStateParam param = null;
	
	public ActionRecord(String type, IStateParam param) {
		this.type = type;
		this.param = param;
	}
}
