package com.ibm.peony.state;

public interface IActionPerformer {

	public void execute(String type, Object param, boolean bsystem);
	
	public void unexecute(String type, Object param, boolean bsystem);
	
}
